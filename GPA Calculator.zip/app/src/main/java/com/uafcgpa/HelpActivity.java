package com.uafcgpa;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.ClipboardManager;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;


public class HelpActivity extends Activity {

	private LinearLayout linear2;
	private LinearLayout linear1;
	private LinearLayout linear4;
	private LinearLayout linear6;
	private LinearLayout linear5;
	private LinearLayout linear7;
	private TextView textview3;
	private TextView textview2;
	private TextView textview13;
	private TextView textview14;
	private TextView textview12;
	private TextView textview15;
	private TextView textview16;
	private TextView textview4;
	private TextView textview7;
	private TextView textview17;
	private TextView textview18;
	private TextView textview19;
	private TextView textview8;



	private Intent i = new Intent();
	private SharedPreferences share;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.help);
		initialize();
		initializeLogic();
	}

	private void  initialize() {
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		textview3 = (TextView) findViewById(R.id.textview3);
		textview2 = (TextView) findViewById(R.id.textview2);
		textview13 = (TextView) findViewById(R.id.textview13);
		textview14 = (TextView) findViewById(R.id.textview14);
		textview12 = (TextView) findViewById(R.id.textview12);
		textview15 = (TextView) findViewById(R.id.textview15);
		textview16 = (TextView) findViewById(R.id.textview16);
		textview4 = (TextView) findViewById(R.id.textview4);
		textview7 = (TextView) findViewById(R.id.textview7);
		textview17 = (TextView) findViewById(R.id.textview17);
		textview18 = (TextView) findViewById(R.id.textview18);
		textview19 = (TextView) findViewById(R.id.textview19);
		textview8 = (TextView) findViewById(R.id.textview8);


		share = getSharedPreferences("activity", Activity.MODE_PRIVATE);


	}

	private void  initializeLogic() {
		
getActionBar().setTitle("Help");
		textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/osap.ttf"), 0);
		textview4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		textview7.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/osap.ttf"), 0);
		textview8.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/osap.ttf"), 0);
		
getActionBar().setDisplayHomeAsUpEnabled(true);
/* */} 
@Override 
public boolean onMenuItemSelected(int featureId, MenuItem item) {
int itemId = item.getItemId(); 
switch (itemId) {
case android.R.id.home:
finish();
break;
}
return true;

	}

	@Override
	public void onBackPressed() {
				if (share.getString("pop", "").equals("1")) {
					i.setClass(getApplicationContext(), Main2Activity.class);
					startActivity(i);
					finish();
				}
				else {
					if (share.getString("pop", "").equals("2")) {
						i.setClass(getApplicationContext(), WelcomeActivity.class);
						startActivity(i);
						finish();
					}
					else {
						if (share.getString("pop", "").equals("3")) {
							i.setClass(getApplicationContext(), MainActivity.class);
							startActivity(i);
							finish();
						}
					}
				}
	}





	// created automatically
	private void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}

	private int getLocationX(View _v) {
		 int _location[] = new int[2];
		 _v.getLocationInWindow(_location);
		 return _location[0];
	}

	private int getLocationY(View _v) {
		 int _location[] = new int[2];
		 _v.getLocationInWindow(_location);
		 return _location[1];
	}

	private int getRandom(int _minValue ,int _maxValue){
		Random random = new Random();
		return random.nextInt(_maxValue - _minValue + 1) + _minValue;
	}

	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
				_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}

	private float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}

	private int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}

	private int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}


}
