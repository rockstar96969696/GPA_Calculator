package com.uafcgpa;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.ClipboardManager;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;


public class Main2Activity extends Activity {

	private LinearLayout linear_al_expt_welcm;
	private Spinner spinner1;
	private TextView textview15;
	private ScrollView vscrol_all_data;
	private LinearLayout allign_gpa_message;
	private Button submitdata;
	private LinearLayout allign_reset_calcula;
	private LinearLayout linear_subject_all;
	private LinearLayout linear2;
	private LinearLayout sp1;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private LinearLayout linear10;
	private LinearLayout linear11;
	private Button button7;
	private TextView textview5;
	private Button subject1;
	private TextView textview6;
	private Button subject2;
	private TextView textview7;
	private Button subject3;
	private TextView textview8;
	private Button subject4;
	private TextView textview9;
	private Button subject5;
	private TextView textview10;
	private Button subject6;
	private Button button8;
	private TextView textview1;
	private EditText ch_sub1;
	private EditText ch_sub2;
	private EditText ch_sub3;
	private EditText ch_sub4;
	private EditText ch_sub5;
	private EditText ch_sub6;
	private Button button9;
	private TextView textview2;
	private EditText no1;
	private EditText no2;
	private EditText no3;
	private EditText no4;
	private EditText no5;
	private EditText no6;
	private Button button10;
	private TextView textview3;
	private EditText points1;
	private EditText points2;
	private EditText points3;
	private EditText points4;
	private EditText points5;
	private EditText points6;
	private Button button11;
	private TextView sp4;
	private EditText grade1;
	private EditText grade2;
	private EditText grade3;
	private EditText grade4;
	private EditText grade5;
	private EditText grade6;
	private TextView textview11;
	private TextView gpa;
	private Button reset;
	private TextView textview13;
	private Button calculate;
	private TextView textview14;
	private Button share_result;

	private String CrH2 = "";
	private String pkg = "";
	private String set = "";
	private double p1 = 0;
	private double p2 = 0;
	private double p4 = 0;
	private double p5 = 0;
	private double p6 = 0;
	private String set2 = "";
	private double subj1 = 0;
	private double subj2 = 0;
	private double subj3 = 0;
	private double subj4 = 0;
	private double subj5 = 0;
	private double subj6 = 0;
	private HashMap<String, Object> map = new HashMap<>();
	private String your_version = "";
	private String package_name = "";
	private String latest_version = "";
	private boolean connected;
	private String command = "";
	private double p3 = 0;
	private String a = "";
	private double rotate = 0;
	private double no_8 = 0;
	private double no_9 = 0;
	private double no_10 = 0;
	private double no_11 = 0;
	private double no_12 = 0;
	private double no_13 = 0;
	private double no_14 = 0;
	private double no_15 = 0;
	private double no_16 = 0;
	private double no_17 = 0;
	private double no_18 = 0;
	private double no_19 = 0;
	private double no_20 = 0;
	private double no_21 = 0;
	private double no_22 = 0;
	private double no_23 = 0;
	private double no_24 = 0;
	private double no_25 = 0;
	private double no_26 = 0;
	private double no_27 = 0;
	private double no_28 = 0;
	private double no_29 = 0;
	private double no_30 = 0;
	private double no_31 = 0;
	private double no_32 = 0;
	private double no_33 = 0;
	private double no_34 = 0;
	private double no_35 = 0;
	private double no_36 = 0;
	private double no_37 = 0;
	private double no_38 = 0;
	private double no_39 = 0;
	private double no_40 = 0;
	private double no_41 = 0;
	private double no_42 = 0;
	private double no_43 = 0;
	private double no_44 = 0;
	private double no_45 = 0;
	private double no_46 = 0;
	private double no_47 = 0;
	private double no_48 = 0;
	private double no_49 = 0;
	private double no_50 = 0;

	private ArrayList<HashMap<String, Object>> map1 = new ArrayList<>();
	private ArrayList<String> list = new ArrayList<String>();

	private Timer _timer = new Timer();
	private AlertDialog.Builder dilog1;
	private Intent i = new Intent();
	private AlertDialog.Builder dilog2;
	private SharedPreferences file;
	private AlertDialog.Builder dilog3;
	private SharedPreferences file2;
	private Intent i2 = new Intent();
	private AlertDialog.Builder info;
	private Intent whatsappgroup = new Intent();
	private AlertDialog.Builder dialog;
	private SharedPreferences File;
	private AlertDialog.Builder dilo3;
	private Intent iii = new Intent();
	private Vibrator vib;
	private SharedPreferences vibration;
	private Intent i4 = new Intent();
	private AlertDialog.Builder exit;
	private SharedPreferences gpa_file;
	private SharedPreferences share;
	private SharedPreferences back;
	private TimerTask t;
	private TimerTask time;
	private AlertDialog.Builder help;
	private ObjectAnimator blink = new ObjectAnimator();
	private ObjectAnimator blink2 = new ObjectAnimator();
	private SharedPreferences grade;
	private SharedPreferences grade_2;
	private SharedPreferences grade_3;
	private SharedPreferences grade_4;
	private SharedPreferences grade_5;
	private SharedPreferences grade_6;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main2);
		initialize();
		initializeLogic();
	}

	private void  initialize() {
		linear_al_expt_welcm = (LinearLayout) findViewById(R.id.linear_al_expt_welcm);
		spinner1 = (Spinner) findViewById(R.id.spinner1);
		textview15 = (TextView) findViewById(R.id.textview15);
		vscrol_all_data = (ScrollView) findViewById(R.id.vscrol_all_data);
		allign_gpa_message = (LinearLayout) findViewById(R.id.allign_gpa_message);
		submitdata = (Button) findViewById(R.id.submitdata);
		allign_reset_calcula = (LinearLayout) findViewById(R.id.allign_reset_calcula);
		linear_subject_all = (LinearLayout) findViewById(R.id.linear_subject_all);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		sp1 = (LinearLayout) findViewById(R.id.sp1);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		button7 = (Button) findViewById(R.id.button7);
		textview5 = (TextView) findViewById(R.id.textview5);
		subject1 = (Button) findViewById(R.id.subject1);
		textview6 = (TextView) findViewById(R.id.textview6);
		subject2 = (Button) findViewById(R.id.subject2);
		textview7 = (TextView) findViewById(R.id.textview7);
		subject3 = (Button) findViewById(R.id.subject3);
		textview8 = (TextView) findViewById(R.id.textview8);
		subject4 = (Button) findViewById(R.id.subject4);
		textview9 = (TextView) findViewById(R.id.textview9);
		subject5 = (Button) findViewById(R.id.subject5);
		textview10 = (TextView) findViewById(R.id.textview10);
		subject6 = (Button) findViewById(R.id.subject6);
		button8 = (Button) findViewById(R.id.button8);
		textview1 = (TextView) findViewById(R.id.textview1);
		ch_sub1 = (EditText) findViewById(R.id.ch_sub1);
		ch_sub2 = (EditText) findViewById(R.id.ch_sub2);
		ch_sub3 = (EditText) findViewById(R.id.ch_sub3);
		ch_sub4 = (EditText) findViewById(R.id.ch_sub4);
		ch_sub5 = (EditText) findViewById(R.id.ch_sub5);
		ch_sub6 = (EditText) findViewById(R.id.ch_sub6);
		button9 = (Button) findViewById(R.id.button9);
		textview2 = (TextView) findViewById(R.id.textview2);
		no1 = (EditText) findViewById(R.id.no1);
		no2 = (EditText) findViewById(R.id.no2);
		no3 = (EditText) findViewById(R.id.no3);
		no4 = (EditText) findViewById(R.id.no4);
		no5 = (EditText) findViewById(R.id.no5);
		no6 = (EditText) findViewById(R.id.no6);
		button10 = (Button) findViewById(R.id.button10);
		textview3 = (TextView) findViewById(R.id.textview3);
		points1 = (EditText) findViewById(R.id.points1);
		points2 = (EditText) findViewById(R.id.points2);
		points3 = (EditText) findViewById(R.id.points3);
		points4 = (EditText) findViewById(R.id.points4);
		points5 = (EditText) findViewById(R.id.points5);
		points6 = (EditText) findViewById(R.id.points6);
		button11 = (Button) findViewById(R.id.button11);
		sp4 = (TextView) findViewById(R.id.sp4);
		grade1 = (EditText) findViewById(R.id.grade1);
		grade2 = (EditText) findViewById(R.id.grade2);
		grade3 = (EditText) findViewById(R.id.grade3);
		grade4 = (EditText) findViewById(R.id.grade4);
		grade5 = (EditText) findViewById(R.id.grade5);
		grade6 = (EditText) findViewById(R.id.grade6);
		textview11 = (TextView) findViewById(R.id.textview11);
		gpa = (TextView) findViewById(R.id.gpa);
		reset = (Button) findViewById(R.id.reset);
		textview13 = (TextView) findViewById(R.id.textview13);
		calculate = (Button) findViewById(R.id.calculate);
		textview14 = (TextView) findViewById(R.id.textview14);
		share_result = (Button) findViewById(R.id.share_result);

		dilog1 = new AlertDialog.Builder(this);

		dilog2 = new AlertDialog.Builder(this);
		file = getSharedPreferences("store", Activity.MODE_PRIVATE);
		dilog3 = new AlertDialog.Builder(this);
		file2 = getSharedPreferences("store", Activity.MODE_PRIVATE);

		info = new AlertDialog.Builder(this);

		dialog = new AlertDialog.Builder(this);
		File = getSharedPreferences("file", Activity.MODE_PRIVATE);
		dilo3 = new AlertDialog.Builder(this);

		vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
		vibration = getSharedPreferences("value", Activity.MODE_PRIVATE);

		exit = new AlertDialog.Builder(this);
		gpa_file = getSharedPreferences("gpa", Activity.MODE_PRIVATE);
		share = getSharedPreferences("activity", Activity.MODE_PRIVATE);
		back = getSharedPreferences("stop", Activity.MODE_PRIVATE);


		help = new AlertDialog.Builder(this);


		grade = getSharedPreferences("grade1", Activity.MODE_PRIVATE);
		grade_2 = getSharedPreferences("grade2", Activity.MODE_PRIVATE);
		grade_3 = getSharedPreferences("grade3", Activity.MODE_PRIVATE);
		grade_4 = getSharedPreferences("grade4", Activity.MODE_PRIVATE);
		grade_5 = getSharedPreferences("grade5", Activity.MODE_PRIVATE);
		grade_6 = getSharedPreferences("grade6", Activity.MODE_PRIVATE);

		submitdata.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				_ch1_check();
				_check_colors();
				submitdata.setAlpha((float)(Double.parseDouble(".2")));
				calculate.setRotation((float)(rotate));
				_rotation();
				share_result.setVisibility(View.INVISIBLE);
				t = new TimerTask() {
							@Override
								public void run() {
									runOnUiThread(new Runnable() {
									@Override
										public void run() {
														submitdata.setAlpha((float)(Double.parseDouble("1")));
										}
									});
								}
							};
							_timer.schedule(t, (int)(150));
				gpa_file.edit().putString("gpa", "1").commit();
				if (file.getString("subject", "").equals("4") && !(ch_sub1.getText().toString().equals("") || (ch_sub2.getText().toString().equals("") || ((ch_sub3.getText().toString().equals("") || ch_sub4.getText().toString().equals("")) || (no1.getText().toString().equals("") || (no2.getText().toString().equals("") || (no3.getText().toString().equals("") || no4.getText().toString().equals("")))))))) {
					allign_reset_calcula.setVisibility(View.VISIBLE);
					submitdata.setVisibility(View.GONE);
					points1.setVisibility(View.VISIBLE);
					points2.setVisibility(View.VISIBLE);
					points3.setVisibility(View.VISIBLE);
					points4.setVisibility(View.VISIBLE);
					points5.setVisibility(View.GONE);
					points6.setVisibility(View.GONE);
					_check_colors();
					_check_all();
					_disabla_input();
				}
				else {
					if (ch_sub1.getText().toString().equals("") || (ch_sub2.getText().toString().equals("") || ((ch_sub3.getText().toString().equals("") || ch_sub4.getText().toString().equals("")) || (no1.getText().toString().equals("") || (no2.getText().toString().equals("") || (no3.getText().toString().equals("") || no4.getText().toString().equals(""))))))) {

					}
					if (file.getString("subject", "").equals("5") && !(ch_sub2.getText().toString().equals("") || ((ch_sub3.getText().toString().equals("") || (ch_sub4.getText().toString().equals("") || ch_sub5.getText().toString().equals(""))) || (no1.getText().toString().equals("") || (no2.getText().toString().equals("") || (no3.getText().toString().equals("") || (no4.getText().toString().equals("") || no5.getText().toString().equals("")))))))) {
						allign_reset_calcula.setVisibility(View.VISIBLE);
						submitdata.setVisibility(View.GONE);
						points1.setVisibility(View.VISIBLE);
						points2.setVisibility(View.VISIBLE);
						points3.setVisibility(View.VISIBLE);
						points4.setVisibility(View.VISIBLE);
						points5.setVisibility(View.VISIBLE);
						points6.setVisibility(View.GONE);
						_check_colors();
						_check_all();
						_disabla_input();
					}
					else {
						if (ch_sub1.getText().toString().equals("") || (ch_sub2.getText().toString().equals("") || ((ch_sub3.getText().toString().equals("") || ch_sub4.getText().toString().equals("")) || ((ch_sub5.getText().toString().equals("") || no1.getText().toString().equals("")) || (no2.getText().toString().equals("") || (no3.getText().toString().equals("") || (no4.getText().toString().equals("") || no5.getText().toString().equals("")))))))) {

						}
						if (file.getString("subject", "").equals("6") && !(ch_sub2.getText().toString().equals("") || ((ch_sub3.getText().toString().equals("") || (ch_sub4.getText().toString().equals("") || (ch_sub5.getText().toString().equals("") || ch_sub6.getText().toString().equals("")))) || (no1.getText().toString().equals("") || (no2.getText().toString().equals("") || (no3.getText().toString().equals("") || (no4.getText().toString().equals("") || (no5.getText().toString().equals("") || no6.getText().toString().equals(""))))))))) {
							allign_reset_calcula.setVisibility(View.VISIBLE);
							submitdata.setVisibility(View.GONE);
							points1.setVisibility(View.VISIBLE);
							points2.setVisibility(View.VISIBLE);
							points3.setVisibility(View.VISIBLE);
							points4.setVisibility(View.VISIBLE);
							points5.setVisibility(View.VISIBLE);
							points6.setVisibility(View.VISIBLE);
							grade5.setVisibility(View.VISIBLE);
							grade6.setVisibility(View.VISIBLE);
							_check_colors();
							_check_all();
							_disabla_input();
						}
						else {
							if (ch_sub1.getText().toString().equals("") || (ch_sub2.getText().toString().equals("") || ((ch_sub3.getText().toString().equals("") || ch_sub4.getText().toString().equals("")) || (((ch_sub5.getText().toString().equals("") || ch_sub6.getText().toString().equals("")) || no1.getText().toString().equals("")) || (no2.getText().toString().equals("") || (no3.getText().toString().equals("") || (no4.getText().toString().equals("") || (no5.getText().toString().equals("") || no6.getText().toString().equals(""))))))))) {
								showMessage("Fill all subjects data");
							}
						}
					}
				}
				if (vibration.getString("click", "").equals("1")) {
					vib.vibrate((long)(0));
				}
				else {
					if (vibration.getString("click", "").equals("2")) {
						vib.vibrate((long)(100));
					}
				}
				blink.setTarget(calculate);
				blink.setPropertyName("alpha");
				blink.setFloatValues((float)(0), (float)(1));
				blink.setRepeatMode(ValueAnimator.REVERSE);
				blink.setDuration((int)(1000));
				blink.setRepeatCount((int)(500));
				blink.start();
				_numbers();
			}
		});
		reset.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				_mode();
				reset.setAlpha((float)(Double.parseDouble(".2")));
				t = new TimerTask() {
							@Override
								public void run() {
									runOnUiThread(new Runnable() {
									@Override
										public void run() {
														reset.setAlpha((float)(Double.parseDouble("1")));
										}
									});
								}
							};
							_timer.schedule(t, (int)(150));
				gpa_file.edit().putString("gpa", "1").commit();
				file.edit().putString("reset", "0").commit();
				back.edit().putString("reset", "0").commit();
				_check_colors();
				_Reset();
				_enable_input();
				if (vibration.getString("click", "").equals("1")) {
					vib.vibrate((long)(0));
				}
				else {
					if (vibration.getString("click", "").equals("2")) {
						vib.vibrate((long)(100));
					}
				}
				spinner1.setSelection((int)(0));
			}
		});
		calculate.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				share_result.setVisibility(View.VISIBLE);
				allign_gpa_message.setVisibility(View.VISIBLE);
				calculate.setAlpha((float)(Double.parseDouble(".2")));
				t = new TimerTask() {
							@Override
								public void run() {
									runOnUiThread(new Runnable() {
									@Override
										public void run() {
														calculate.setAlpha((float)(Double.parseDouble("1")));
										}
									});
								}
							};
							_timer.schedule(t, (int)(150));
				if (vibration.getString("click", "").equals("1")) {
					vib.vibrate((long)(0));
				}
				else {
					if (vibration.getString("click", "").equals("2")) {
						vib.vibrate((long)(100));
					}
				}
				if (gpa_file.getString("gpa", "").equals("0")) {
					_disabla_input();
					blink2.setTarget(reset);
					blink2.setPropertyName("alpha");
					blink2.setFloatValues((float)(0), (float)(1));
					blink2.setRepeatMode(ValueAnimator.REVERSE);
					blink2.setDuration((int)(1000));
					blink2.setRepeatCount((int)(500));
					blink2.start();
					showMessage("Reset data first");
				}
				if (gpa_file.getString("gpa", "").equals("1")) {
					if (file.getString("subject", "").equals("6")) {
						if (!(points2.getText().toString().equals("") && (points3.getText().toString().equals("") && (points4.getText().toString().equals("") && (points5.getText().toString().equals("") && (points1.getText().toString().equals("") && points6.getText().toString().equals(""))))))) {
							_calculate_subject6();
						}
						else {
							if (points2.getText().toString().equals("") || (points3.getText().toString().equals("") || (points4.getText().toString().equals("") || (points5.getText().toString().equals("") || (points1.getText().toString().equals("") || points6.getText().toString().equals("")))))) {
								showMessage("Enter valid data");
							}
						}
					}
					else {
						if (file.getString("subject", "").equals("5")) {
							if (!(points2.getText().toString().equals("") && (points3.getText().toString().equals("") && (points4.getText().toString().equals("") && (points5.getText().toString().equals("") && points1.getText().toString().equals("")))))) {
								_calculate_subject5();
							}
							else {
								if (points2.getText().toString().equals("") || (points3.getText().toString().equals("") || (points4.getText().toString().equals("") || (points5.getText().toString().equals("") || points1.getText().toString().equals(""))))) {
									showMessage("Enter valid data");
								}
							}
						}
						else {
							if (file.getString("subject", "").equals("4")) {
								if (!(points2.getText().toString().equals("") && (points3.getText().toString().equals("") && (points4.getText().toString().equals("") && points1.getText().toString().equals(""))))) {
									_calculate_subject4();
								}
								else {
									if (points2.getText().toString().equals("") || (points3.getText().toString().equals("") || (points4.getText().toString().equals("") || points1.getText().toString().equals("")))) {
										showMessage("Enter valid data");
									}
								}
							}
						}
					}
				}
				dilog3.setTitle("Congratulation!");
				dilog3.setMessage("  Your GPA is ".concat(gpa.getText().toString()));
				dilog3.setPositiveButton("OK", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
				
					}
				});
				dilog3.create().show();
				gpa_file.edit().putString("gpa", "0").commit();
				blink.cancel();
			}
		});
		share_result.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				showMessage("Sharing result");
				share_result.setAlpha((float)(Double.parseDouble(".2")));
				t = new TimerTask() {
							@Override
								public void run() {
									runOnUiThread(new Runnable() {
									@Override
										public void run() {
														share_result.setAlpha((float)(Double.parseDouble("1")));
										}
									});
								}
							};
							_timer.schedule(t, (int)(150));
				a = "Hey! My GPA is ".concat(gpa.getText().toString());
				Intent i = new Intent(android.content.Intent.ACTION_SEND); i.setType("text/plain");  i.putExtra(android.content.Intent.EXTRA_TEXT, a); startActivity(Intent.createChooser(i,"Share using"));
			}
		});
		spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView _parent, View _view, final int _position, long _id) { 
				_Enter_Subject_Number();
				_check_colors();
				if (_position == 0) {
					file.edit().putString("subject", share.getString("subject", "")).commit();
					if (vibration.getString("click", "").equals("1")) {
						vib.vibrate((long)(0));
					}
					else {
						if (vibration.getString("click", "").equals("2")) {
							vib.vibrate((long)(100));
						}
					}
					_Reset();
					ch_sub1.setText("");
					ch_sub2.setText("");
					ch_sub3.setText("");
					ch_sub4.setText("");
					ch_sub5.setText("");
					ch_sub6.setText("");
					no1.setText("");
					no2.setText("");
					no3.setText("");
					no4.setText("");
					no5.setText("");
					no6.setText("");
					grade1.setText("");
					grade2.setText("");
					grade3.setText("");
					grade4.setText("");
					grade5.setText("");
					grade6.setText("");
					subject1.setBackgroundResource(R.drawable.sub1);
					subject3.setBackgroundResource(R.drawable.sub3);
					subject2.setBackgroundResource(R.drawable.sub2);
					subject4.setBackgroundResource(R.drawable.sub4);
					subject5.setBackgroundResource(R.drawable.sub5);
					subject6.setBackgroundResource(R.drawable.sub6);
					((ArrayAdapter)spinner1.getAdapter()).notifyDataSetChanged();
					_Enter_Subject_Number();
					_check_colors();
					_enable_input();
					_check_all();
					_mode();
				}
				if (_position == 1) {
					if (vibration.getString("click", "").equals("1")) {
						vib.vibrate((long)(0));
					}
					else {
						if (vibration.getString("click", "").equals("2")) {
							vib.vibrate((long)(100));
						}
					}
					file.edit().putString("subject", "").commit();
					subject1.setBackgroundResource(R.drawable.sub1);
					subject3.setBackgroundResource(R.drawable.sub3);
					subject2.setBackgroundResource(R.drawable.sub2);
					subject4.setBackgroundResource(R.drawable.sub4);
					subject5.setBackgroundResource(R.drawable.sub5);
					subject6.setBackgroundResource(R.drawable.sub6);
					points1.setVisibility(View.VISIBLE);
					points2.setVisibility(View.VISIBLE);
					points3.setVisibility(View.VISIBLE);
					points4.setVisibility(View.VISIBLE);
					points5.setVisibility(View.VISIBLE);
					points6.setVisibility(View.VISIBLE);
					((ArrayAdapter)spinner1.getAdapter()).notifyDataSetChanged();
					_enable_input();
					i4.setClass(getApplicationContext(), WelcomeActivity.class);
					startActivity(i4);
					finish();
				}
				if (_position == 2) {
					file.edit().putString("subject", "6").commit();
					if (vibration.getString("click", "").equals("1")) {
						vib.vibrate((long)(0));
					}
					else {
						if (vibration.getString("click", "").equals("2")) {
							vib.vibrate((long)(100));
						}
					}
					no1.setEnabled(true);
					no2.setEnabled(true);
					no3.setEnabled(true);
					no4.setEnabled(true);
					no5.setEnabled(true);
					no6.setEnabled(true);
					ch_sub1.setEnabled(false);
					ch_sub2.setEnabled(false);
					ch_sub3.setEnabled(false);
					ch_sub4.setEnabled(false);
					ch_sub5.setEnabled(false);
					ch_sub6.setEnabled(false);
					subject1.setBackgroundResource(R.drawable.se402);
					subject2.setBackgroundResource(R.drawable.cs402);
					subject3.setBackgroundResource(R.drawable.stat402);
					subject4.setBackgroundResource(R.drawable.cs408);
					subject5.setBackgroundResource(R.drawable.math402);
					subject6.setBackgroundResource(R.drawable.ssh302);
					((ArrayAdapter)spinner1.getAdapter()).notifyDataSetChanged();
					ch_sub1.setText("3");
					ch_sub2.setText("3");
					ch_sub3.setText("3");
					ch_sub4.setText("3");
					ch_sub5.setText("3");
					ch_sub6.setText("2");
					linear_al_expt_welcm.setVisibility(View.VISIBLE);
					allign_gpa_message.setVisibility(View.GONE);
					no1.setText("");
					no2.setText("");
					no3.setText("");
					no4.setText("");
					no5.setText("");
					no6.setText("");
					grade1.setText("");
					grade2.setText("");
					grade3.setText("");
					grade4.setText("");
					grade5.setText("");
					grade6.setText("");
					points1.setText("");
					points2.setText("");
					points3.setText("");
					points4.setText("");
					points5.setText("");
					points6.setText("");
					_visible_all();
					if (gpa_file.getString("gpa", "").equals("0")) {
						showMessage("Reset data first");
					}
					_Enter_Subject_Number();
					_mode();
					_check_all();
					_check_colors();
				}
				if (vibration.getString("click", "").equals("1")) {
					vib.vibrate((long)(0));
				}
				else {
					if (vibration.getString("click", "").equals("2")) {
						vib.vibrate((long)(100));
					}
				}
			}
			@Override
			public void onNothingSelected(AdapterView _parent) { 
			}
		});
		ch_sub1.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence _text, int _start, int _count, int _after) {
			}
			@Override
			public void onTextChanged(final CharSequence _charSeq, int _start, int _before, int _count) {
				if (ch_sub1.getText().toString().length() > 1) {
					showMessage("invalid! Enter 1-digit data only");
					ch_sub1.setText("");
				}
				else {
					if ((!ch_sub1.getText().toString().equals("") && (Double.parseDouble(ch_sub1.getText().toString()) < 1)) && (Double.parseDouble(ch_sub1.getText().toString()) > 4)) {
						showMessage("invalid! Enter 1-digit data only");
						ch_sub1.setText("");
					}
				}
			}
			@Override
			public void afterTextChanged(Editable _text) {
			}
		});
		ch_sub4.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence _text, int _start, int _count, int _after) {
			}
			@Override
			public void onTextChanged(final CharSequence _charSeq, int _start, int _before, int _count) {
				if (ch_sub4.getText().toString().length() > 1) {
					ch_sub4.setText("");
					showMessage("invalid! Enter 1-digit data only");
				}
				else {
					if ((!ch_sub4.getText().toString().equals("") && (Double.parseDouble(ch_sub4.getText().toString()) < 1)) && (Double.parseDouble(ch_sub4.getText().toString()) > 4)) {
						ch_sub4.setText("");
						showMessage("invalid! Enter 1-digit data only");
					}
				}
			}
			@Override
			public void afterTextChanged(Editable _text) {
			}
		});
		ch_sub5.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence _text, int _start, int _count, int _after) {
			}
			@Override
			public void onTextChanged(final CharSequence _charSeq, int _start, int _before, int _count) {
				if (ch_sub5.getText().toString().length() > 1) {
					ch_sub5.setText("");
					showMessage("invalid! Enter 1-digit data only");
				}
				else {
					if ((!ch_sub5.getText().toString().equals("") && (Double.parseDouble(subject5.getText().toString()) < 1)) && (Double.parseDouble(ch_sub5.getText().toString()) > 4)) {
						ch_sub5.setText("");
						showMessage("invalid! Enter 1-digit data only");
					}
				}
			}
			@Override
			public void afterTextChanged(Editable _text) {
			}
		});
		ch_sub6.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence _text, int _start, int _count, int _after) {
			}
			@Override
			public void onTextChanged(final CharSequence _charSeq, int _start, int _before, int _count) {
				if (ch_sub6.getText().toString().length() > 1) {
					ch_sub6.setText("");
					showMessage("invalid! Enter 1-digit data only");
				}
				else {
					if ((!ch_sub6.getText().toString().equals("") && (Double.parseDouble(ch_sub6.getText().toString()) < 1)) && (Double.parseDouble(ch_sub6.getText().toString()) > 4)) {
						ch_sub6.setText("");
						showMessage("invalid! Enter 1-digit data only");
					}
				}
			}
			@Override
			public void afterTextChanged(Editable _text) {
			}
		});
		ch_sub2.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence _text, int _start, int _count, int _after) {
			}
			@Override
			public void onTextChanged(final CharSequence _charSeq, int _start, int _before, int _count) {
				if (ch_sub2.getText().toString().length() > 1) {
					ch_sub2.setText("");
					showMessage("invalid! Enter 1-digit data only");
				}
				else {
					if ((!ch_sub2.getText().toString().equals("") && (Double.parseDouble(ch_sub2.getText().toString()) < 1)) && (Double.parseDouble(ch_sub2.getText().toString()) > 4)) {
						ch_sub2.setText("");
						showMessage("invalid! Enter 1-digit data only");
					}
				}
			}
			@Override
			public void afterTextChanged(Editable _text) {
			}
		});
		ch_sub3.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence _text, int _start, int _count, int _after) {
			}
			@Override
			public void onTextChanged(final CharSequence _charSeq, int _start, int _before, int _count) {
				if (ch_sub3.getText().toString().length() > 1) {
					ch_sub3.setText("");
					showMessage("invalid! Enter 1-digit data only");
				}
				else {
					if ((!ch_sub3.getText().toString().equals("") && (Double.parseDouble(ch_sub3.getText().toString()) < 1)) && (Double.parseDouble(subject3.getText().toString()) > 4)) {
						ch_sub3.setText("");
						showMessage("invalid! Enter 1-digit data only");
					}
				}
			}
			@Override
			public void afterTextChanged(Editable _text) {
			}
		});
		no1.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence _text, int _start, int _count, int _after) {
			}
			@Override
			public void onTextChanged(final CharSequence _charSeq, int _start, int _before, int _count) {
				if (no1.getText().toString().length() > 2) {
					showMessage("invalid! Enter 2-digit data only");
					no1.setText("");
				}
			}
			@Override
			public void afterTextChanged(Editable _text) {
			}
		});
		no2.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence _text, int _start, int _count, int _after) {
			}
			@Override
			public void onTextChanged(final CharSequence _charSeq, int _start, int _before, int _count) {
				if (no2.getText().toString().length() > 2) {
					no2.setText("");
					showMessage("invalid! Enter 2-digit data only");
				}
			}
			@Override
			public void afterTextChanged(Editable _text) {
			}
		});
		no3.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence _text, int _start, int _count, int _after) {
			}
			@Override
			public void onTextChanged(final CharSequence _charSeq, int _start, int _before, int _count) {
				if (no3.getText().toString().length() > 2) {
					no3.setText("");
					showMessage("invalid! Enter 2-digit data only");
				}
			}
			@Override
			public void afterTextChanged(Editable _text) {
			}
		});
		no4.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence _text, int _start, int _count, int _after) {
			}
			@Override
			public void onTextChanged(final CharSequence _charSeq, int _start, int _before, int _count) {
				if (no4.getText().toString().length() > 2) {
					no4.setText("");
					showMessage("invalid! Enter 2-digit data only");
				}
			}
			@Override
			public void afterTextChanged(Editable _text) {
			}
		});
		no5.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence _text, int _start, int _count, int _after) {
			}
			@Override
			public void onTextChanged(final CharSequence _charSeq, int _start, int _before, int _count) {
				if (no5.getText().toString().length() > 2) {
					no5.setText("");
					showMessage("invalid! Enter 2-digit data only");
				}
			}
			@Override
			public void afterTextChanged(Editable _text) {
			}
		});
		no6.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence _text, int _start, int _count, int _after) {
			}
			@Override
			public void onTextChanged(final CharSequence _charSeq, int _start, int _before, int _count) {
				if (no6.getText().toString().length() > 2) {
					no6.setText("");
					showMessage("invalid! Enter 2-digit data only");
				}
			}
			@Override
			public void afterTextChanged(Editable _text) {
			}
		});
		points1.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence _text, int _start, int _count, int _after) {
			}
			@Override
			public void onTextChanged(final CharSequence _charSeq, int _start, int _before, int _count) {
				_check_colors();
			}
			@Override
			public void afterTextChanged(Editable _text) {
			}
		});
		points2.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence _text, int _start, int _count, int _after) {
			}
			@Override
			public void onTextChanged(final CharSequence _charSeq, int _start, int _before, int _count) {
				_check_colors();
			}
			@Override
			public void afterTextChanged(Editable _text) {
			}
		});
		points3.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence _text, int _start, int _count, int _after) {
			}
			@Override
			public void onTextChanged(final CharSequence _charSeq, int _start, int _before, int _count) {
				_check_colors();
			}
			@Override
			public void afterTextChanged(Editable _text) {
			}
		});
		points4.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence _text, int _start, int _count, int _after) {
			}
			@Override
			public void onTextChanged(final CharSequence _charSeq, int _start, int _before, int _count) {
				_check_colors();
			}
			@Override
			public void afterTextChanged(Editable _text) {
			}
		});
		points5.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence _text, int _start, int _count, int _after) {
			}
			@Override
			public void onTextChanged(final CharSequence _charSeq, int _start, int _before, int _count) {
				_check_colors();
			}
			@Override
			public void afterTextChanged(Editable _text) {
			}
		});
		points6.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence _text, int _start, int _count, int _after) {
			}
			@Override
			public void onTextChanged(final CharSequence _charSeq, int _start, int _before, int _count) {
				_check_colors();
			}
			@Override
			public void afterTextChanged(Editable _text) {
			}
		});

	}

	private void  initializeLogic() {
		
getActionBar().setTitle("GPA Calculator");
		_mode();
		if (share.getString("mode", "").equals("")) {
			share.edit().putString("mode", "0").commit();
		}
		if (share.getString("close", "").equals("1")) {
			finish();
		}
		share.edit().putString("pop", "1").commit();
		if (file.getString("subject", "").equals("")) {
			i4.setClass(getApplicationContext(), WelcomeActivity.class);
			startActivity(i4);
		}
		else {
			if (file.getString("subject", "").equals("4") || (file.getString("subject", "").equals("5") || file.getString("subject", "").equals("6"))) {
				_Enter_Subject_Number();
				share.edit().putString("main", "1").commit();
			}
		}
		list.add("No degree selected");
		list.add("Select subjects");
		list.add("BS (Software Engineering)");
		spinner1.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, list));
		allign_reset_calcula.setVisibility(View.GONE);
		share_result.setVisibility(View.GONE);
		help.setTitle("Valid data input");
		help.setMessage("■Credit Hours 1~4\n□Credit Hour 1: Numbers 8~20\n□Credit Hour 2: Numbers 16~40\n□Credit Hour 3: Numbers 24~60\n□Credit Hour 4: Numbers 32~80\n■Wrong input will lead to wrong result");
		help.setPositiveButton("ok", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
		
			}
		});
		help.setNegativeButton("contact us", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
							whatsappgroup.setAction(Intent.ACTION_VIEW);
					whatsappgroup.setData(Uri.parse("https://chat.whatsapp.com/7mWDfkHrDab24WYtMUqCZt"));
					startActivity(whatsappgroup);
			}
		});
		help.create().show();
		_numbers();
		 }
@Override
public boolean onCreateOptionsMenu(Menu menu){


menu.add("Share App").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);


menu.add("About us").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);

menu.add("Settings").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
menu.add("Help").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
return true;
}

@Override 
public boolean onOptionsItemSelected(final MenuItem item) {
switch (item.getTitle().toString()) {
case "Share App":
showMessage("Sharing App");


pkg="com.uafcgpa";
 String apk = "";
String uri = (pkg);
try {
android.content.pm.PackageInfo pi = getPackageManager().getPackageInfo(uri, android.content.pm.PackageManager.GET_ACTIVITIES);
apk = pi.applicationInfo.publicSourceDir;
} catch (Exception e) { showMessage(e.toString());}
Intent iten = new Intent(Intent.ACTION_SEND);
iten.setType("*/*");
iten.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(new java.io.File(apk)));
startActivity(Intent.createChooser(iten, "Share App")); 
return true;
case "Settings":
showMessage("Settings");
i4.setClass(getApplicationContext(),SettingsActivity.class);
startActivity (i4);

return true;
case "Help":
showMessage("Help");
i.setClass(getApplicationContext(),HelpActivity.class);
startActivity (i);
return true;
case "About us":
showMessage("UAF Developers");
i.setClass(getApplicationContext(),AboutActivity.class);
startActivity (i);
return true;
default:
return super.onOptionsItemSelected(item);
}
	}

	@Override
	public void onBackPressed() {
				dilog1.setTitle("Exit");
				dilog1.setMessage("Do you really want to exit?");
				dilog1.setPositiveButton("YES", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
											share.edit().putString("pop", "").commit();
							finishAffinity ();
					}
				});
				dilog1.setNegativeButton("No", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
				
					}
				});
				dilog1.create().show();
	}
	@Override
	public void onDestroy() {
		super.onDestroy();

	}
	@Override
	public void onStop() {
		super.onStop();

	}
	@Override
	public void onResume() {
		super.onResume();
				_mode();
	}

	private void _ch1 () {
		if (ch_sub1.getText().toString().equals("") || no1.getText().toString().equals("")) {

		}
		else {
			if ((Double.parseDouble(ch_sub1.getText().toString()) == 1) && (Double.parseDouble(no1.getText().toString()) == 8)) {
				points1.setText("1");
				grade1.setText("D");
			}
			else {
				if ((Double.parseDouble(ch_sub1.getText().toString()) == 1) && (Double.parseDouble(no1.getText().toString()) == 9)) {
					points1.setText("1.5");
					grade1.setText("D");
				}
				else {
					if ((Double.parseDouble(ch_sub1.getText().toString()) == 1) && (Double.parseDouble(no1.getText().toString()) == 10)) {
						points1.setText("2");
						grade1.setText("C");
					}
					else {
						if ((Double.parseDouble(ch_sub1.getText().toString()) == 1) && (Double.parseDouble(no1.getText().toString()) == 11)) {
							points1.setText("2.33");
							grade1.setText("C");
						}
						else {
							if ((Double.parseDouble(ch_sub1.getText().toString()) == 1) && (Double.parseDouble(no1.getText().toString()) == 12)) {
								points1.setText("2.67");
								grade1.setText("C");
							}
							else {
								if ((Double.parseDouble(ch_sub1.getText().toString()) == 1) && (Double.parseDouble(no1.getText().toString()) == 13)) {
									points1.setText("3");
									grade1.setText("B");
								}
								else {
									if ((Double.parseDouble(ch_sub1.getText().toString()) == 1) && (Double.parseDouble(no1.getText().toString()) == 14)) {
										points1.setText("3.33");
										grade1.setText("B");
									}
									else {
										if ((Double.parseDouble(ch_sub1.getText().toString()) == 1) && (Double.parseDouble(no1.getText().toString()) == 15)) {
											points1.setText("3.67");
											grade1.setText("B");
										}
										else {
											if ((Double.parseDouble(ch_sub1.getText().toString()) == 1) && (Double.parseDouble(no1.getText().toString()) == 16)) {
												points1.setText("4");
												grade1.setText("A");
											}
											else {
												if ((Double.parseDouble(ch_sub1.getText().toString()) == 1) && (Double.parseDouble(no1.getText().toString()) == 17)) {
													points1.setText("4");
													grade1.setText("A");
												}
												else {
													if ((Double.parseDouble(ch_sub1.getText().toString()) == 1) && (Double.parseDouble(no1.getText().toString()) == 18)) {
														points1.setText("4");
														grade1.setText("A");
													}
													else {
														if ((Double.parseDouble(ch_sub1.getText().toString()) == 1) && (Double.parseDouble(no1.getText().toString()) == 19)) {
															points1.setText("4");
															grade1.setText("A");
														}
														else {
															if ((Double.parseDouble(ch_sub1.getText().toString()) == 1) && (Double.parseDouble(no1.getText().toString()) == 20)) {
																points1.setText("4");
																grade1.setText("A");
															}
															else {
																_check_colors();
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	private void _ch2 () {
		if (ch_sub1.getText().toString().equals("") || no1.getText().toString().equals("")) {

		}
		else {
			if ((Double.parseDouble(ch_sub1.getText().toString()) == 2) && (Double.parseDouble(no1.getText().toString()) == 16)) {
				points1.setText("2");
				grade1.setText("D");
			}
			else {
				if ((Double.parseDouble(ch_sub1.getText().toString()) == 2) && (Double.parseDouble(no1.getText().toString()) == 17)) {
					points1.setText("2.5");
					grade1.setText("D");
				}
				else {
					if ((Double.parseDouble(ch_sub1.getText().toString()) == 2) && (Double.parseDouble(no1.getText().toString()) == 18)) {
						points1.setText("3");
						grade1.setText("D");
					}
					else {
						if ((Double.parseDouble(ch_sub1.getText().toString()) == 2) && (Double.parseDouble(no1.getText().toString()) == 19)) {
							points1.setText("3.5");
							grade1.setText("D");
						}
						else {
							if ((Double.parseDouble(ch_sub1.getText().toString()) == 2) && (Double.parseDouble(no1.getText().toString()) == 20)) {
								points1.setText("4");
								grade1.setText("C");
							}
							else {
								if ((Double.parseDouble(ch_sub1.getText().toString()) == 2) && (Double.parseDouble(no1.getText().toString()) == 21)) {
									points1.setText("4.33");
									grade1.setText("C");
								}
								else {
									if ((Double.parseDouble(ch_sub1.getText().toString()) == 2) && (Double.parseDouble(no1.getText().toString()) == 22)) {
										points1.setText("4.67");
										grade1.setText("C");
									}
									else {
										if ((Double.parseDouble(ch_sub1.getText().toString()) == 2) && (Double.parseDouble(no1.getText().toString()) == 23)) {
											points1.setText("5");
											grade1.setText("C");
										}
										else {
											if ((Double.parseDouble(ch_sub1.getText().toString()) == 2) && (Double.parseDouble(no1.getText().toString()) == 24)) {
												points1.setText("5.33");
												grade1.setText("C");
											}
											else {
												if ((Double.parseDouble(ch_sub1.getText().toString()) == 2) && (Double.parseDouble(no1.getText().toString()) == 25)) {
													points1.setText("5.67");
													grade1.setText("C");
												}
												else {
													if ((Double.parseDouble(ch_sub1.getText().toString()) == 2) && (Double.parseDouble(no1.getText().toString()) == 26)) {
														points1.setText("6");
														grade1.setText("B");
													}
													else {
														if ((Double.parseDouble(ch_sub1.getText().toString()) == 2) && (Double.parseDouble(no1.getText().toString()) == 27)) {
															points1.setText("6.33");
															grade1.setText("B");
														}
														else {
															if ((Double.parseDouble(ch_sub1.getText().toString()) == 2) && (Double.parseDouble(no1.getText().toString()) == 28)) {
																points1.setText("6.67");
																grade1.setText("B");
															}
															else {
																if ((Double.parseDouble(ch_sub1.getText().toString()) == 2) && (Double.parseDouble(no1.getText().toString()) == 29)) {
																	points1.setText("7");
																	grade1.setText("B");
																}
																else {
																	if ((Double.parseDouble(ch_sub1.getText().toString()) == 2) && (Double.parseDouble(no1.getText().toString()) == 30)) {
																		points1.setText("7.33");
																		grade1.setText("B");
																	}
																	else {
																		if ((Double.parseDouble(ch_sub1.getText().toString()) == 2) && (Double.parseDouble(no1.getText().toString()) == 31)) {
																			points1.setText("7.67");
																			grade1.setText("B");
																		}
																		else {
																			if ((Double.parseDouble(ch_sub1.getText().toString()) == 2) && (Double.parseDouble(no1.getText().toString()) == 32)) {
																				points1.setText("8");
																				grade1.setText("A");
																			}
																			else {
																				if ((Double.parseDouble(ch_sub1.getText().toString()) == 2) && (Double.parseDouble(no1.getText().toString()) == 33)) {
																					points1.setText("8");
																					grade1.setText("A");
																				}
																				else {
																					if ((Double.parseDouble(ch_sub1.getText().toString()) == 2) && (Double.parseDouble(no1.getText().toString()) == 34)) {
																						points1.setText("8");
																						grade1.setText("A");
																					}
																					else {
																						if ((Double.parseDouble(ch_sub1.getText().toString()) == 2) && (Double.parseDouble(no1.getText().toString()) == 35)) {
																							points1.setText("8");
																							grade1.setText("A");
																						}
																						else {
																							if ((Double.parseDouble(ch_sub1.getText().toString()) == 2) && (Double.parseDouble(no1.getText().toString()) == 36)) {
																								points1.setText("8");
																								grade1.setText("A");
																							}
																							else {
																								if ((Double.parseDouble(ch_sub1.getText().toString()) == 2) && (Double.parseDouble(no1.getText().toString()) == 37)) {
																									points1.setText("8");
																									grade1.setText("A");
																								}
																								else {
																									if ((Double.parseDouble(ch_sub1.getText().toString()) == 2) && (Double.parseDouble(no1.getText().toString()) == 38)) {
																										points1.setText("8");
																										grade1.setText("A");
																									}
																									else {
																										if ((Double.parseDouble(ch_sub1.getText().toString()) == 2) && (Double.parseDouble(no1.getText().toString()) == 39)) {
																											points1.setText("8");
																											grade1.setText("A");
																										}
																										else {
																											if ((Double.parseDouble(ch_sub1.getText().toString()) == 2) && (Double.parseDouble(no1.getText().toString()) == 40)) {
																												points1.setText("8");
																												grade1.setText("A");
																											}
																											else {
																												_check_colors();
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		_check_colors();
	}
	private void _ch3 () {
		if (ch_sub1.getText().toString().equals("") || no1.getText().toString().equals("")) {

		}
		else {
			if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 24)) {
				points1.setText("3");
				grade1.setText("D");
			}
			else {
				if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 25)) {
					points1.setText("3.5");
					grade1.setText("D");
				}
				else {
					if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 26)) {
						points1.setText("4");
						grade1.setText("D");
					}
					else {
						if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 27)) {
							points1.setText("4.5");
							grade1.setText("D");
						}
						else {
							if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 28)) {
								points1.setText("5");
								grade1.setText("D");
							}
							else {
								if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 29)) {
									points1.setText("5.5");
									grade1.setText("D");
								}
								else {
									if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 30)) {
										points1.setText("6");
										grade1.setText("C");
									}
									else {
										if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 31)) {
											points1.setText("6.33");
											grade1.setText("C");
										}
										else {
											if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 32)) {
												points1.setText("6.67");
												grade1.setText("C");
											}
											else {
												if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 33)) {
													points1.setText("7");
													grade1.setText("C");
												}
												else {
													if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 34)) {
														points1.setText("7.33");
														grade1.setText("C");
													}
													else {
														if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 35)) {
															points1.setText("7.67");
															grade1.setText("C");
														}
														else {
															if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 36)) {
																points1.setText("8");
																grade1.setText("C");
															}
															else {
																if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 37)) {
																	points1.setText("8.33");
																	grade1.setText("C");
																}
																else {
																	if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 38)) {
																		points1.setText("8.67");
																		grade1.setText("C");
																	}
																	else {
																		if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 39)) {
																			points1.setText("9");
																			grade1.setText("B");
																		}
																		else {
																			if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 40)) {
																				points1.setText("9.33");
																				grade1.setText("B");
																			}
																			else {
																				if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 41)) {
																					points1.setText("9.67");
																					grade1.setText("B");
																				}
																				else {
																					if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 42)) {
																						points1.setText("10");
																						grade1.setText("B");
																					}
																					else {
																						if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 43)) {
																							points1.setText("10.33");
																							grade1.setText("B");
																						}
																						else {
																							if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 44)) {
																								points1.setText("10.67");
																								grade1.setText("B");
																							}
																							else {
																								if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 45)) {
																									points1.setText("11");
																									grade1.setText("B");
																								}
																								else {
																									if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 46)) {
																										points1.setText("11.33");
																										grade1.setText("B");
																									}
																									else {
																										if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 47)) {
																											points1.setText("11.67");
																											grade1.setText("B");
																										}
																										else {
																											if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 48)) {
																												points1.setText("12");
																												grade1.setText("A");
																											}
																											else {
																												if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 49)) {
																													points1.setText("12");
																													grade1.setText("A");
																												}
																												else {
																													if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 50)) {
																														points1.setText("12");
																														grade1.setText("A");
																													}
																													else {
																														if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 51)) {
																															points1.setText("12");
																															grade1.setText("A");
																														}
																														else {
																															if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 52)) {
																																points1.setText("12");
																																grade1.setText("A");
																															}
																															else {
																																if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 53)) {
																																	points1.setText("12");
																																	grade1.setText("A");
																																}
																																else {
																																	if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 54)) {
																																		points1.setText("12");
																																		grade1.setText("A");
																																	}
																																	else {
																																		if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 55)) {
																																			points1.setText("12");
																																			grade1.setText("A");
																																		}
																																		else {
																																			if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 56)) {
																																				points1.setText("12");
																																				grade1.setText("A");
																																			}
																																			else {
																																				if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 57)) {
																																					points1.setText("12");
																																					grade1.setText("A");
																																				}
																																				else {
																																					if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 58)) {
																																						points1.setText("12");
																																						grade1.setText("A");
																																					}
																																					else {
																																						if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 59)) {
																																							points1.setText("12");
																																							grade1.setText("A");
																																						}
																																						else {
																																							if ((Double.parseDouble(ch_sub1.getText().toString()) == 3) && (Double.parseDouble(no1.getText().toString()) == 60)) {
																																								points1.setText("12");
																																								grade1.setText("A");
																																							}
																																							else {
																																								_check_colors();
																																							}
																																						}
																																					}
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	private void _ch4 () {
		if (ch_sub1.getText().toString().equals("") || no1.getText().toString().equals("")) {

		}
		else {
			if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 32)) {
				points1.setText("4");
				grade1.setText("D");
			}
			else {
				if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 33)) {
					points1.setText("4.5");
					grade1.setText("D");
				}
				else {
					if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 34)) {
						points1.setText("5");
						grade1.setText("D");
					}
					else {
						if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 35)) {
							points1.setText("5.5");
							grade1.setText("D");
						}
						else {
							if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 36)) {
								points1.setText("6");
								grade1.setText("D");
							}
							else {
								if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 37)) {
									points1.setText("6.5");
									grade1.setText("D");
								}
								else {
									if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 38)) {
										points1.setText("7");
										grade1.setText("D");
									}
									else {
										if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 39)) {
											points1.setText("7.5");
											grade1.setText("D");
										}
										else {
											if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 40)) {
												points1.setText("8");
												grade1.setText("C");
											}
											else {
												if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 41)) {
													points1.setText("8.33");
													grade1.setText("C");
												}
												else {
													if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 42)) {
														points1.setText("8.67");
														grade1.setText("C");
													}
													else {
														if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 43)) {
															points1.setText("9");
															grade1.setText("C");
														}
														else {
															if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 44)) {
																points1.setText("9.33");
																grade1.setText("C");
															}
															else {
																if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 45)) {
																	points1.setText("9.67");
																	grade1.setText("C");
																}
																else {
																	if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 46)) {
																		points1.setText("10");
																		grade1.setText("C");
																	}
																	else {
																		if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 47)) {
																			points1.setText("10.33");
																			grade1.setText("C");
																		}
																		else {
																			if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 48)) {
																				points1.setText("10.67");
																				grade1.setText("C");
																			}
																			else {
																				if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 49)) {
																					points1.setText("11");
																					grade1.setText("C");
																				}
																				else {
																					if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 50)) {
																						points1.setText("11.33");
																						grade1.setText("C");
																					}
																					else {
																						if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 51)) {
																							points1.setText("11.67");
																							grade1.setText("C");
																						}
																						else {
																							if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 52)) {
																								points1.setText("12");
																								grade1.setText("B");
																							}
																							else {
																								if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 53)) {
																									points1.setText("12.33");
																									grade1.setText("B");
																								}
																								else {
																									if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 54)) {
																										points1.setText("12.67");
																										grade1.setText("B");
																									}
																									else {
																										if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 55)) {
																											points1.setText("13");
																											grade1.setText("B");
																										}
																										else {
																											if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 56)) {
																												points1.setText("13.33");
																												grade1.setText("B");
																											}
																											else {
																												if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 57)) {
																													points1.setText("13.67");
																													grade1.setText("B");
																												}
																												else {
																													if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 58)) {
																														points1.setText("14");
																														grade1.setText("B");
																													}
																													else {
																														if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 59)) {
																															points1.setText("14.33");
																															grade1.setText("B");
																														}
																														else {
																															if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 60)) {
																																points1.setText("14.67");
																																grade1.setText("B");
																															}
																															else {
																																if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 61)) {
																																	points1.setText("15");
																																	grade1.setText("B");
																																}
																																else {
																																	if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 62)) {
																																		points1.setText("15.33");
																																		grade1.setText("B");
																																	}
																																	else {
																																		if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 63)) {
																																			points1.setText("15.67");
																																			grade1.setText("B");
																																		}
																																		else {
																																			if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 64)) {
																																				points1.setText("16");
																																				grade1.setText("A");
																																			}
																																			else {
																																				if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 65)) {
																																					points1.setText("16");
																																					grade1.setText("A");
																																				}
																																				else {
																																					if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 66)) {
																																						points1.setText("16");
																																						grade1.setText("A");
																																					}
																																					else {
																																						if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 67)) {
																																							points1.setText("16");
																																							grade1.setText("A");
																																						}
																																						else {
																																							if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 68)) {
																																								points1.setText("16");
																																								grade1.setText("A");
																																							}
																																							else {
																																								if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 69)) {
																																									points1.setText("16");
																																									grade1.setText("A");
																																								}
																																								else {
																																									if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 70)) {
																																										points1.setText("16");
																																										grade1.setText("A");
																																									}
																																									else {
																																										if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 71)) {
																																											points1.setText("16");
																																											grade1.setText("A");
																																										}
																																										else {
																																											if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 72)) {
																																												points1.setText("16");
																																												grade1.setText("A");
																																											}
																																											else {
																																												if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 73)) {
																																													points1.setText("16");
																																													grade1.setText("A");
																																												}
																																												else {
																																													if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 74)) {
																																														points1.setText("16");
																																														grade1.setText("A");
																																													}
																																													else {
																																														if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 75)) {
																																															points1.setText("16");
																																															grade1.setText("A");
																																														}
																																														else {
																																															if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 76)) {
																																																points1.setText("16");
																																																grade1.setText("A");
																																															}
																																															else {
																																																if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 77)) {
																																																	points1.setText("16");
																																																	grade1.setText("A");
																																																}
																																																else {
																																																	if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 78)) {
																																																		points1.setText("16");
																																																		grade1.setText("A");
																																																	}
																																																	else {
																																																		if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 79)) {
																																																			points1.setText("16");
																																																			grade1.setText("A");
																																																		}
																																																		else {
																																																			if ((Double.parseDouble(ch_sub1.getText().toString()) == 4) && (Double.parseDouble(no1.getText().toString()) == 80)) {
																																																				points1.setText("16");
																																																				grade1.setText("A");
																																																			}
																																																			else {
																																																				_check_colors();
																																																			}
																																																		}
																																																	}
																																																}
																																															}
																																														}
																																													}
																																												}
																																											}
																																										}
																																									}
																																								}
																																							}
																																						}
																																					}
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	private void _ch5 () {

	}
	private void _check_General () {
		if ((Double.parseDouble(ch_sub1.getText().toString()) > 5) || ((Double.parseDouble(ch_sub1.getText().toString()) == 0) || (ch_sub1.getText().toString().equals("") || no1.getText().toString().equals("")))) {
			ch_sub1.setText("");
			dilog1.setTitle("Invalid data");
			dilog1.setMessage("Valid Credits data 1~5");
			dilog1.setPositiveButton("OK", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
			
				}
			});
			dilog1.create().show();
		}
	}
	private void _check_ch1 () {
		if (file.getString("", "").equals("4")) {
			if ((ch_sub1.getText().toString().equals("1") || (ch_sub2.getText().toString().equals("1") || (ch_sub3.getText().toString().equals("1") || ch_sub4.getText().toString().equals("1")))) && (((Double.parseDouble(no1.getText().toString()) > 20) || ((Double.parseDouble(no2.getText().toString()) > 20) || ((Double.parseDouble(no3.getText().toString()) > 20) || (Double.parseDouble(no4.getText().toString()) > 20)))) || ((Double.parseDouble(no1.getText().toString()) < 8) || ((Double.parseDouble(no2.getText().toString()) < 8) || ((Double.parseDouble(no3.getText().toString()) < 8) || (Double.parseDouble(no4.getText().toString()) < 8)))))) {
				if (ch_sub1.getText().toString().equals("1")) {
					no1.setText("");
					dilog1.setTitle("Invalid Numbers");
					dilog1.setMessage("Valid Numbers data 8~20");
					dilog1.setPositiveButton("OK", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
					
						}
					});
					dilog1.create().show();
				}
			}
		}
	}
	private void _check_ch2 () {
		if (ch_sub1.getText().toString().equals("2") && ((Double.parseDouble(no1.getText().toString()) > 40) || ((Double.parseDouble(no1.getText().toString()) < 16) || (ch_sub1.getText().toString().equals("") || no1.getText().toString().equals(""))))) {
			no1.setText("");
			dilog1.setTitle("Invalid data");
			dilog1.setMessage("Valid Numbers 16~40");
			dilog1.setPositiveButton("OK", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
			
				}
			});
			dilog1.create().show();
		}
	}
	private void _check_ch3 () {
		if (ch_sub1.getText().toString().equals("3") && ((Double.parseDouble(no1.getText().toString()) > 60) || ((Double.parseDouble(no1.getText().toString()) < 24) || (ch_sub1.getText().toString().equals("") || no1.getText().toString().equals(""))))) {
			no1.setText("");
			dilog1.setTitle("Invalid Numbers");
			dilog1.setMessage("Valid Numbers data 24~60");
			dilog1.setPositiveButton("OK", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
			
				}
			});
			dilog1.create().show();
		}
	}
	private void _check_ch4 () {
		if (!(points1.getText().toString().equals("") || (points2.getText().toString().equals("") || (points3.getText().toString().equals("") || (points4.getText().toString().equals("") || (grade5.getText().toString().equals("") || points6.getText().toString().equals(""))))))) {
			set = String.valueOf(Double.parseDouble(points2.getText().toString()));
			set = String.valueOf(Double.parseDouble(points2.getText().toString()));

			showMessage("Please fill all subjects data");
		}
		else {

		}
		CrH2 = String.valueOf((long)(p1 + (p2 + (0 + (p4 + (p5 + p6))))));
	}
	private void _check_ch5 () {
		if (ch_sub1.getText().toString().length() == 0) {
			ch_sub1.setText("");
		}
	}
	private void _check_ch6 () {

	}
	private void _sub2 () {
		if (ch_sub2.getText().toString().equals("") || no2.getText().toString().equals("")) {

		}
		else {
			points2.setTextColor(0xFFFFFFFF);
			if ((Double.parseDouble(ch_sub2.getText().toString()) == 1) && (Double.parseDouble(no2.getText().toString()) == 8)) {
				points2.setText("1");
				grade2.setText("D");
			}
			else {
				if ((Double.parseDouble(ch_sub2.getText().toString()) == 1) && (Double.parseDouble(no2.getText().toString()) == 9)) {
					points2.setText("1.5");
					grade2.setText("D");
				}
				else {
					if ((Double.parseDouble(ch_sub2.getText().toString()) == 1) && (Double.parseDouble(no1.getText().toString()) == 10)) {
						points2.setText("2");
						grade2.setText("C");
					}
					else {
						if ((Double.parseDouble(ch_sub2.getText().toString()) == 1) && (Double.parseDouble(no2.getText().toString()) == 11)) {
							points2.setText("2.33");
							grade2.setText("C");
						}
						else {
							if ((Double.parseDouble(ch_sub2.getText().toString()) == 1) && (Double.parseDouble(no2.getText().toString()) == 12)) {
								points2.setText("2.67");
								grade2.setText("C");
							}
							else {
								if ((Double.parseDouble(ch_sub2.getText().toString()) == 1) && (Double.parseDouble(no2.getText().toString()) == 13)) {
									points2.setText("3");
									grade2.setText("B");
								}
								else {
									if ((Double.parseDouble(ch_sub2.getText().toString()) == 1) && (Double.parseDouble(no2.getText().toString()) == 14)) {
										points2.setText("3.33");
										grade2.setText("B");
									}
									else {
										if ((Double.parseDouble(ch_sub2.getText().toString()) == 1) && (Double.parseDouble(no2.getText().toString()) == 15)) {
											points2.setText("3.67");
											grade2.setText("B");
										}
										else {
											if ((Double.parseDouble(ch_sub2.getText().toString()) == 1) && (Double.parseDouble(no2.getText().toString()) == 16)) {
												points2.setText("4");
												grade2.setText("A");
											}
											else {
												if ((Double.parseDouble(ch_sub2.getText().toString()) == 1) && (Double.parseDouble(no2.getText().toString()) == 17)) {
													points2.setText("4");
													grade2.setText("A");
												}
												else {
													if ((Double.parseDouble(ch_sub2.getText().toString()) == 1) && (Double.parseDouble(no2.getText().toString()) == 18)) {
														points2.setText("4");
														grade2.setText("A");
													}
													else {
														if ((Double.parseDouble(ch_sub2.getText().toString()) == 1) && (Double.parseDouble(no2.getText().toString()) == 19)) {
															points2.setText("4");
															grade2.setText("A");
														}
														else {
															if ((Double.parseDouble(ch_sub2.getText().toString()) == 1) && (Double.parseDouble(no2.getText().toString()) == 20)) {
																points2.setText("4");
																grade2.setText("A");
															}
															else {
																_check_colors();
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	private void _sub2_ch2 () {
		if (ch_sub2.getText().toString().equals("") || no2.getText().toString().equals("")) {

		}
		else {
			if ((Double.parseDouble(ch_sub2.getText().toString()) == 2) && (Double.parseDouble(no2.getText().toString()) == 16)) {
				points2.setText("2");
				grade2.setText("D");
			}
			else {
				if ((Double.parseDouble(ch_sub2.getText().toString()) == 2) && (Double.parseDouble(no2.getText().toString()) == 17)) {
					points2.setText("2.5");
					grade2.setText("D");
				}
				else {
					if ((Double.parseDouble(ch_sub2.getText().toString()) == 2) && (Double.parseDouble(no2.getText().toString()) == 18)) {
						points2.setText("3");
						grade2.setText("D");
					}
					else {
						if ((Double.parseDouble(ch_sub2.getText().toString()) == 2) && (Double.parseDouble(no2.getText().toString()) == 19)) {
							points2.setText("3.5");
							grade2.setText("D");
						}
						else {
							if ((Double.parseDouble(ch_sub2.getText().toString()) == 2) && (Double.parseDouble(no2.getText().toString()) == 20)) {
								points2.setText("4");
								grade2.setText("C");
							}
							else {
								if ((Double.parseDouble(ch_sub2.getText().toString()) == 2) && (Double.parseDouble(no2.getText().toString()) == 21)) {
									points2.setText("4.33");
									grade2.setText("C");
								}
								else {
									if ((Double.parseDouble(ch_sub2.getText().toString()) == 2) && (Double.parseDouble(no2.getText().toString()) == 22)) {
										points2.setText("4.67");
										grade2.setText("C");
									}
									else {
										if ((Double.parseDouble(ch_sub2.getText().toString()) == 2) && (Double.parseDouble(no2.getText().toString()) == 23)) {
											points2.setText("5");
											grade2.setText("C");
										}
										else {
											if ((Double.parseDouble(ch_sub2.getText().toString()) == 2) && (Double.parseDouble(no2.getText().toString()) == 24)) {
												points2.setText("5.33");
												grade2.setText("C");
											}
											else {
												if ((Double.parseDouble(ch_sub2.getText().toString()) == 2) && (Double.parseDouble(no2.getText().toString()) == 25)) {
													points2.setText("5.67");
													grade2.setText("C");
												}
												else {
													if ((Double.parseDouble(ch_sub2.getText().toString()) == 2) && (Double.parseDouble(no2.getText().toString()) == 26)) {
														points2.setText("6");
														grade2.setText("B");
													}
													else {
														if ((Double.parseDouble(ch_sub2.getText().toString()) == 2) && (Double.parseDouble(no2.getText().toString()) == 27)) {
															points2.setText("6.33");
															grade2.setText("B");
														}
														else {
															if ((Double.parseDouble(ch_sub2.getText().toString()) == 2) && (Double.parseDouble(no2.getText().toString()) == 28)) {
																points2.setText("6.67");
																grade2.setText("B");
															}
															else {
																if ((Double.parseDouble(ch_sub2.getText().toString()) == 2) && (Double.parseDouble(no2.getText().toString()) == 29)) {
																	points2.setText("7");
																	grade2.setText("B");
																}
																else {
																	if ((Double.parseDouble(ch_sub2.getText().toString()) == 2) && (Double.parseDouble(no2.getText().toString()) == 30)) {
																		points2.setText("7.33");
																		grade2.setText("B");
																	}
																	else {
																		if ((Double.parseDouble(ch_sub2.getText().toString()) == 2) && (Double.parseDouble(no2.getText().toString()) == 31)) {
																			points2.setText("7.67");
																			grade2.setText("B");
																		}
																		else {
																			if ((Double.parseDouble(ch_sub2.getText().toString()) == 2) && (Double.parseDouble(no2.getText().toString()) == 32)) {
																				points2.setText("8");
																				grade2.setText("A");
																			}
																			else {
																				if ((Double.parseDouble(ch_sub2.getText().toString()) == 2) && (Double.parseDouble(no2.getText().toString()) == 33)) {
																					points2.setText("8");
																					grade2.setText("A");
																				}
																				else {
																					if ((Double.parseDouble(ch_sub2.getText().toString()) == 2) && (Double.parseDouble(no2.getText().toString()) == 34)) {
																						points2.setText("8");
																						grade2.setText("A");
																					}
																					else {
																						if ((Double.parseDouble(ch_sub2.getText().toString()) == 2) && (Double.parseDouble(no2.getText().toString()) == 35)) {
																							points2.setText("8");
																							grade2.setText("A");
																						}
																						else {
																							if ((Double.parseDouble(ch_sub2.getText().toString()) == 2) && (Double.parseDouble(no2.getText().toString()) == 36)) {
																								points2.setText("8");
																								grade2.setText("A");
																							}
																							else {
																								if ((Double.parseDouble(ch_sub2.getText().toString()) == 2) && (Double.parseDouble(no2.getText().toString()) == 37)) {
																									points2.setText("8");
																									grade2.setText("A");
																								}
																								else {
																									if ((Double.parseDouble(ch_sub2.getText().toString()) == 2) && (Double.parseDouble(no2.getText().toString()) == 38)) {
																										points2.setText("8");
																										grade2.setText("A");
																									}
																									else {
																										if ((Double.parseDouble(ch_sub2.getText().toString()) == 2) && (Double.parseDouble(no2.getText().toString()) == 39)) {
																											points2.setText("8");
																											grade2.setText("A");
																										}
																										else {
																											if ((Double.parseDouble(ch_sub2.getText().toString()) == 2) && (Double.parseDouble(no2.getText().toString()) == 40)) {
																												points2.setText("8");
																												grade2.setText("A");
																											}
																											else {
																												_check_colors();
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	private void _sub2_ch3 () {
		if (ch_sub2.getText().toString().equals("") || no2.getText().toString().equals("")) {

		}
		else {
			if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 24)) {
				points2.setText("3");
				grade2.setText("D");
			}
			else {
				if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 25)) {
					points2.setText("3.5");
					grade2.setText("D");
				}
				else {
					if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 26)) {
						points2.setText("4");
						grade2.setText("D");
					}
					else {
						if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 27)) {
							points2.setText("4.5");
							grade2.setText("D");
						}
						else {
							if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 28)) {
								points2.setText("5");
								grade2.setText("D");
							}
							else {
								if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 29)) {
									points2.setText("5.5");
									grade2.setText("D");
								}
								else {
									if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 30)) {
										points2.setText("6");
										grade2.setText("C");
									}
									else {
										if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 31)) {
											points2.setText("6.33");
											grade2.setText("C");
										}
										else {
											if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 32)) {
												points2.setText("6.67");
												grade2.setText("C");
											}
											else {
												if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 33)) {
													points2.setText("7");
													grade2.setText("C");
												}
												else {
													if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 34)) {
														points2.setText("7.33");
														grade2.setText("C");
													}
													else {
														if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 35)) {
															points2.setText("7.67");
															grade2.setText("C");
														}
														else {
															if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 36)) {
																points2.setText("8");
																grade2.setText("C");
															}
															else {
																if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 37)) {
																	points2.setText("8.33");
																	grade2.setText("C");
																}
																else {
																	if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 38)) {
																		points2.setText("8.67");
																		grade2.setText("C");
																	}
																	else {
																		if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 39)) {
																			points2.setText("9");
																			grade2.setText("B");
																		}
																		else {
																			if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 40)) {
																				points2.setText("9.33");
																				grade2.setText("B");
																			}
																			else {
																				if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 41)) {
																					points2.setText("9.67");
																					grade2.setText("B");
																				}
																				else {
																					if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 42)) {
																						points2.setText("10");
																						grade2.setText("B");
																					}
																					else {
																						if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 43)) {
																							points2.setText("10.33");
																							grade2.setText("B");
																						}
																						else {
																							if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 44)) {
																								points2.setText("10.67");
																								grade2.setText("B");
																							}
																							else {
																								if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 45)) {
																									points2.setText("11");
																									grade2.setText("B");
																								}
																								else {
																									if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 46)) {
																										points2.setText("11.33");
																										grade2.setText("B");
																									}
																									else {
																										if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 47)) {
																											points2.setText("11.67");
																											grade2.setText("B");
																										}
																										else {
																											if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 48)) {
																												points2.setText("12");
																												grade2.setText("A");
																											}
																											else {
																												if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 49)) {
																													points2.setText("12");
																													grade2.setText("A");
																												}
																												else {
																													if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 50)) {
																														points2.setText("12");
																														grade2.setText("A");
																													}
																													else {
																														if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 51)) {
																															points2.setText("12");
																															grade2.setText("A");
																														}
																														else {
																															if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 52)) {
																																points2.setText("12");
																																grade2.setText("A");
																															}
																															else {
																																if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 53)) {
																																	points2.setText("12");
																																	grade2.setText("A");
																																}
																																else {
																																	if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 54)) {
																																		points2.setText("12");
																																		grade2.setText("A");
																																	}
																																	else {
																																		if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 55)) {
																																			points2.setText("12");
																																			grade2.setText("A");
																																		}
																																		else {
																																			if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 56)) {
																																				points2.setText("12");
																																				grade2.setText("A");
																																			}
																																			else {
																																				if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 57)) {
																																					points2.setText("12");
																																					grade2.setText("A");
																																				}
																																				else {
																																					if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 58)) {
																																						points2.setText("12");
																																						grade2.setText("A");
																																					}
																																					else {
																																						if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 59)) {
																																							points2.setText("12");
																																							grade2.setText("A");
																																						}
																																						else {
																																							if ((Double.parseDouble(ch_sub2.getText().toString()) == 3) && (Double.parseDouble(no2.getText().toString()) == 60)) {
																																								points2.setText("12");
																																								grade2.setText("A");
																																							}
																																							else {
																																								_check_colors();
																																							}
																																						}
																																					}
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	private void _sub2_ch4 () {
		if (ch_sub2.getText().toString().equals("") || no2.getText().toString().equals("")) {

		}
		else {
			if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 32)) {
				points2.setText("4");
				grade2.setText("D");
			}
			else {
				if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 33)) {
					points2.setText("4.5");
					grade2.setText("D");
				}
				else {
					if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 34)) {
						points2.setText("5");
						grade2.setText("D");
					}
					else {
						if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 35)) {
							points2.setText("5.5");
							grade2.setText("D");
						}
						else {
							if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 36)) {
								points2.setText("6");
								grade2.setText("D");
							}
							else {
								if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 37)) {
									points2.setText("6.5");
									grade2.setText("D");
								}
								else {
									if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 38)) {
										points2.setText("7");
										grade2.setText("D");
									}
									else {
										if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 39)) {
											points2.setText("7.5");
											grade2.setText("D");
										}
										else {
											if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 40)) {
												points2.setText("8");
												grade2.setText("C");
											}
											else {
												if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 41)) {
													points2.setText("8.33");
													grade2.setText("C");
												}
												else {
													if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 42)) {
														points2.setText("8.67");
														grade2.setText("C");
													}
													else {
														if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 43)) {
															points2.setText("9");
															grade2.setText("C");
														}
														else {
															if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 44)) {
																points2.setText("9.33");
																grade2.setText("C");
															}
															else {
																if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 45)) {
																	points2.setText("9.67");
																	grade2.setText("C");
																}
																else {
																	if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 46)) {
																		points2.setText("10");
																		grade2.setText("C");
																	}
																	else {
																		if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 47)) {
																			points2.setText("10.33");
																			grade2.setText("C");
																		}
																		else {
																			if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 48)) {
																				points2.setText("10.67");
																				grade2.setText("C");
																			}
																			else {
																				if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 49)) {
																					points2.setText("11");
																					grade2.setText("C");
																				}
																				else {
																					if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 50)) {
																						points2.setText("11.33");
																						grade2.setText("C");
																					}
																					else {
																						if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 51)) {
																							points2.setText("11.67");
																							grade2.setText("C");
																						}
																						else {
																							if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 52)) {
																								points2.setText("12");
																								grade2.setText("B");
																							}
																							else {
																								if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 53)) {
																									points2.setText("12.33");
																									grade2.setText("B");
																								}
																								else {
																									if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 54)) {
																										points2.setText("12.67");
																										grade2.setText("B");
																									}
																									else {
																										if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 55)) {
																											points2.setText("13");
																											grade2.setText("B");
																										}
																										else {
																											if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 56)) {
																												points2.setText("13.33");
																												grade2.setText("B");
																											}
																											else {
																												if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 57)) {
																													points2.setText("13.67");
																													grade2.setText("B");
																												}
																												else {
																													if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 58)) {
																														points2.setText("14");
																														grade2.setText("B");
																													}
																													else {
																														if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 59)) {
																															points2.setText("14.33");
																															grade2.setText("B");
																														}
																														else {
																															if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 60)) {
																																points2.setText("14.67");
																																grade2.setText("B");
																															}
																															else {
																																if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 61)) {
																																	points2.setText("15");
																																	grade2.setText("B");
																																}
																																else {
																																	if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 62)) {
																																		points2.setText("15.33");
																																		grade2.setText("B");
																																	}
																																	else {
																																		if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 63)) {
																																			points2.setText("15.67");
																																			grade2.setText("B");
																																		}
																																		else {
																																			if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 64)) {
																																				points2.setText("16");
																																				grade2.setText("A");
																																			}
																																			else {
																																				if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 65)) {
																																					points2.setText("16");
																																					grade2.setText("A");
																																				}
																																				else {
																																					if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 66)) {
																																						points2.setText("16");
																																						grade2.setText("A");
																																					}
																																					else {
																																						if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 67)) {
																																							points2.setText("16");
																																							grade2.setText("A");
																																						}
																																						else {
																																							if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 68)) {
																																								points2.setText("16");
																																								grade2.setText("A");
																																							}
																																							else {
																																								if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 69)) {
																																									points2.setText("16");
																																									grade2.setText("A");
																																								}
																																								else {
																																									if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 70)) {
																																										points2.setText("16");
																																										grade2.setText("A");
																																									}
																																									else {
																																										if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 71)) {
																																											points2.setText("16");
																																											grade2.setText("A");
																																										}
																																										else {
																																											if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 72)) {
																																												points2.setText("16");
																																												grade2.setText("A");
																																											}
																																											else {
																																												if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 73)) {
																																													points2.setText("16");
																																													grade2.setText("A");
																																												}
																																												else {
																																													if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 74)) {
																																														points2.setText("16");
																																														grade2.setText("A");
																																													}
																																													else {
																																														if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 75)) {
																																															points2.setText("16");
																																															grade2.setText("A");
																																														}
																																														else {
																																															if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 76)) {
																																																points2.setText("16");
																																																grade2.setText("A");
																																															}
																																															else {
																																																if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 77)) {
																																																	points2.setText("16");
																																																	grade2.setText("A");
																																																}
																																																else {
																																																	if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 78)) {
																																																		points2.setText("16");
																																																		grade2.setText("A");
																																																	}
																																																	else {
																																																		if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 79)) {
																																																			points2.setText("16");
																																																			grade2.setText("A");
																																																		}
																																																		else {
																																																			if ((Double.parseDouble(ch_sub2.getText().toString()) == 4) && (Double.parseDouble(no2.getText().toString()) == 80)) {
																																																				points2.setText("16");
																																																				grade2.setText("A");
																																																			}
																																																			else {
																																																				_check_colors();
																																																			}
																																																		}
																																																	}
																																																}
																																															}
																																														}
																																													}
																																												}
																																											}
																																										}
																																									}
																																								}
																																							}
																																						}
																																					}
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																							points2.setTextColor(0xFFF44336);
																							grade2.setTextColor(0xFFF44336);
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	private void _sub2_ch5 () {

	}
	private void _sub3_ch1 () {
		if (ch_sub3.getText().toString().equals("") || no3.getText().toString().equals("")) {

		}
		else {
			if ((Double.parseDouble(ch_sub3.getText().toString()) == 1) && (Double.parseDouble(no3.getText().toString()) == 8)) {
				points3.setText("1");
				grade3.setText("D");
			}
			else {
				if ((Double.parseDouble(ch_sub3.getText().toString()) == 1) && (Double.parseDouble(no3.getText().toString()) == 9)) {
					points3.setText("1.5");
					grade3.setText("D");
				}
				else {
					if ((Double.parseDouble(ch_sub3.getText().toString()) == 1) && (Double.parseDouble(no3.getText().toString()) == 10)) {
						points3.setText("2");
						grade3.setText("C");
					}
					else {
						if ((Double.parseDouble(ch_sub3.getText().toString()) == 1) && (Double.parseDouble(no3.getText().toString()) == 11)) {
							points3.setText("2.33");
							grade3.setText("C");
						}
						else {
							if ((Double.parseDouble(ch_sub3.getText().toString()) == 1) && (Double.parseDouble(no3.getText().toString()) == 12)) {
								points3.setText("2.67");
								grade3.setText("C");
							}
							else {
								if ((Double.parseDouble(ch_sub3.getText().toString()) == 1) && (Double.parseDouble(no3.getText().toString()) == 13)) {
									points3.setText("3");
									grade3.setText("B");
								}
								else {
									if ((Double.parseDouble(ch_sub3.getText().toString()) == 1) && (Double.parseDouble(no3.getText().toString()) == 14)) {
										points3.setText("3.33");
										grade3.setText("B");
									}
									else {
										if ((Double.parseDouble(ch_sub3.getText().toString()) == 1) && (Double.parseDouble(no3.getText().toString()) == 15)) {
											points3.setText("3.67");
											grade3.setText("B");
										}
										else {
											if ((Double.parseDouble(ch_sub3.getText().toString()) == 1) && (Double.parseDouble(no3.getText().toString()) == 16)) {
												points3.setText("4");
												grade3.setText("A");
											}
											else {
												if ((Double.parseDouble(ch_sub3.getText().toString()) == 1) && (Double.parseDouble(no3.getText().toString()) == 17)) {
													points3.setText("4");
													grade3.setText("A");
												}
												else {
													if ((Double.parseDouble(ch_sub3.getText().toString()) == 1) && (Double.parseDouble(no3.getText().toString()) == 18)) {
														points3.setText("4");
														grade3.setText("A");
													}
													else {
														if ((Double.parseDouble(ch_sub3.getText().toString()) == 1) && (Double.parseDouble(no3.getText().toString()) == 19)) {
															points3.setText("4");
															grade3.setText("A");
														}
														else {
															if ((Double.parseDouble(ch_sub3.getText().toString()) == 1) && (Double.parseDouble(no3.getText().toString()) == 20)) {
																points3.setText("4");
																grade3.setText("A");
															}
															else {
																_check_colors();
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	private void _sub3_ch2 () {
		if (ch_sub3.getText().toString().equals("") || no3.getText().toString().equals("")) {
			showMessage("Enter valid data");
		}
		else {
			if ((Double.parseDouble(ch_sub3.getText().toString()) == 2) && (Double.parseDouble(no3.getText().toString()) == 16)) {
				points3.setText("2");
				grade3.setText("D");
			}
			else {
				if ((Double.parseDouble(ch_sub3.getText().toString()) == 2) && (Double.parseDouble(no3.getText().toString()) == 17)) {
					points3.setText("2.5");
					grade3.setText("D");
				}
				else {
					if ((Double.parseDouble(ch_sub3.getText().toString()) == 2) && (Double.parseDouble(no3.getText().toString()) == 18)) {
						points3.setText("3");
						grade3.setText("D");
					}
					else {
						if ((Double.parseDouble(ch_sub3.getText().toString()) == 2) && (Double.parseDouble(no3.getText().toString()) == 19)) {
							points3.setText("3.5");
							grade3.setText("D");
						}
						else {
							if ((Double.parseDouble(ch_sub3.getText().toString()) == 2) && (Double.parseDouble(no3.getText().toString()) == 20)) {
								points3.setText("4");
								grade3.setText("C");
							}
							else {
								if ((Double.parseDouble(ch_sub3.getText().toString()) == 2) && (Double.parseDouble(no3.getText().toString()) == 21)) {
									points3.setText("4.33");
									grade3.setText("C");
								}
								else {
									if ((Double.parseDouble(ch_sub3.getText().toString()) == 2) && (Double.parseDouble(no3.getText().toString()) == 22)) {
										points3.setText("4.67");
										grade3.setText("C");
									}
									else {
										if ((Double.parseDouble(ch_sub3.getText().toString()) == 2) && (Double.parseDouble(no3.getText().toString()) == 23)) {
											points3.setText("5");
											grade3.setText("C");
										}
										else {
											if ((Double.parseDouble(ch_sub3.getText().toString()) == 2) && (Double.parseDouble(no3.getText().toString()) == 24)) {
												points3.setText("5.33");
												grade3.setText("C");
											}
											else {
												if ((Double.parseDouble(ch_sub3.getText().toString()) == 2) && (Double.parseDouble(no3.getText().toString()) == 25)) {
													points3.setText("5.67");
													grade3.setText("C");
												}
												else {
													if ((Double.parseDouble(ch_sub3.getText().toString()) == 2) && (Double.parseDouble(no3.getText().toString()) == 26)) {
														points3.setText("6");
														grade3.setText("B");
													}
													else {
														if ((Double.parseDouble(ch_sub3.getText().toString()) == 2) && (Double.parseDouble(no3.getText().toString()) == 27)) {
															points3.setText("6.33");
															grade3.setText("B");
														}
														else {
															if ((Double.parseDouble(ch_sub3.getText().toString()) == 2) && (Double.parseDouble(no3.getText().toString()) == 28)) {
																points3.setText("6.67");
																grade3.setText("B");
															}
															else {
																if ((Double.parseDouble(ch_sub3.getText().toString()) == 2) && (Double.parseDouble(no3.getText().toString()) == 29)) {
																	points3.setText("7");
																	grade3.setText("B");
																}
																else {
																	if ((Double.parseDouble(ch_sub3.getText().toString()) == 2) && (Double.parseDouble(no3.getText().toString()) == 30)) {
																		points3.setText("7.33");
																		grade3.setText("B");
																	}
																	else {
																		if ((Double.parseDouble(ch_sub3.getText().toString()) == 2) && (Double.parseDouble(no3.getText().toString()) == 31)) {
																			points3.setText("7.67");
																			grade3.setText("B");
																		}
																		else {
																			if ((Double.parseDouble(ch_sub3.getText().toString()) == 2) && (Double.parseDouble(no3.getText().toString()) == 32)) {
																				points3.setText("8");
																				grade3.setText("A");
																			}
																			else {
																				if ((Double.parseDouble(ch_sub3.getText().toString()) == 2) && (Double.parseDouble(no3.getText().toString()) == 33)) {
																					points3.setText("8");
																					grade3.setText("A");
																				}
																				else {
																					if ((Double.parseDouble(ch_sub3.getText().toString()) == 2) && (Double.parseDouble(no3.getText().toString()) == 34)) {
																						points3.setText("8");
																						grade3.setText("A");
																					}
																					else {
																						if ((Double.parseDouble(ch_sub3.getText().toString()) == 2) && (Double.parseDouble(no3.getText().toString()) == 35)) {
																							points3.setText("8");
																							grade3.setText("A");
																						}
																						else {
																							if ((Double.parseDouble(ch_sub3.getText().toString()) == 2) && (Double.parseDouble(no3.getText().toString()) == 36)) {
																								points3.setText("8");
																								grade3.setText("A");
																							}
																							else {
																								if ((Double.parseDouble(ch_sub3.getText().toString()) == 2) && (Double.parseDouble(no3.getText().toString()) == 37)) {
																									points3.setText("8");
																									grade3.setText("A");
																								}
																								else {
																									if ((Double.parseDouble(ch_sub3.getText().toString()) == 2) && (Double.parseDouble(no3.getText().toString()) == 38)) {
																										points3.setText("8");
																										grade3.setText("A");
																									}
																									else {
																										if ((Double.parseDouble(ch_sub3.getText().toString()) == 2) && (Double.parseDouble(no3.getText().toString()) == 39)) {
																											points3.setText("8");
																											grade3.setText("A");
																										}
																										else {
																											if ((Double.parseDouble(ch_sub3.getText().toString()) == 2) && (Double.parseDouble(no3.getText().toString()) == 40)) {
																												points3.setText("8");
																												grade3.setText("A");
																											}
																											else {
																												_check_colors();
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	private void _sub3_ch3 () {
		if (ch_sub3.getText().toString().equals("") || no3.getText().toString().equals("")) {

		}
		else {
			if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 24)) {
				points3.setText("3");
				grade3.setText("D");
			}
			else {
				if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 25)) {
					points3.setText("3.5");
					grade3.setText("D");
				}
				else {
					if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 26)) {
						points3.setText("4");
						grade3.setText("D");
					}
					else {
						if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 27)) {
							points3.setText("4.5");
							grade3.setText("D");
						}
						else {
							if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 28)) {
								points3.setText("5");
								grade3.setText("D");
							}
							else {
								if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 29)) {
									points3.setText("5.5");
									grade3.setText("D");
								}
								else {
									if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 30)) {
										points3.setText("6");
										grade3.setText("C");
									}
									else {
										if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 31)) {
											points3.setText("6.33");
											grade3.setText("C");
										}
										else {
											if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 32)) {
												points3.setText("6.67");
												grade3.setText("C");
											}
											else {
												if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 33)) {
													points3.setText("7");
													grade3.setText("C");
												}
												else {
													if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 34)) {
														points3.setText("7.33");
														grade3.setText("C");
													}
													else {
														if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 35)) {
															points3.setText("7.67");
															grade3.setText("C");
														}
														else {
															if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 36)) {
																points3.setText("8");
																grade3.setText("C");
															}
															else {
																if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 37)) {
																	points3.setText("8.33");
																	grade3.setText("C");
																}
																else {
																	if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 38)) {
																		points3.setText("8.67");
																		grade3.setText("C");
																	}
																	else {
																		if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 39)) {
																			points3.setText("9");
																			grade3.setText("B");
																		}
																		else {
																			if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 40)) {
																				points3.setText("9.33");
																				grade3.setText("B");
																			}
																			else {
																				if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 41)) {
																					points3.setText("9.67");
																					grade3.setText("B");
																				}
																				else {
																					if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 42)) {
																						points3.setText("10");
																						grade3.setText("B");
																					}
																					else {
																						if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 43)) {
																							points3.setText("10.33");
																							grade3.setText("B");
																						}
																						else {
																							if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 44)) {
																								points3.setText("10.67");
																								grade3.setText("B");
																							}
																							else {
																								if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 45)) {
																									points3.setText("11");
																									grade3.setText("B");
																								}
																								else {
																									if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 46)) {
																										points3.setText("11.33");
																										grade3.setText("B");
																									}
																									else {
																										if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 47)) {
																											points3.setText("11.67");
																											grade3.setText("B");
																										}
																										else {
																											if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 48)) {
																												points3.setText("12");
																												grade3.setText("A");
																											}
																											else {
																												if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 49)) {
																													points3.setText("12");
																													grade3.setText("A");
																												}
																												else {
																													if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 50)) {
																														points3.setText("12");
																														grade3.setText("A");
																													}
																													else {
																														if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 51)) {
																															points3.setText("12");
																															grade3.setText("A");
																														}
																														else {
																															if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 52)) {
																																points3.setText("12");
																																grade3.setText("A");
																															}
																															else {
																																if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 53)) {
																																	points3.setText("12");
																																	grade3.setText("A");
																																}
																																else {
																																	if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 54)) {
																																		points3.setText("12");
																																		grade3.setText("A");
																																	}
																																	else {
																																		if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 55)) {
																																			points3.setText("12");
																																			grade3.setText("A");
																																		}
																																		else {
																																			if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 56)) {
																																				points3.setText("12");
																																				grade3.setText("A");
																																			}
																																			else {
																																				if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 57)) {
																																					points3.setText("12");
																																					grade3.setText("A");
																																				}
																																				else {
																																					if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 58)) {
																																						points3.setText("12");
																																						grade3.setText("A");
																																					}
																																					else {
																																						if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 59)) {
																																							points3.setText("12");
																																							grade3.setText("A");
																																						}
																																						else {
																																							if ((Double.parseDouble(ch_sub3.getText().toString()) == 3) && (Double.parseDouble(no3.getText().toString()) == 60)) {
																																								points3.setText("12");
																																								grade3.setText("A");
																																							}
																																							else {
																																								_check_colors();
																																							}
																																						}
																																					}
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	private void _sub3_ch4 () {
		if (ch_sub3.getText().toString().equals("") || no3.getText().toString().equals("")) {

		}
		else {
			if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 32)) {
				points3.setText("4");
				grade3.setText("D");
			}
			else {
				if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 33)) {
					points3.setText("4.5");
					grade3.setText("D");
				}
				else {
					if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 34)) {
						points3.setText("5");
						grade3.setText("D");
					}
					else {
						if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 35)) {
							points3.setText("5.5");
							grade3.setText("D");
						}
						else {
							if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 36)) {
								points3.setText("6");
								grade3.setText("D");
							}
							else {
								if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 37)) {
									points3.setText("6.5");
									grade3.setText("D");
								}
								else {
									if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 38)) {
										points3.setText("7");
										grade3.setText("D");
									}
									else {
										if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 39)) {
											points3.setText("7.5");
											grade3.setText("D");
										}
										else {
											if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 40)) {
												points3.setText("8");
												grade3.setText("C");
											}
											else {
												if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 41)) {
													points3.setText("8.33");
													grade3.setText("C");
												}
												else {
													if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 42)) {
														points3.setText("8.67");
														grade3.setText("C");
													}
													else {
														if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 43)) {
															points3.setText("9");
															grade3.setText("C");
														}
														else {
															if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 44)) {
																points3.setText("9.33");
																grade3.setText("C");
															}
															else {
																if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 45)) {
																	points3.setText("9.67");
																	grade3.setText("C");
																}
																else {
																	if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 46)) {
																		points3.setText("10");
																		grade3.setText("C");
																	}
																	else {
																		if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 47)) {
																			points3.setText("10.33");
																			grade3.setText("C");
																		}
																		else {
																			if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 48)) {
																				points3.setText("10.67");
																				grade3.setText("C");
																			}
																			else {
																				if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 49)) {
																					points3.setText("11");
																					grade3.setText("C");
																				}
																				else {
																					if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 50)) {
																						points3.setText("11.33");
																						grade3.setText("C");
																					}
																					else {
																						if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 51)) {
																							points3.setText("11.67");
																							grade3.setText("C");
																						}
																						else {
																							if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 52)) {
																								points3.setText("12");
																								grade3.setText("B");
																							}
																							else {
																								if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 53)) {
																									points3.setText("12.33");
																									grade3.setText("B");
																								}
																								else {
																									if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 54)) {
																										points3.setText("12.67");
																										grade3.setText("B");
																									}
																									else {
																										if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 55)) {
																											points3.setText("13");
																											grade3.setText("B");
																										}
																										else {
																											if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 56)) {
																												points3.setText("13.33");
																												grade3.setText("B");
																											}
																											else {
																												if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 57)) {
																													points3.setText("13.67");
																													grade3.setText("B");
																												}
																												else {
																													if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 58)) {
																														points3.setText("14");
																														grade3.setText("B");
																													}
																													else {
																														if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 59)) {
																															points3.setText("14.33");
																															grade3.setText("B");
																														}
																														else {
																															if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 60)) {
																																points3.setText("14.67");
																																grade3.setText("B");
																															}
																															else {
																																if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 61)) {
																																	points3.setText("15");
																																	grade3.setText("B");
																																}
																																else {
																																	if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 62)) {
																																		points3.setText("15.33");
																																		grade3.setText("B");
																																	}
																																	else {
																																		if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 63)) {
																																			points3.setText("15.67");
																																			grade3.setText("B");
																																		}
																																		else {
																																			if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 64)) {
																																				points3.setText("16");
																																				grade3.setText("A");
																																			}
																																			else {
																																				if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 65)) {
																																					points3.setText("16");
																																					grade3.setText("A");
																																				}
																																				else {
																																					if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 66)) {
																																						points3.setText("16");
																																						grade3.setText("A");
																																					}
																																					else {
																																						if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 67)) {
																																							points3.setText("16");
																																							grade3.setText("A");
																																						}
																																						else {
																																							if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 68)) {
																																								points3.setText("16");
																																								grade3.setText("A");
																																							}
																																							else {
																																								if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 69)) {
																																									points3.setText("16");
																																									grade3.setText("A");
																																								}
																																								else {
																																									if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 70)) {
																																										points3.setText("16");
																																										grade3.setText("A");
																																									}
																																									else {
																																										if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 71)) {
																																											points3.setText("16");
																																											grade3.setText("A");
																																										}
																																										else {
																																											if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 72)) {
																																												points3.setText("16");
																																												grade3.setText("A");
																																											}
																																											else {
																																												if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 73)) {
																																													points3.setText("16");
																																													grade3.setText("A");
																																												}
																																												else {
																																													if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 74)) {
																																														points3.setText("16");
																																														grade3.setText("A");
																																													}
																																													else {
																																														if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 75)) {
																																															points3.setText("16");
																																															grade3.setText("A");
																																														}
																																														else {
																																															if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 76)) {
																																																points3.setText("16");
																																																grade3.setText("A");
																																															}
																																															else {
																																																if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 77)) {
																																																	points3.setText("16");
																																																	grade3.setText("A");
																																																}
																																																else {
																																																	if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 78)) {
																																																		points3.setText("16");
																																																		grade3.setText("A");
																																																	}
																																																	else {
																																																		if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 79)) {
																																																			points3.setText("16");
																																																			grade3.setText("A");
																																																		}
																																																		else {
																																																			if ((Double.parseDouble(ch_sub3.getText().toString()) == 4) && (Double.parseDouble(no3.getText().toString()) == 80)) {
																																																				points3.setText("16");
																																																				grade3.setText("A");
																																																			}
																																																			else {
																																																				_check_colors();
																																																			}
																																																		}
																																																	}
																																																}
																																															}
																																														}
																																													}
																																												}
																																											}
																																										}
																																									}
																																								}
																																							}
																																						}
																																					}
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	private void _sub3_ch5 () {

	}
	private void _check_colors () {
		grade.edit().putString("grade", grade1.getText().toString()).commit();
		grade_2.edit().putString("grade", grade2.getText().toString()).commit();
		grade_3.edit().putString("grade", grade3.getText().toString()).commit();
		grade_4.edit().putString("grade", grade4.getText().toString()).commit();
		grade_5.edit().putString("grade", grade5.getText().toString()).commit();
		grade_6.edit().putString("grade", grade6.getText().toString()).commit();
		if (grade_2.getString("grade", "").equals("A")) {
			grade2.setTextColor(0xFF4CAF50);
			points2.setTextColor(0xFF4CAF50);
		}
		else {
			if (grade_2.getString("grade", "").equals("B")) {
				grade2.setTextColor(0xFF9C27B0);
				points2.setTextColor(0xFF9C27B0);
			}
			else {
				if (grade_2.getString("grade", "").equals("C")) {
					grade2.setTextColor(0xFF2196F3);
					points2.setTextColor(0xFF2196F3);
				}
				else {
					if (grade_2.getString("grade", "").equals("D")) {
						grade2.setTextColor(0xFFF44336);
						points2.setTextColor(0xFFF44336);
					}
					else {
						_mode();
					}
				}
			}
		}
		if (grade.getString("grade", "").equals("A")) {
			grade1.setTextColor(0xFF4CAF50);
			points1.setTextColor(0xFF4CAF50);
		}
		else {
			if (grade.getString("grade", "").equals("B")) {
				grade1.setTextColor(0xFF9C27B0);
				points1.setTextColor(0xFF9C27B0);
			}
			else {
				if (grade.getString("grade", "").equals("C")) {
					grade1.setTextColor(0xFF2196F3);
					points1.setTextColor(0xFF2196F3);
				}
				else {
					if (grade.getString("grade", "").equals("D")) {
						grade1.setTextColor(0xFFF44336);
						points1.setTextColor(0xFFF44336);
					}
					else {
						_mode();
					}
				}
			}
		}
		if (grade_3.getString("grade", "").equals("A")) {
			grade3.setTextColor(0xFF4CAF50);
			points3.setTextColor(0xFF4CAF50);
		}
		else {
			if (grade_3.getString("grade", "").equals("B")) {
				grade3.setTextColor(0xFF9C27B0);
				points3.setTextColor(0xFF9C27B0);
			}
			else {
				if (grade_3.getString("grade", "").equals("C")) {
					grade3.setTextColor(0xFF2196F3);
					points3.setTextColor(0xFF2196F3);
				}
				else {
					if (grade_3.getString("grade", "").equals("D")) {
						grade3.setTextColor(0xFFF44336);
						points3.setTextColor(0xFFF44336);
					}
					else {
						_mode();
					}
				}
			}
		}
		if (grade_4.getString("grade", "").equals("A")) {
			grade4.setTextColor(0xFF4CAF50);
			points4.setTextColor(0xFF4CAF50);
		}
		else {
			if (grade_4.getString("grade", "").equals("B")) {
				grade4.setTextColor(0xFF9C27B0);
				points4.setTextColor(0xFF9C27B0);
			}
			else {
				if (grade_4.getString("grade", "").equals("C")) {
					grade4.setTextColor(0xFF2196F3);
					points4.setTextColor(0xFF2196F3);
				}
				else {
					if (grade_4.getString("grade", "").equals("D")) {
						grade4.setTextColor(0xFFF44336);
						points4.setTextColor(0xFFF44336);
					}
					else {
						_mode();
					}
				}
			}
		}
		if (grade_5.getString("grade", "").equals("A")) {
			grade5.setTextColor(0xFF4CAF50);
			points5.setTextColor(0xFF4CAF50);
		}
		else {
			if (grade_5.getString("grade", "").equals(" B")) {
				grade5.setTextColor(0xFF9C27B0);
				points5.setTextColor(0xFF9C27B0);
			}
			else {
				if (grade_5.getString("grade", "").equals("C")) {
					grade5.setTextColor(0xFF2196F3);
					points5.setTextColor(0xFF2196F3);
				}
				else {
					if (grade_5.getString("grade", "").equals("D")) {
						grade5.setTextColor(0xFFF44336);
						points5.setTextColor(0xFFF44336);
					}
					else {
						_mode();
					}
				}
			}
		}
		if (grade_6.getString("grade", "").equals("A")) {
			grade6.setTextColor(0xFF4CAF50);
			points6.setTextColor(0xFF4CAF50);
		}
		else {
			if (grade_6.getString("grade", "").equals("B")) {
				grade6.setTextColor(0xFF9C27B0);
				points6.setTextColor(0xFF9C27B0);
			}
			else {
				if (grade_6.getString("grade", "").equals("C")) {
					grade6.setTextColor(0xFF2196F3);
					points6.setTextColor(0xFF2196F3);
				}
				else {
					if (grade_6.getString("grade", "").equals("D")) {
						grade6.setTextColor(0xFFF44336);
						points6.setTextColor(0xFFF44336);
					}
					else {
						_mode();
					}
				}
			}
		}
	}
	private void _Enter_Subject_Number () {
		share.edit().putString("ok", "1").commit();
		if (file.getString("subject", "").equals("4")) {
			grade1.setVisibility(View.VISIBLE);
			grade2.setVisibility(View.VISIBLE);
			grade3.setVisibility(View.VISIBLE);
			grade4.setVisibility(View.VISIBLE);
			grade5.setVisibility(View.GONE);
			grade6.setVisibility(View.GONE);
			points1.setVisibility(View.VISIBLE);
			points2.setVisibility(View.VISIBLE);
			points3.setVisibility(View.VISIBLE);
			points4.setVisibility(View.VISIBLE);
			points5.setVisibility(View.GONE);
			points6.setVisibility(View.GONE);
			no1.setVisibility(View.VISIBLE);
			no2.setVisibility(View.VISIBLE);
			no3.setVisibility(View.VISIBLE);
			no4.setVisibility(View.VISIBLE);
			no5.setVisibility(View.GONE);
			no6.setVisibility(View.GONE);
			grade1.setVisibility(View.VISIBLE);
			grade2.setVisibility(View.VISIBLE);
			grade3.setVisibility(View.VISIBLE);
			grade4.setVisibility(View.VISIBLE);
			grade5.setVisibility(View.GONE);
			grade6.setVisibility(View.GONE);
			ch_sub1.setVisibility(View.VISIBLE);
			ch_sub2.setVisibility(View.VISIBLE);
			ch_sub3.setVisibility(View.VISIBLE);
			ch_sub4.setVisibility(View.VISIBLE);
			ch_sub5.setVisibility(View.GONE);
			ch_sub6.setVisibility(View.GONE);
			subject1.setVisibility(View.VISIBLE);
			subject2.setVisibility(View.VISIBLE);
			subject3.setVisibility(View.VISIBLE);
			subject4.setVisibility(View.VISIBLE);
			subject5.setVisibility(View.GONE);
			subject6.setVisibility(View.GONE);
			file.edit().putString("subject", "4").commit();
			share.edit().putString("share", "4").commit();
			_check_colors();
		}
		else {
			if (file.getString("subject", "").equals("5")) {
				grade1.setVisibility(View.VISIBLE);
				grade2.setVisibility(View.VISIBLE);
				grade3.setVisibility(View.VISIBLE);
				grade4.setVisibility(View.VISIBLE);
				grade5.setVisibility(View.VISIBLE);
				grade6.setVisibility(View.GONE);
				points1.setVisibility(View.VISIBLE);
				points2.setVisibility(View.VISIBLE);
				points3.setVisibility(View.VISIBLE);
				points4.setVisibility(View.VISIBLE);
				points5.setVisibility(View.VISIBLE);
				points6.setVisibility(View.GONE);
				no1.setVisibility(View.VISIBLE);
				no2.setVisibility(View.VISIBLE);
				no3.setVisibility(View.VISIBLE);
				no4.setVisibility(View.VISIBLE);
				no5.setVisibility(View.VISIBLE);
				no6.setVisibility(View.GONE);
				grade1.setVisibility(View.VISIBLE);
				grade2.setVisibility(View.VISIBLE);
				grade3.setVisibility(View.VISIBLE);
				grade4.setVisibility(View.VISIBLE);
				grade5.setVisibility(View.VISIBLE);
				grade6.setVisibility(View.GONE);
				ch_sub1.setVisibility(View.VISIBLE);
				ch_sub2.setVisibility(View.VISIBLE);
				ch_sub3.setVisibility(View.VISIBLE);
				ch_sub4.setVisibility(View.VISIBLE);
				ch_sub5.setVisibility(View.VISIBLE);
				ch_sub6.setVisibility(View.GONE);
				subject1.setVisibility(View.VISIBLE);
				subject2.setVisibility(View.VISIBLE);
				subject3.setVisibility(View.VISIBLE);
				subject4.setVisibility(View.VISIBLE);
				subject5.setVisibility(View.VISIBLE);
				subject6.setVisibility(View.GONE);
				file.edit().putString("subject", "5").commit();
				share.edit().putString("share", "5").commit();
				_check_colors();
			}
			else {
				if (file.getString("subject", "").equals("6")) {
					file.edit().putString("subject", "6").commit();
					share.edit().putString("share", "6").commit();
					_visible_all();
					_check_colors();
				}
			}
		}
	}
	private void _sub4_ch1 () {
		if (ch_sub4.getText().toString().equals("") || no4.getText().toString().equals("")) {

		}
		else {
			if ((Double.parseDouble(ch_sub4.getText().toString()) == 1) && (Double.parseDouble(no4.getText().toString()) == 8)) {
				points4.setText("1");
				grade4.setText("D");
			}
			else {
				if ((Double.parseDouble(ch_sub4.getText().toString()) == 1) && (Double.parseDouble(no4.getText().toString()) == 9)) {
					points4.setText("1.5");
					grade4.setText("D");
				}
				else {
					if ((Double.parseDouble(ch_sub4.getText().toString()) == 1) && (Double.parseDouble(no4.getText().toString()) == 10)) {
						points4.setText("2");
						grade4.setText("C");
					}
					else {
						if ((Double.parseDouble(ch_sub4.getText().toString()) == 1) && (Double.parseDouble(no4.getText().toString()) == 11)) {
							points4.setText("2.33");
							grade4.setText("C");
						}
						else {
							if ((Double.parseDouble(ch_sub4.getText().toString()) == 1) && (Double.parseDouble(no4.getText().toString()) == 12)) {
								points4.setText("2.67");
								grade4.setText("C");
							}
							else {
								if ((Double.parseDouble(ch_sub4.getText().toString()) == 1) && (Double.parseDouble(no4.getText().toString()) == 13)) {
									points4.setText("3");
									grade4.setText("B");
								}
								else {
									if ((Double.parseDouble(ch_sub4.getText().toString()) == 1) && (Double.parseDouble(no4.getText().toString()) == 14)) {
										points4.setText("3.33");
										grade4.setText("B");
									}
									else {
										if ((Double.parseDouble(ch_sub4.getText().toString()) == 1) && (Double.parseDouble(no4.getText().toString()) == 15)) {
											points4.setText("3.67");
											grade4.setText("B");
										}
										else {
											if ((Double.parseDouble(ch_sub4.getText().toString()) == 1) && (Double.parseDouble(no4.getText().toString()) == 16)) {
												points4.setText("4");
												grade4.setText("A");
											}
											else {
												if ((Double.parseDouble(ch_sub4.getText().toString()) == 1) && (Double.parseDouble(no4.getText().toString()) == 17)) {
													points4.setText("4");
													grade4.setText("A");
												}
												else {
													if ((Double.parseDouble(ch_sub4.getText().toString()) == 1) && (Double.parseDouble(no4.getText().toString()) == 18)) {
														points4.setText("4");
														grade4.setText("A");
													}
													else {
														if ((Double.parseDouble(ch_sub4.getText().toString()) == 1) && (Double.parseDouble(no4.getText().toString()) == 19)) {
															points4.setText("4");
															grade4.setText("A");
														}
														else {
															if ((Double.parseDouble(ch_sub4.getText().toString()) == 1) && (Double.parseDouble(no4.getText().toString()) == 20)) {
																points4.setText("4");
																grade4.setText("A");
															}
															else {
																_check_colors();
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	private void _sub4_ch2 () {
		if (ch_sub4.getText().toString().equals("") || no4.getText().toString().equals("")) {

		}
		else {
			if ((Double.parseDouble(ch_sub4.getText().toString()) == 2) && (Double.parseDouble(no4.getText().toString()) == 16)) {
				points4.setText("2");
				grade4.setText("D");
			}
			else {
				if ((Double.parseDouble(ch_sub4.getText().toString()) == 2) && (Double.parseDouble(no4.getText().toString()) == 17)) {
					points4.setText("2.5");
					grade4.setText("D");
				}
				else {
					if ((Double.parseDouble(ch_sub4.getText().toString()) == 2) && (Double.parseDouble(no4.getText().toString()) == 18)) {
						points4.setText("3");
						grade4.setText("D");
					}
					else {
						if ((Double.parseDouble(ch_sub4.getText().toString()) == 2) && (Double.parseDouble(no4.getText().toString()) == 19)) {
							points4.setText("3.5");
							grade4.setText("D");
						}
						else {
							if ((Double.parseDouble(ch_sub4.getText().toString()) == 2) && (Double.parseDouble(no4.getText().toString()) == 20)) {
								points4.setText("4");
								grade4.setText("C");
							}
							else {
								if ((Double.parseDouble(ch_sub4.getText().toString()) == 2) && (Double.parseDouble(no4.getText().toString()) == 21)) {
									points4.setText("4.33");
									grade4.setText("C");
								}
								else {
									if ((Double.parseDouble(ch_sub4.getText().toString()) == 2) && (Double.parseDouble(no4.getText().toString()) == 22)) {
										points4.setText("4.67");
										grade4.setText("C");
									}
									else {
										if ((Double.parseDouble(ch_sub4.getText().toString()) == 2) && (Double.parseDouble(no4.getText().toString()) == 23)) {
											points4.setText("5");
											grade4.setText("C");
										}
										else {
											if ((Double.parseDouble(ch_sub4.getText().toString()) == 2) && (Double.parseDouble(no4.getText().toString()) == 24)) {
												points4.setText("5.33");
												grade4.setText("C");
											}
											else {
												if ((Double.parseDouble(ch_sub4.getText().toString()) == 2) && (Double.parseDouble(no4.getText().toString()) == 25)) {
													points4.setText("5.67");
													grade4.setText("C");
												}
												else {
													if ((Double.parseDouble(ch_sub4.getText().toString()) == 2) && (Double.parseDouble(no4.getText().toString()) == 26)) {
														points4.setText("6");
														grade4.setText("B");
													}
													else {
														if ((Double.parseDouble(ch_sub4.getText().toString()) == 2) && (Double.parseDouble(no4.getText().toString()) == 27)) {
															points4.setText("6.33");
															grade4.setText("B");
														}
														else {
															if ((Double.parseDouble(ch_sub4.getText().toString()) == 2) && (Double.parseDouble(no4.getText().toString()) == 28)) {
																points4.setText("6.67");
																grade4.setText("B");
															}
															else {
																if ((Double.parseDouble(ch_sub4.getText().toString()) == 2) && (Double.parseDouble(no4.getText().toString()) == 29)) {
																	points4.setText("7");
																	grade4.setText("B");
																}
																else {
																	if ((Double.parseDouble(ch_sub4.getText().toString()) == 2) && (Double.parseDouble(no4.getText().toString()) == 30)) {
																		points4.setText("7.33");
																		grade4.setText("B");
																	}
																	else {
																		if ((Double.parseDouble(ch_sub4.getText().toString()) == 2) && (Double.parseDouble(no4.getText().toString()) == 31)) {
																			points4.setText("7.67");
																			grade4.setText("B");
																		}
																		else {
																			if ((Double.parseDouble(ch_sub4.getText().toString()) == 2) && (Double.parseDouble(no4.getText().toString()) == 32)) {
																				points4.setText("8");
																				grade4.setText("A");
																			}
																			else {
																				if ((Double.parseDouble(ch_sub4.getText().toString()) == 2) && (Double.parseDouble(no4.getText().toString()) == 33)) {
																					points4.setText("8");
																					grade4.setText("A");
																				}
																				else {
																					if ((Double.parseDouble(ch_sub4.getText().toString()) == 2) && (Double.parseDouble(no4.getText().toString()) == 34)) {
																						points4.setText("8");
																						grade4.setText("A");
																					}
																					else {
																						if ((Double.parseDouble(ch_sub4.getText().toString()) == 2) && (Double.parseDouble(no4.getText().toString()) == 35)) {
																							points4.setText("8");
																							grade4.setText("A");
																						}
																						else {
																							if ((Double.parseDouble(ch_sub4.getText().toString()) == 2) && (Double.parseDouble(no4.getText().toString()) == 36)) {
																								points4.setText("8");
																								grade4.setText("A");
																							}
																							else {
																								if ((Double.parseDouble(ch_sub4.getText().toString()) == 2) && (Double.parseDouble(no4.getText().toString()) == 37)) {
																									points4.setText("8");
																									grade4.setText("A");
																								}
																								else {
																									if ((Double.parseDouble(ch_sub4.getText().toString()) == 2) && (Double.parseDouble(no4.getText().toString()) == 38)) {
																										points4.setText("8");
																										grade4.setText("A");
																									}
																									else {
																										if ((Double.parseDouble(ch_sub4.getText().toString()) == 2) && (Double.parseDouble(no4.getText().toString()) == 39)) {
																											points4.setText("8");
																											grade4.setText("A");
																										}
																										else {
																											if ((Double.parseDouble(ch_sub4.getText().toString()) == 2) && (Double.parseDouble(no4.getText().toString()) == 40)) {
																												points4.setText("8");
																												grade4.setText("A");
																											}
																											else {
																												_check_colors();
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	private void _sub4_ch3 () {
		if (ch_sub4.getText().toString().equals("") || no4.getText().toString().equals("")) {

		}
		else {
			if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 24)) {
				points4.setText("3");
				grade4.setText("D");
			}
			else {
				if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 25)) {
					points4.setText("3.5");
					grade4.setText("D");
				}
				else {
					if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 26)) {
						points4.setText("4");
						grade4.setText("D");
					}
					else {
						if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 27)) {
							points4.setText("4.5");
							grade4.setText("D");
						}
						else {
							if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 28)) {
								points4.setText("5");
								grade4.setText("D");
							}
							else {
								if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 29)) {
									points4.setText("5.5");
									grade4.setText("D");
								}
								else {
									if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 30)) {
										points4.setText("6");
										grade4.setText("C");
									}
									else {
										if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 31)) {
											points4.setText("6.33");
											grade4.setText("C");
										}
										else {
											if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 32)) {
												points4.setText("6.67");
												grade4.setText("C");
											}
											else {
												if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 33)) {
													points4.setText("7");
													grade4.setText("C");
												}
												else {
													if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 34)) {
														points4.setText("7.33");
														grade4.setText("C");
													}
													else {
														if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 35)) {
															points4.setText("7.67");
															grade4.setText("C");
														}
														else {
															if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 36)) {
																points4.setText("8");
																grade4.setText("C");
															}
															else {
																if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 37)) {
																	points4.setText("8.33");
																	grade4.setText("C");
																}
																else {
																	if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 38)) {
																		points4.setText("8.67");
																		grade4.setText("C");
																	}
																	else {
																		if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 39)) {
																			points4.setText("9");
																			grade4.setText("B");
																		}
																		else {
																			if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 40)) {
																				points4.setText("9.33");
																				grade4.setText("B");
																			}
																			else {
																				if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 41)) {
																					points4.setText("9.67");
																					grade4.setText("B");
																				}
																				else {
																					if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 42)) {
																						points4.setText("10");
																						grade4.setText("B");
																					}
																					else {
																						if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 43)) {
																							points4.setText("10.33");
																							grade4.setText("B");
																						}
																						else {
																							if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 44)) {
																								points4.setText("10.67");
																								grade4.setText("B");
																							}
																							else {
																								if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 45)) {
																									points4.setText("11");
																									grade4.setText("B");
																								}
																								else {
																									if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 46)) {
																										points4.setText("11.33");
																										grade4.setText("B");
																									}
																									else {
																										if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 47)) {
																											points4.setText("11.67");
																											grade4.setText("B");
																										}
																										else {
																											if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 48)) {
																												points4.setText("12");
																												grade4.setText("A");
																											}
																											else {
																												if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 49)) {
																													points4.setText("12");
																													grade4.setText("A");
																												}
																												else {
																													if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 50)) {
																														points4.setText("12");
																														grade4.setText("A");
																													}
																													else {
																														if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 51)) {
																															points4.setText("12");
																															grade4.setText("A");
																														}
																														else {
																															if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 52)) {
																																points4.setText("12");
																																grade4.setText("A");
																															}
																															else {
																																if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 53)) {
																																	points4.setText("12");
																																	grade4.setText("A");
																																}
																																else {
																																	if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 54)) {
																																		points4.setText("12");
																																		grade4.setText("A");
																																	}
																																	else {
																																		if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 55)) {
																																			points4.setText("12");
																																			grade4.setText("A");
																																		}
																																		else {
																																			if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 56)) {
																																				points4.setText("12");
																																				grade4.setText("A");
																																			}
																																			else {
																																				if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 57)) {
																																					points4.setText("12");
																																					grade4.setText("A");
																																				}
																																				else {
																																					if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 58)) {
																																						points4.setText("12");
																																						grade4.setText("A");
																																					}
																																					else {
																																						if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 59)) {
																																							points4.setText("12");
																																							grade4.setText("A");
																																						}
																																						else {
																																							if ((Double.parseDouble(ch_sub4.getText().toString()) == 3) && (Double.parseDouble(no4.getText().toString()) == 60)) {
																																								points4.setText("12");
																																								grade4.setText("A");
																																							}
																																							else {
																																								_check_colors();
																																							}
																																						}
																																					}
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	private void _sub4_ch4 () {
		if (ch_sub4.getText().toString().equals("") || no4.getText().toString().equals("")) {

		}
		else {
			if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 32)) {
				points4.setText("4");
				grade4.setText("D");
			}
			else {
				if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 33)) {
					points4.setText("4.5");
					grade4.setText("D");
				}
				else {
					if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 34)) {
						points4.setText("5");
						grade4.setText("D");
					}
					else {
						if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 35)) {
							points4.setText("5.5");
							grade4.setText("D");
						}
						else {
							if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 36)) {
								points4.setText("6");
								grade4.setText("D");
							}
							else {
								if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 37)) {
									points4.setText("6.5");
									grade4.setText("D");
								}
								else {
									if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 38)) {
										points4.setText("7");
										grade4.setText("D");
									}
									else {
										if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 39)) {
											points4.setText("7.5");
											grade4.setText("D");
										}
										else {
											if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 40)) {
												points4.setText("8");
												grade4.setText("C");
											}
											else {
												if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 41)) {
													points4.setText("8.33");
													grade4.setText("C");
												}
												else {
													if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 42)) {
														points4.setText("8.67");
														grade4.setText("C");
													}
													else {
														if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 43)) {
															points4.setText("9");
															grade4.setText("C");
														}
														else {
															if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 44)) {
																points4.setText("9.33");
																grade4.setText("C");
															}
															else {
																if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 45)) {
																	points4.setText("9.67");
																	grade4.setText("C");
																}
																else {
																	if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 46)) {
																		points4.setText("10");
																		grade4.setText("C");
																	}
																	else {
																		if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 47)) {
																			points4.setText("10.33");
																			grade4.setText("C");
																		}
																		else {
																			if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 48)) {
																				points4.setText("10.67");
																				grade4.setText("C");
																			}
																			else {
																				if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 49)) {
																					points4.setText("11");
																					grade4.setText("C");
																				}
																				else {
																					if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 50)) {
																						points4.setText("11.33");
																						grade4.setText("C");
																					}
																					else {
																						if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 51)) {
																							points4.setText("11.67");
																							grade4.setText("C");
																						}
																						else {
																							if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 52)) {
																								points4.setText("12");
																								grade4.setText("B");
																							}
																							else {
																								if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 53)) {
																									points4.setText("12.33");
																									grade4.setText("B");
																								}
																								else {
																									if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 54)) {
																										points4.setText("12.67");
																										grade4.setText("B");
																									}
																									else {
																										if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 55)) {
																											points4.setText("13");
																											grade4.setText("B");
																										}
																										else {
																											if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 56)) {
																												points4.setText("13.33");
																												grade4.setText("B");
																											}
																											else {
																												if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 57)) {
																													points4.setText("13.67");
																													grade4.setText("B");
																												}
																												else {
																													if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 58)) {
																														points4.setText("14");
																														grade4.setText("B");
																													}
																													else {
																														if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 59)) {
																															points4.setText("14.33");
																															grade4.setText("B");
																														}
																														else {
																															if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 60)) {
																																points4.setText("14.67");
																																grade4.setText("B");
																															}
																															else {
																																if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 61)) {
																																	points4.setText("15");
																																	grade4.setText("B");
																																}
																																else {
																																	if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 62)) {
																																		points4.setText("15.33");
																																		grade4.setText("B");
																																	}
																																	else {
																																		if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 63)) {
																																			points4.setText("15.67");
																																			grade4.setText("B");
																																		}
																																		else {
																																			if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 64)) {
																																				points4.setText("16");
																																				grade4.setText("A");
																																			}
																																			else {
																																				if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 65)) {
																																					points4.setText("16");
																																					grade4.setText("A");
																																				}
																																				else {
																																					if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 66)) {
																																						points4.setText("16");
																																						grade4.setText("A");
																																					}
																																					else {
																																						if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 67)) {
																																							points4.setText("16");
																																							grade4.setText("A");
																																						}
																																						else {
																																							if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 68)) {
																																								points4.setText("16");
																																								grade4.setText("A");
																																							}
																																							else {
																																								if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 69)) {
																																									points4.setText("16");
																																									grade4.setText("A");
																																								}
																																								else {
																																									if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 70)) {
																																										points4.setText("16");
																																										grade4.setText("A");
																																									}
																																									else {
																																										if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 71)) {
																																											points4.setText("16");
																																											grade4.setText("A");
																																										}
																																										else {
																																											if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 72)) {
																																												points4.setText("16");
																																												grade4.setText("A");
																																											}
																																											else {
																																												if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 73)) {
																																													points4.setText("16");
																																													grade4.setText("A");
																																												}
																																												else {
																																													if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 74)) {
																																														points4.setText("16");
																																														grade4.setText("A");
																																													}
																																													else {
																																														if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 75)) {
																																															points4.setText("16");
																																															grade4.setText("A");
																																														}
																																														else {
																																															if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 76)) {
																																																points4.setText("16");
																																																grade4.setText("A");
																																															}
																																															else {
																																																if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 77)) {
																																																	points4.setText("16");
																																																	grade4.setText("A");
																																																}
																																																else {
																																																	if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 78)) {
																																																		points4.setText("16");
																																																		grade4.setText("A");
																																																	}
																																																	else {
																																																		if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 79)) {
																																																			points4.setText("16");
																																																			grade4.setText("A");
																																																		}
																																																		else {
																																																			if ((Double.parseDouble(ch_sub4.getText().toString()) == 4) && (Double.parseDouble(no4.getText().toString()) == 80)) {
																																																				points4.setText("16");
																																																				grade4.setText("A");
																																																			}
																																																			else {
																																																				_check_colors();
																																																			}
																																																		}
																																																	}
																																																}
																																															}
																																														}
																																													}
																																												}
																																											}
																																										}
																																									}
																																								}
																																							}
																																						}
																																					}
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	private void _sub4_ch5 () {

	}
	private void _sub5_ch1 () {
		if (ch_sub5.getText().toString().equals("") || no5.getText().toString().equals("")) {

		}
		else {
			if ((Double.parseDouble(ch_sub5.getText().toString()) == 1) && (Double.parseDouble(no5.getText().toString()) == 8)) {
				points5.setText("1");
				grade5.setText("D");
			}
			else {
				if ((Double.parseDouble(ch_sub5.getText().toString()) == 1) && (Double.parseDouble(no5.getText().toString()) == 9)) {
					points5.setText("1.5");
					grade5.setText("D");
				}
				else {
					if ((Double.parseDouble(ch_sub5.getText().toString()) == 1) && (Double.parseDouble(no5.getText().toString()) == 10)) {
						points5.setText("2");
						grade5.setText("C");
					}
					else {
						if ((Double.parseDouble(ch_sub5.getText().toString()) == 1) && (Double.parseDouble(no5.getText().toString()) == 11)) {
							points5.setText("2.33");
							grade5.setText("C");
						}
						else {
							if ((Double.parseDouble(ch_sub5.getText().toString()) == 1) && (Double.parseDouble(no5.getText().toString()) == 12)) {
								points5.setText("2.67");
								grade5.setText("C");
							}
							else {
								if ((Double.parseDouble(ch_sub5.getText().toString()) == 1) && (Double.parseDouble(no5.getText().toString()) == 13)) {
									points5.setText("3");
									grade5.setText("B");
								}
								else {
									if ((Double.parseDouble(ch_sub5.getText().toString()) == 1) && (Double.parseDouble(no5.getText().toString()) == 14)) {
										points5.setText("3.33");
										grade5.setText("B");
									}
									else {
										if ((Double.parseDouble(ch_sub5.getText().toString()) == 1) && (Double.parseDouble(no5.getText().toString()) == 15)) {
											points5.setText("3.67");
											grade5.setText("B");
										}
										else {
											if ((Double.parseDouble(ch_sub5.getText().toString()) == 1) && (Double.parseDouble(no5.getText().toString()) == 16)) {
												points5.setText("4");
												grade5.setText("A");
											}
											else {
												if ((Double.parseDouble(ch_sub5.getText().toString()) == 1) && (Double.parseDouble(no5.getText().toString()) == 17)) {
													points5.setText("4");
													grade5.setText("A");
												}
												else {
													if ((Double.parseDouble(ch_sub5.getText().toString()) == 1) && (Double.parseDouble(no5.getText().toString()) == 18)) {
														points5.setText("4");
														grade5.setText("A");
													}
													else {
														if ((Double.parseDouble(ch_sub5.getText().toString()) == 1) && (Double.parseDouble(no5.getText().toString()) == 19)) {
															points5.setText("4");
															grade5.setText("A");
														}
														else {
															if ((Double.parseDouble(ch_sub5.getText().toString()) == 1) && (Double.parseDouble(no5.getText().toString()) == 20)) {
																points5.setText("4");
																grade5.setText("A");
															}
															else {
																_check_colors();
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	private void _sub5_ch2 () {
		if (ch_sub5.getText().toString().equals("") || no5.getText().toString().equals("")) {

		}
		else {
			if ((Double.parseDouble(ch_sub5.getText().toString()) == 2) && (Double.parseDouble(no5.getText().toString()) == 16)) {
				points5.setText("2");
				grade5.setText("D");
			}
			else {
				if ((Double.parseDouble(ch_sub5.getText().toString()) == 2) && (Double.parseDouble(no5.getText().toString()) == 17)) {
					points5.setText("2.5");
					grade5.setText("D");
				}
				else {
					if ((Double.parseDouble(ch_sub5.getText().toString()) == 2) && (Double.parseDouble(no5.getText().toString()) == 18)) {
						points5.setText("3");
						grade5.setText("D");
					}
					else {
						if ((Double.parseDouble(ch_sub5.getText().toString()) == 2) && (Double.parseDouble(no5.getText().toString()) == 19)) {
							points5.setText("3.5");
							grade5.setText("D");
						}
						else {
							if ((Double.parseDouble(ch_sub5.getText().toString()) == 2) && (Double.parseDouble(no5.getText().toString()) == 20)) {
								points5.setText("4");
								grade5.setText("C");
							}
							else {
								if ((Double.parseDouble(ch_sub5.getText().toString()) == 2) && (Double.parseDouble(no5.getText().toString()) == 21)) {
									points5.setText("4.33");
									grade5.setText("C");
								}
								else {
									if ((Double.parseDouble(ch_sub5.getText().toString()) == 2) && (Double.parseDouble(no5.getText().toString()) == 22)) {
										points5.setText("4.67");
										grade5.setText("C");
									}
									else {
										if ((Double.parseDouble(ch_sub5.getText().toString()) == 2) && (Double.parseDouble(no5.getText().toString()) == 23)) {
											points5.setText("5");
											grade5.setText("C");
										}
										else {
											if ((Double.parseDouble(ch_sub5.getText().toString()) == 2) && (Double.parseDouble(no5.getText().toString()) == 24)) {
												points5.setText("5.33");
												grade5.setText("C");
											}
											else {
												if ((Double.parseDouble(ch_sub5.getText().toString()) == 2) && (Double.parseDouble(no5.getText().toString()) == 25)) {
													points5.setText("5.67");
													grade5.setText("C");
												}
												else {
													if ((Double.parseDouble(ch_sub5.getText().toString()) == 2) && (Double.parseDouble(no5.getText().toString()) == 26)) {
														points5.setText("6");
														grade5.setText("B");
													}
													else {
														if ((Double.parseDouble(ch_sub5.getText().toString()) == 2) && (Double.parseDouble(no5.getText().toString()) == 27)) {
															points5.setText("6.33");
															grade5.setText("B");
														}
														else {
															if ((Double.parseDouble(ch_sub5.getText().toString()) == 2) && (Double.parseDouble(no5.getText().toString()) == 28)) {
																points5.setText("6.67");
																grade5.setText("B");
																points5.setTextColor(0xFF4CAF50);
																grade5.setTextColor(0xFF4CAF50);
															}
															else {
																if ((Double.parseDouble(ch_sub5.getText().toString()) == 2) && (Double.parseDouble(no5.getText().toString()) == 29)) {
																	points5.setText("7");
																	grade5.setText("B");
																	points5.setTextColor(0xFF4CAF50);
																	grade5.setTextColor(0xFF4CAF50);
																}
																else {
																	if ((Double.parseDouble(ch_sub5.getText().toString()) == 2) && (Double.parseDouble(no5.getText().toString()) == 30)) {
																		points5.setText("7.33");
																		grade5.setText("B");
																		points5.setTextColor(0xFF4CAF50);
																		grade5.setTextColor(0xFF4CAF50);
																	}
																	else {
																		if ((Double.parseDouble(ch_sub5.getText().toString()) == 2) && (Double.parseDouble(no5.getText().toString()) == 31)) {
																			points5.setText("7.67");
																			grade5.setText("B");
																			points5.setTextColor(0xFF4CAF50);
																			grade5.setTextColor(0xFF4CAF50);
																		}
																		else {
																			if ((Double.parseDouble(ch_sub5.getText().toString()) == 2) && (Double.parseDouble(no5.getText().toString()) == 32)) {
																				points5.setText("8");
																				grade5.setText("A");
																				points5.setTextColor(0xFF4CAF50);
																				grade5.setTextColor(0xFF4CAF50);
																			}
																			else {
																				if ((Double.parseDouble(ch_sub5.getText().toString()) == 2) && (Double.parseDouble(no5.getText().toString()) == 33)) {
																					points5.setText("8");
																					grade5.setText("A");
																					points5.setTextColor(0xFF4CAF50);
																					grade5.setTextColor(0xFF4CAF50);
																				}
																				else {
																					if ((Double.parseDouble(ch_sub5.getText().toString()) == 2) && (Double.parseDouble(no5.getText().toString()) == 34)) {
																						points5.setText("8");
																						grade5.setText("A");
																						points5.setTextColor(0xFF4CAF50);
																						grade5.setTextColor(0xFF4CAF50);
																					}
																					else {
																						if ((Double.parseDouble(ch_sub5.getText().toString()) == 2) && (Double.parseDouble(no5.getText().toString()) == 35)) {
																							points5.setText("8");
																							grade5.setText("A");
																							points5.setTextColor(0xFF4CAF50);
																							grade5.setTextColor(0xFF4CAF50);
																						}
																						else {
																							if ((Double.parseDouble(ch_sub5.getText().toString()) == 2) && (Double.parseDouble(no5.getText().toString()) == 36)) {
																								points5.setText("8");
																								grade5.setText("A");
																								points5.setTextColor(0xFF4CAF50);
																								grade5.setTextColor(0xFF4CAF50);
																							}
																							else {
																								if ((Double.parseDouble(ch_sub5.getText().toString()) == 2) && (Double.parseDouble(no5.getText().toString()) == 37)) {
																									points5.setText("8");
																									grade5.setText("A");
																									points5.setTextColor(0xFF4CAF50);
																									grade5.setTextColor(0xFF4CAF50);
																								}
																								else {
																									if ((Double.parseDouble(ch_sub5.getText().toString()) == 2) && (Double.parseDouble(no5.getText().toString()) == 38)) {
																										points5.setText("8");
																										grade5.setText("A");
																										points5.setTextColor(0xFF4CAF50);
																										grade5.setTextColor(0xFF4CAF50);
																									}
																									else {
																										if ((Double.parseDouble(ch_sub5.getText().toString()) == 2) && (Double.parseDouble(no5.getText().toString()) == 39)) {
																											points5.setText("8");
																											grade5.setText("A");
																											points5.setTextColor(0xFF4CAF50);
																											grade5.setTextColor(0xFF4CAF50);
																										}
																										else {
																											if ((Double.parseDouble(ch_sub5.getText().toString()) == 2) && (Double.parseDouble(no5.getText().toString()) == 40)) {
																												points5.setText("8");
																												grade5.setText("A");
																												points5.setTextColor(0xFF4CAF50);
																												grade5.setTextColor(0xFF4CAF50);
																											}
																											else {
																												_check_colors();
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	private void _sub5_ch3 () {
		if (ch_sub5.getText().toString().equals("") || no5.getText().toString().equals("")) {

		}
		else {
			if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 24)) {
				points5.setText("3");
				grade5.setText("D");
			}
			else {
				if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 25)) {
					points5.setText("3.5");
					grade5.setText("D");
				}
				else {
					if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 26)) {
						points5.setText("4");
						grade5.setText("D");
					}
					else {
						if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 27)) {
							points5.setText("4.5");
							grade5.setText("D");
						}
						else {
							if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 28)) {
								points5.setText("5");
								grade5.setText("D");
							}
							else {
								if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 29)) {
									points5.setText("5.5");
									grade5.setText("D");
								}
								else {
									if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 30)) {
										points5.setText("6");
										grade5.setText("C");
									}
									else {
										if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 31)) {
											points5.setText("6.33");
											grade5.setText("C");
										}
										else {
											if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 32)) {
												points5.setText("6.67");
												grade5.setText("C");
											}
											else {
												if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 33)) {
													points5.setText("7");
													grade5.setText("C");
												}
												else {
													if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 34)) {
														points5.setText("7.33");
														grade5.setText("C");
													}
													else {
														if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 35)) {
															points5.setText("7.67");
															grade5.setText("C");
														}
														else {
															if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 36)) {
																points5.setText("8");
																grade5.setText("C");
															}
															else {
																if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 37)) {
																	points5.setText("8.33");
																	grade5.setText("C");
																}
																else {
																	if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 38)) {
																		points5.setText("8.67");
																		grade5.setText("C");
																	}
																	else {
																		if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 39)) {
																			points5.setText("9");
																			grade5.setText("B");
																			grade5.setTextColor(0xFFFFC107);
																		}
																		else {
																			if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 40)) {
																				points5.setText("9.33");
																				grade5.setText("B");
																				grade5.setTextColor(0xFFFFC107);
																			}
																			else {
																				if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 41)) {
																					points5.setText("9.67");
																					grade5.setText("B");
																					grade5.setTextColor(0xFFFFC107);
																				}
																				else {
																					if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 42)) {
																						points5.setText("10");
																						grade5.setText("B");
																						grade5.setTextColor(0xFFFFC107);
																					}
																					else {
																						if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 43)) {
																							points5.setText("10.33");
																							grade5.setText("B");
																							grade5.setTextColor(0xFFFFC107);
																						}
																						else {
																							if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 44)) {
																								points5.setText("10.67");
																								grade5.setText("B");
																								grade5.setTextColor(0xFFFFC107);
																							}
																							else {
																								if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 45)) {
																									points5.setText("11");
																									grade5.setText("B");
																									grade5.setTextColor(0xFFFFC107);
																								}
																								else {
																									if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 46)) {
																										points5.setText("11.33");
																										grade5.setText("B");
																										grade5.setTextColor(0xFFFFC107);
																									}
																									else {
																										if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 47)) {
																											points5.setText("11.67");
																											grade5.setText("B");
																											grade5.setTextColor(0xFFFFC107);
																										}
																										else {
																											if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 48)) {
																												points5.setText("12");
																												grade5.setText("A");
																											}
																											else {
																												if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 49)) {
																													points5.setText("12");
																													grade5.setText("A");
																												}
																												else {
																													if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 50)) {
																														points5.setText("12");
																														grade5.setText("A");
																													}
																													else {
																														if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 51)) {
																															points5.setText("12");
																															grade5.setText("A");
																														}
																														else {
																															if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 52)) {
																																points5.setText("12");
																																grade5.setText("A");
																															}
																															else {
																																if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 53)) {
																																	points5.setText("12");
																																	grade5.setText("A");
																																}
																																else {
																																	if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 54)) {
																																		points5.setText("12");
																																		grade5.setText("A");
																																	}
																																	else {
																																		if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 55)) {
																																			points5.setText("12");
																																			grade5.setText("A");
																																		}
																																		else {
																																			if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 56)) {
																																				points5.setText("12");
																																				grade5.setText("A");
																																			}
																																			else {
																																				if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 57)) {
																																					points5.setText("12");
																																					grade5.setText("A");
																																				}
																																				else {
																																					if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 58)) {
																																						points5.setText("12");
																																						grade5.setText("A");
																																					}
																																					else {
																																						if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 59)) {
																																							points5.setText("12");
																																							grade5.setText("A");
																																						}
																																						else {
																																							if ((Double.parseDouble(ch_sub5.getText().toString()) == 3) && (Double.parseDouble(no5.getText().toString()) == 60)) {
																																								points5.setText("12");
																																								grade5.setText("A");
																																							}
																																							else {
																																								_check_colors();
																																							}
																																						}
																																					}
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	private void _sub5_ch4 () {
		if (ch_sub5.getText().toString().equals("") || no5.getText().toString().equals("")) {

		}
		else {
			if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 32)) {
				points5.setText("4");
				grade5.setText("D");
			}
			else {
				if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 33)) {
					points5.setText("4.5");
					grade5.setText("D");
				}
				else {
					if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 34)) {
						points5.setText("5");
						grade5.setText("D");
					}
					else {
						if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 35)) {
							points5.setText("5.5");
							grade5.setText("D");
						}
						else {
							if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 36)) {
								points5.setText("6");
								grade5.setText("D");
							}
							else {
								if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 37)) {
									points5.setText("6.5");
									grade5.setText("D");
								}
								else {
									if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 38)) {
										points5.setText("7");
										grade5.setText("D");
									}
									else {
										if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 39)) {
											points5.setText("7.5");
											grade5.setText("D");
										}
										else {
											if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 40)) {
												points5.setText("8");
												grade5.setText("C");
											}
											else {
												if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 41)) {
													points5.setText("8.33");
													grade5.setText("C");
												}
												else {
													if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 42)) {
														points5.setText("8.67");
														grade5.setText("C");
													}
													else {
														if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 43)) {
															points5.setText("9");
															grade5.setText("C");
														}
														else {
															if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 44)) {
																points5.setText("9.33");
																grade5.setText("C");
															}
															else {
																if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 45)) {
																	points5.setText("9.67");
																	grade5.setText("C");
																}
																else {
																	if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 46)) {
																		points5.setText("10");
																		grade5.setText("C");
																	}
																	else {
																		if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 47)) {
																			points5.setText("10.33");
																			grade5.setText("C");
																		}
																		else {
																			if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 48)) {
																				points5.setText("10.67");
																				grade5.setText("C");
																			}
																			else {
																				if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 49)) {
																					points5.setText("11");
																					grade5.setText("C");
																				}
																				else {
																					if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 50)) {
																						points5.setText("11.33");
																						grade5.setText("C");
																					}
																					else {
																						if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 51)) {
																							points5.setText("11.67");
																							grade5.setText("C");
																						}
																						else {
																							if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 52)) {
																								points5.setText("12");
																								grade5.setText("B");
																							}
																							else {
																								if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 53)) {
																									points5.setText("12.33");
																									grade5.setText("B");
																								}
																								else {
																									if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 54)) {
																										points5.setText("12.67");
																										grade5.setText("B");
																									}
																									else {
																										if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 55)) {
																											points5.setText("13");
																											grade5.setText("B");
																										}
																										else {
																											if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 56)) {
																												points5.setText("13.33");
																												grade5.setText("B");
																											}
																											else {
																												if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 57)) {
																													points5.setText("13.67");
																													grade5.setText("B");
																												}
																												else {
																													if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 58)) {
																														points5.setText("14");
																														grade5.setText("B");
																													}
																													else {
																														if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 59)) {
																															points5.setText("14.33");
																															grade5.setText("B");
																														}
																														else {
																															if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 60)) {
																																points5.setText("14.67");
																																grade5.setText("B");
																															}
																															else {
																																if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 61)) {
																																	points5.setText("15");
																																	grade5.setText("B");
																																}
																																else {
																																	if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 62)) {
																																		points5.setText("15.33");
																																		grade5.setText("B");
																																	}
																																	else {
																																		if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 63)) {
																																			points5.setText("15.67");
																																			grade5.setText("B");
																																		}
																																		else {
																																			if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 64)) {
																																				points5.setText("16");
																																				grade5.setText("A");
																																			}
																																			else {
																																				if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 65)) {
																																					points5.setText("16");
																																					grade5.setText("A");
																																				}
																																				else {
																																					if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 66)) {
																																						points5.setText("16");
																																						grade5.setText("A");
																																					}
																																					else {
																																						if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 67)) {
																																							points5.setText("16");
																																							grade5.setText("A");
																																						}
																																						else {
																																							if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 68)) {
																																								points5.setText("16");
																																								grade5.setText("A");
																																							}
																																							else {
																																								if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 69)) {
																																									points5.setText("16");
																																									grade5.setText("A");
																																								}
																																								else {
																																									if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 70)) {
																																										points5.setText("16");
																																										grade5.setText("A");
																																									}
																																									else {
																																										if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 71)) {
																																											points5.setText("16");
																																											grade5.setText("A");
																																										}
																																										else {
																																											if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 72)) {
																																												points5.setText("16");
																																												grade5.setText("A");
																																											}
																																											else {
																																												if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 73)) {
																																													points5.setText("16");
																																													grade5.setText("A");
																																												}
																																												else {
																																													if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 74)) {
																																														points5.setText("16");
																																														grade5.setText("A");
																																													}
																																													else {
																																														if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 75)) {
																																															points5.setText("16");
																																															grade5.setText("A");
																																														}
																																														else {
																																															if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 76)) {
																																																points5.setText("16");
																																																grade5.setText("A");
																																															}
																																															else {
																																																if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 77)) {
																																																	points5.setText("16");
																																																	grade5.setText("A");
																																																}
																																																else {
																																																	if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 78)) {
																																																		points5.setText("16");
																																																		grade5.setText("A");
																																																	}
																																																	else {
																																																		if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 79)) {
																																																			points5.setText("16");
																																																			grade5.setText("A");
																																																		}
																																																		else {
																																																			if ((Double.parseDouble(ch_sub5.getText().toString()) == 4) && (Double.parseDouble(no5.getText().toString()) == 80)) {
																																																				points5.setText("16");
																																																				grade5.setText("A");
																																																			}
																																																			else {
																																																				_check_colors();
																																																			}
																																																		}
																																																	}
																																																}
																																															}
																																														}
																																													}
																																												}
																																											}
																																										}
																																									}
																																								}
																																							}
																																						}
																																					}
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	private void _sub5_ch5 () {

	}
	private void _sub6_ch1 () {
		if (ch_sub6.getText().toString().equals("") || no6.getText().toString().equals("")) {

		}
		else {
			if ((Double.parseDouble(ch_sub6.getText().toString()) == 1) && (Double.parseDouble(no6.getText().toString()) == 8)) {
				points6.setText("1");
				grade6.setText("D");
				grade6.setTextColor(0xFFF44336);
			}
			else {
				if ((Double.parseDouble(ch_sub6.getText().toString()) == 1) && (Double.parseDouble(no6.getText().toString()) == 9)) {
					points6.setText("1.5");
					grade6.setText("D");
					grade6.setTextColor(0xFFF44336);
				}
				else {
					if ((Double.parseDouble(ch_sub6.getText().toString()) == 1) && (Double.parseDouble(no6.getText().toString()) == 10)) {
						points6.setText("2");
						grade6.setText("C");
						grade6.setTextColor(0xFFFF5722);
					}
					else {
						if ((Double.parseDouble(ch_sub6.getText().toString()) == 1) && (Double.parseDouble(no6.getText().toString()) == 11)) {
							points6.setText("2.33");
							grade6.setText("C");
							grade6.setTextColor(0xFFFF5722);
						}
						else {
							if ((Double.parseDouble(ch_sub6.getText().toString()) == 1) && (Double.parseDouble(no6.getText().toString()) == 12)) {
								points6.setText("2.67");
								grade6.setText("C");
								grade6.setTextColor(0xFFFF5722);
							}
							else {
								if ((Double.parseDouble(ch_sub6.getText().toString()) == 1) && (Double.parseDouble(no6.getText().toString()) == 13)) {
									points6.setText("3");
									grade6.setText("B");
									grade6.setTextColor(0xFFFFC107);
								}
								else {
									if ((Double.parseDouble(ch_sub6.getText().toString()) == 1) && (Double.parseDouble(no6.getText().toString()) == 14)) {
										points6.setText("3.33");
										grade6.setText("B");
										grade6.setTextColor(0xFFFFC107);
									}
									else {
										if ((Double.parseDouble(ch_sub6.getText().toString()) == 1) && (Double.parseDouble(no6.getText().toString()) == 15)) {
											points6.setText("3.67");
											grade6.setText("B");
											grade6.setTextColor(0xFFFFC107);
										}
										else {
											if ((Double.parseDouble(ch_sub6.getText().toString()) == 1) && (Double.parseDouble(no6.getText().toString()) == 16)) {
												points6.setText("4");
												grade6.setText("A");
												grade6.setTextColor(0xFF4CAF50);
											}
											else {
												if ((Double.parseDouble(ch_sub6.getText().toString()) == 1) && (Double.parseDouble(no6.getText().toString()) == 17)) {
													points6.setText("4");
													grade6.setText("A");
													grade6.setTextColor(0xFF4CAF50);
												}
												else {
													if ((Double.parseDouble(ch_sub6.getText().toString()) == 1) && (Double.parseDouble(no6.getText().toString()) == 18)) {
														points6.setText("4");
														grade6.setText("A");
														grade6.setTextColor(0xFF4CAF50);
													}
													else {
														if ((Double.parseDouble(ch_sub6.getText().toString()) == 1) && (Double.parseDouble(no6.getText().toString()) == 19)) {
															points6.setText("4");
															grade6.setText("A");
															grade6.setTextColor(0xFF4CAF50);
														}
														else {
															if ((Double.parseDouble(ch_sub6.getText().toString()) == 1) && (Double.parseDouble(no6.getText().toString()) == 20)) {
																points6.setText("4");
																grade6.setText("A");
																grade6.setTextColor(0xFF4CAF50);
															}
															else {
																_check_colors();
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	private void _sub6_ch2 () {
		if (ch_sub6.getText().toString().equals("") || no6.getText().toString().equals("")) {

		}
		else {
			if ((Double.parseDouble(ch_sub6.getText().toString()) == 2) && (Double.parseDouble(no6.getText().toString()) == 16)) {
				points6.setText("2");
				grade6.setText("D");
			}
			else {
				if ((Double.parseDouble(ch_sub6.getText().toString()) == 2) && (Double.parseDouble(no6.getText().toString()) == 17)) {
					points6.setText("2.5");
					grade6.setText("D");
				}
				else {
					if ((Double.parseDouble(ch_sub6.getText().toString()) == 2) && (Double.parseDouble(no6.getText().toString()) == 18)) {
						points6.setText("3");
						grade6.setText("D");
					}
					else {
						if ((Double.parseDouble(ch_sub6.getText().toString()) == 2) && (Double.parseDouble(no6.getText().toString()) == 19)) {
							points6.setText("3.5");
							grade6.setText("D");
						}
						else {
							if ((Double.parseDouble(ch_sub6.getText().toString()) == 2) && (Double.parseDouble(no6.getText().toString()) == 20)) {
								points6.setText("4");
								grade6.setText("C");
							}
							else {
								if ((Double.parseDouble(ch_sub6.getText().toString()) == 2) && (Double.parseDouble(no6.getText().toString()) == 21)) {
									points6.setText("4.33");
									grade6.setText("C");
								}
								else {
									if ((Double.parseDouble(ch_sub6.getText().toString()) == 2) && (Double.parseDouble(no6.getText().toString()) == 22)) {
										points6.setText("4.67");
										grade6.setText("C");
									}
									else {
										if ((Double.parseDouble(ch_sub6.getText().toString()) == 2) && (Double.parseDouble(no6.getText().toString()) == 23)) {
											points6.setText("5");
											grade6.setText("C");
										}
										else {
											if ((Double.parseDouble(ch_sub6.getText().toString()) == 2) && (Double.parseDouble(no6.getText().toString()) == 24)) {
												points6.setText("5.33");
												grade6.setText("C");
											}
											else {
												if ((Double.parseDouble(ch_sub6.getText().toString()) == 2) && (Double.parseDouble(no6.getText().toString()) == 25)) {
													points6.setText("5.67");
													grade6.setText("C");
												}
												else {
													if ((Double.parseDouble(ch_sub6.getText().toString()) == 2) && (Double.parseDouble(no6.getText().toString()) == 26)) {
														points6.setText("6");
														grade6.setText("B");
													}
													else {
														if ((Double.parseDouble(ch_sub6.getText().toString()) == 2) && (Double.parseDouble(no6.getText().toString()) == 27)) {
															points6.setText("6.33");
															grade6.setText("B");
														}
														else {
															if ((Double.parseDouble(ch_sub6.getText().toString()) == 2) && (Double.parseDouble(no6.getText().toString()) == 28)) {
																points6.setText("6.67");
																grade6.setText("B");
															}
															else {
																if ((Double.parseDouble(ch_sub6.getText().toString()) == 2) && (Double.parseDouble(no6.getText().toString()) == 29)) {
																	points6.setText("7");
																	grade6.setText("B");
																}
																else {
																	if ((Double.parseDouble(ch_sub6.getText().toString()) == 2) && (Double.parseDouble(no6.getText().toString()) == 30)) {
																		points6.setText("7.33");
																		grade6.setText("B");
																	}
																	else {
																		if ((Double.parseDouble(ch_sub6.getText().toString()) == 2) && (Double.parseDouble(no6.getText().toString()) == 31)) {
																			points6.setText("7.67");
																			grade6.setText("B");
																		}
																		else {
																			if ((Double.parseDouble(ch_sub6.getText().toString()) == 2) && (Double.parseDouble(no6.getText().toString()) == 32)) {
																				points6.setText("8");
																				grade6.setText("A");
																			}
																			else {
																				if ((Double.parseDouble(ch_sub6.getText().toString()) == 2) && (Double.parseDouble(no6.getText().toString()) == 33)) {
																					points6.setText("8");
																					grade6.setText("A");
																				}
																				else {
																					if ((Double.parseDouble(ch_sub6.getText().toString()) == 2) && (Double.parseDouble(no6.getText().toString()) == 34)) {
																						points6.setText("8");
																						grade6.setText("A");
																					}
																					else {
																						if ((Double.parseDouble(ch_sub6.getText().toString()) == 2) && (Double.parseDouble(no6.getText().toString()) == 35)) {
																							points6.setText("8");
																							grade6.setText("A");
																						}
																						else {
																							if ((Double.parseDouble(ch_sub6.getText().toString()) == 2) && (Double.parseDouble(no6.getText().toString()) == 36)) {
																								points6.setText("8");
																								grade6.setText("A");
																							}
																							else {
																								if ((Double.parseDouble(ch_sub6.getText().toString()) == 2) && (Double.parseDouble(no6.getText().toString()) == 37)) {
																									points6.setText("8");
																									grade6.setText("A");
																								}
																								else {
																									if ((Double.parseDouble(ch_sub6.getText().toString()) == 2) && (Double.parseDouble(no6.getText().toString()) == 38)) {
																										points6.setText("8");
																										grade6.setText("A");
																									}
																									else {
																										if ((Double.parseDouble(ch_sub6.getText().toString()) == 2) && (Double.parseDouble(no6.getText().toString()) == 39)) {
																											points6.setText("8");
																											grade6.setText("A");
																										}
																										else {
																											if ((Double.parseDouble(ch_sub6.getText().toString()) == 2) && (Double.parseDouble(no6.getText().toString()) == 40)) {
																												points6.setText("8");
																												grade6.setText("A");
																											}
																											else {
																												_check_colors();
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		_check_colors();
	}
	private void _sub6_ch3 () {
		if (ch_sub6.getText().toString().equals("") || no6.getText().toString().equals("")) {

		}
		else {
			if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 24)) {
				points6.setText("3");
				grade6.setText("D");
			}
			else {
				if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 25)) {
					points6.setText("3.5");
					grade6.setText("D");
				}
				else {
					if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 26)) {
						points6.setText("4");
						grade6.setText("D");
					}
					else {
						if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 27)) {
							points6.setText("4.5");
							grade6.setText("D");
						}
						else {
							if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 28)) {
								points6.setText("5");
								grade6.setText("D");
							}
							else {
								if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 29)) {
									points6.setText("5.5");
									grade6.setText("D");
								}
								else {
									if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 30)) {
										points6.setText("6");
										grade6.setText("C");
									}
									else {
										if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 31)) {
											points6.setText("6.33");
											grade6.setText("C");
										}
										else {
											if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 32)) {
												points6.setText("6.67");
												grade6.setText("C");
											}
											else {
												if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 33)) {
													points6.setText("7");
													grade6.setText("C");
												}
												else {
													if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 34)) {
														points6.setText("7.33");
														grade6.setText("C");
													}
													else {
														if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 35)) {
															points6.setText("7.67");
															grade6.setText("C");
														}
														else {
															if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 36)) {
																points6.setText("8");
																grade6.setText("C");
															}
															else {
																if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 37)) {
																	points6.setText("8.33");
																	grade6.setText("C");
																}
																else {
																	if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 38)) {
																		points6.setText("8.67");
																		grade6.setText("C");
																	}
																	else {
																		if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 39)) {
																			points6.setText("9");
																			grade6.setText("B");
																		}
																		else {
																			if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 40)) {
																				points6.setText("9.33");
																				grade6.setText("B");
																			}
																			else {
																				if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 41)) {
																					points6.setText("9.67");
																					grade6.setText("B");
																				}
																				else {
																					if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 42)) {
																						points6.setText("10");
																						grade6.setText("B");
																					}
																					else {
																						if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 43)) {
																							points6.setText("10.33");
																							grade6.setText("B");
																						}
																						else {
																							if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 44)) {
																								points6.setText("10.67");
																								grade6.setText("B");
																							}
																							else {
																								if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 45)) {
																									points6.setText("11");
																									grade6.setText("B");
																								}
																								else {
																									if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 46)) {
																										points6.setText("11.33");
																										grade6.setText("B");
																									}
																									else {
																										if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 47)) {
																											points6.setText("11.67");
																											grade6.setText("B");
																										}
																										else {
																											if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 48)) {
																												points6.setText("12");
																												grade6.setText("A");
																											}
																											else {
																												if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 49)) {
																													points6.setText("12");
																													grade6.setText("A");
																												}
																												else {
																													if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 50)) {
																														points6.setText("12");
																														grade6.setText("A");
																													}
																													else {
																														if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 51)) {
																															points6.setText("12");
																															grade6.setText("A");
																														}
																														else {
																															if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 52)) {
																																points6.setText("12");
																																grade6.setText("A");
																															}
																															else {
																																if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 53)) {
																																	points6.setText("12");
																																	grade6.setText("A");
																																}
																																else {
																																	if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 54)) {
																																		points6.setText("12");
																																		grade6.setText("A");
																																	}
																																	else {
																																		if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 55)) {
																																			points6.setText("12");
																																			grade6.setText("A");
																																		}
																																		else {
																																			if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 56)) {
																																				points6.setText("12");
																																				grade6.setText("A");
																																			}
																																			else {
																																				if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 57)) {
																																					points6.setText("12");
																																					grade6.setText("A");
																																				}
																																				else {
																																					if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 58)) {
																																						points6.setText("12");
																																						grade6.setText("A");
																																					}
																																					else {
																																						if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 59)) {
																																							points6.setText("12");
																																							grade6.setText("A");
																																						}
																																						else {
																																							if ((Double.parseDouble(ch_sub6.getText().toString()) == 3) && (Double.parseDouble(no6.getText().toString()) == 60)) {
																																								points6.setText("12");
																																								grade6.setText("A");
																																							}
																																							else {
																																								_check_colors();
																																							}
																																						}
																																					}
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	private void _sub6_ch4 () {
		if (ch_sub6.getText().toString().equals("") || no6.getText().toString().equals("")) {

		}
		else {
			if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 32)) {
				points6.setText("4");
				grade6.setText("D");
			}
			else {
				if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 33)) {
					points6.setText("4.5");
					grade6.setText("D");
				}
				else {
					if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 34)) {
						points6.setText("5");
						grade6.setText("D");
					}
					else {
						if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 35)) {
							points6.setText("5.5");
							grade6.setText("D");
						}
						else {
							if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 36)) {
								points6.setText("6");
								grade6.setText("D");
							}
							else {
								if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 37)) {
									points6.setText("6.5");
									grade6.setText("D");
								}
								else {
									if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 38)) {
										points6.setText("7");
										grade6.setText("D");
									}
									else {
										if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 39)) {
											points6.setText("7.5");
											grade6.setText("D");
										}
										else {
											if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 40)) {
												points6.setText("8");
												grade6.setText("C");
											}
											else {
												if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 41)) {
													points6.setText("8.33");
													grade6.setText("C");
												}
												else {
													if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 42)) {
														points6.setText("8.67");
														grade6.setText("C");
													}
													else {
														if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 43)) {
															points6.setText("9");
															grade6.setText("C");
														}
														else {
															if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 44)) {
																points6.setText("9.33");
																grade6.setText("C");
															}
															else {
																if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 45)) {
																	points6.setText("9.67");
																	grade6.setText("C");
																}
																else {
																	if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 46)) {
																		points6.setText("10");
																		grade6.setText("C");
																	}
																	else {
																		if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 47)) {
																			points6.setText("10.33");
																			grade6.setText("C");
																		}
																		else {
																			if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 48)) {
																				points6.setText("10.67");
																				grade6.setText("C");
																			}
																			else {
																				if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 49)) {
																					points6.setText("11");
																					grade6.setText("C");
																				}
																				else {
																					if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 50)) {
																						points6.setText("11.33");
																						grade6.setText("C");
																					}
																					else {
																						if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 51)) {
																							points6.setText("11.67");
																							grade6.setText("C");
																						}
																						else {
																							if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 52)) {
																								points6.setText("12");
																								grade6.setText("B");
																							}
																							else {
																								if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 53)) {
																									points6.setText("12.33");
																									grade6.setText("B");
																								}
																								else {
																									if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 54)) {
																										points6.setText("12.67");
																										grade6.setText("B");
																									}
																									else {
																										if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 55)) {
																											points6.setText("13");
																											grade6.setText("B");
																										}
																										else {
																											if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 56)) {
																												points6.setText("13.33");
																												grade6.setText("B");
																											}
																											else {
																												if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 57)) {
																													points6.setText("13.67");
																													grade6.setText("B");
																												}
																												else {
																													if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 58)) {
																														points6.setText("14");
																														grade6.setText("B");
																													}
																													else {
																														if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 59)) {
																															points6.setText("14.33");
																															grade6.setText("B");
																														}
																														else {
																															if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 60)) {
																																points6.setText("14.67");
																																grade6.setText("B");
																															}
																															else {
																																if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 61)) {
																																	points6.setText("15");
																																	grade6.setText("B");
																																}
																																else {
																																	if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 62)) {
																																		points6.setText("15.33");
																																		grade6.setText("B");
																																	}
																																	else {
																																		if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 63)) {
																																			points6.setText("15.67");
																																			grade6.setText("B");
																																		}
																																		else {
																																			if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 64)) {
																																				points6.setText("16");
																																				grade6.setText("A");
																																			}
																																			else {
																																				if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 65)) {
																																					points6.setText("16");
																																					grade6.setText("A");
																																				}
																																				else {
																																					if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 66)) {
																																						points6.setText("16");
																																						grade6.setText("A");
																																					}
																																					else {
																																						if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 67)) {
																																							points6.setText("16");
																																							grade6.setText("A");
																																						}
																																						else {
																																							if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 68)) {
																																								points6.setText("16");
																																								grade6.setText("A");
																																							}
																																							else {
																																								if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 69)) {
																																									points6.setText("16");
																																									grade6.setText("A");
																																								}
																																								else {
																																									if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 70)) {
																																										points6.setText("16");
																																										grade6.setText("A");
																																									}
																																									else {
																																										if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 71)) {
																																											points6.setText("16");
																																											grade6.setText("A");
																																										}
																																										else {
																																											if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 72)) {
																																												points6.setText("16");
																																												grade6.setText("A");
																																											}
																																											else {
																																												if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 73)) {
																																													points6.setText("16");
																																													grade6.setText("A");
																																												}
																																												else {
																																													if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 74)) {
																																														points6.setText("16");
																																														grade6.setText("A");
																																													}
																																													else {
																																														if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 75)) {
																																															points6.setText("16");
																																															grade6.setText("A");
																																														}
																																														else {
																																															if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 76)) {
																																																points6.setText("16");
																																																grade6.setText("A");
																																															}
																																															else {
																																																if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 77)) {
																																																	points6.setText("16");
																																																	grade6.setText("A");
																																																}
																																																else {
																																																	if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 78)) {
																																																		points6.setText("16");
																																																		grade6.setText("A");
																																																	}
																																																	else {
																																																		if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 79)) {
																																																			points6.setText("16");
																																																			grade6.setText("A");
																																																		}
																																																		else {
																																																			if ((Double.parseDouble(ch_sub6.getText().toString()) == 4) && (Double.parseDouble(no6.getText().toString()) == 80)) {
																																																				points6.setText("16");
																																																				grade6.setText("A");
																																																			}
																																																			else {
																																																				_check_colors();
																																																			}
																																																		}
																																																	}
																																																}
																																															}
																																														}
																																													}
																																												}
																																											}
																																										}
																																									}
																																								}
																																							}
																																						}
																																					}
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	private void _sub6_ch5 () {

	}
	private void _Reset () {
		allign_reset_calcula.setVisibility(View.GONE);
		submitdata.setVisibility(View.VISIBLE);
		ch_sub1.setText("");
		ch_sub2.setText("");
		ch_sub3.setText("");
		ch_sub4.setText("");
		ch_sub5.setText("");
		ch_sub6.setText("");
		no1.setText("");
		no2.setText("");
		no3.setText("");
		no4.setText("");
		no5.setText("");
		no6.setText("");
		points1.setText("");
		points2.setText("");
		points3.setText("");
		points4.setText("");
		points5.setText("");
		points6.setText("");
		grade1.setText("");
		grade2.setText("");
		grade3.setText("");
		grade4.setText("");
		grade5.setText("");
		grade6.setText("");
		allign_gpa_message.setVisibility(View.GONE);
		_check_colors();
	}
	private void _calculate_subject4 () {
		if (file.getString("subject", "").equals("4")) {
			allign_gpa_message.setVisibility(View.VISIBLE);
			p1 = Double.parseDouble(points1.getText().toString());
			p2 = Double.parseDouble(points2.getText().toString());
			p3 = Double.parseDouble(points3.getText().toString());
			p4 = Double.parseDouble(points4.getText().toString());
			if (points2.getText().toString().equals("") || (points3.getText().toString().equals("") || (points4.getText().toString().equals("") || points1.getText().toString().equals("")))) {
				showMessage("Enter valid data");
			}
			else {
				gpa.setText(String.valueOf((p1 + (p2 + (p3 + p4))) / (Double.parseDouble(ch_sub1.getText().toString()) + (Double.parseDouble(ch_sub2.getText().toString()) + (Double.parseDouble(ch_sub3.getText().toString()) + Double.parseDouble(ch_sub4.getText().toString()))))));
				_check_colors();
			}
		}
	}
	private void _calculate_subject5 () {
		if (file.getString("subject", "").equals("5")) {
			allign_gpa_message.setVisibility(View.VISIBLE);
			p1 = Double.parseDouble(points1.getText().toString());
			p2 = Double.parseDouble(points2.getText().toString());
			p3 = Double.parseDouble(points3.getText().toString());
			p4 = Double.parseDouble(points4.getText().toString());
			p5 = Double.parseDouble(points5.getText().toString());
			if (points2.getText().toString().equals("") || (points3.getText().toString().equals("") || (points4.getText().toString().equals("") || (points5.getText().toString().equals("") || points1.getText().toString().equals(""))))) {
				showMessage("Enter valid data");
			}
			else {
				gpa.setText(String.valueOf((p1 + (p2 + (p3 + (p5 + p4)))) / (Double.parseDouble(ch_sub1.getText().toString()) + (Double.parseDouble(ch_sub2.getText().toString()) + (Double.parseDouble(ch_sub3.getText().toString()) + (Double.parseDouble(ch_sub4.getText().toString()) + Double.parseDouble(ch_sub5.getText().toString())))))));
				_check_colors();
			}
		}
	}
	private void _calculate_subject6 () {
		if (file.getString("subject", "").equals("6")) {
			allign_gpa_message.setVisibility(View.VISIBLE);
			p1 = Double.parseDouble(points1.getText().toString());
			p2 = Double.parseDouble(points2.getText().toString());
			p3 = Double.parseDouble(points3.getText().toString());
			p4 = Double.parseDouble(points4.getText().toString());
			p5 = Double.parseDouble(points5.getText().toString());
			p6 = Double.parseDouble(points6.getText().toString());
			if (points2.getText().toString().equals("") || (points3.getText().toString().equals("") || (points4.getText().toString().equals("") || (points5.getText().toString().equals("") || (points1.getText().toString().equals("") || points6.getText().toString().equals("")))))) {
				showMessage("Enter valid data");
			}
			else {
				gpa.setText(String.valueOf((p1 + (p2 + (p3 + (p5 + (p4 + p6))))) / (Double.parseDouble(ch_sub1.getText().toString()) + (Double.parseDouble(ch_sub2.getText().toString()) + (Double.parseDouble(ch_sub3.getText().toString()) + (Double.parseDouble(ch_sub4.getText().toString()) + (Double.parseDouble(ch_sub5.getText().toString()) + Double.parseDouble(ch_sub6.getText().toString()))))))));
				_check_colors();
			}
		}
	}
	private void _check_all () {
		_ch1();
		_ch2();
		_ch3();
		_ch4();
		_sub2();
		_sub2_ch2();
		_sub2_ch3();
		_sub2_ch4();
		_sub3_ch1();
		_sub3_ch2();
		_sub3_ch3();
		_sub3_ch4();
		_sub4_ch1();
		_sub4_ch2();
		_sub4_ch3();
		_sub4_ch4();
		_sub4_ch5();
		_sub5_ch1();
		_sub5_ch2();
		_sub5_ch3();
		_sub5_ch4();
		_sub5_ch5();
		_sub6_ch1();
		_sub6_ch2();
		_sub6_ch3();
		_sub6_ch4();
		_sub6_ch5();
	}
	private void _disabla_input () {
		ch_sub1.setEnabled(false);
		ch_sub2.setEnabled(false);
		ch_sub3.setEnabled(false);
		ch_sub4.setEnabled(false);
		ch_sub5.setEnabled(false);
		ch_sub6.setEnabled(false);
		no1.setEnabled(false);
		no2.setEnabled(false);
		no3.setEnabled(false);
		no4.setEnabled(false);
		no5.setEnabled(false);
		no6.setEnabled(false);
	}
	private void _enable_input () {
		ch_sub1.setEnabled(true);
		ch_sub2.setEnabled(true);
		ch_sub3.setEnabled(true);
		ch_sub4.setEnabled(true);
		ch_sub5.setEnabled(true);
		ch_sub6.setEnabled(true);
		no1.setEnabled(true);
		no2.setEnabled(true);
		no3.setEnabled(true);
		no4.setEnabled(true);
		no5.setEnabled(true);
		no6.setEnabled(true);
	}
	private void _Check_Connection () {
		try {
		command = "ping -c 1 google.com";
		connected = (Runtime.getRuntime().exec (command).waitFor() == 0); } catch (Exception e){ showMessage(e.toString());}
	}
	private void _mode () {
		if (share.getString("mode", "").equals("1")) {
			linear_al_expt_welcm.setBackgroundResource(R.drawable.wal3);
			ch_sub1.setTextColor(0xFFFFFFFF);
			ch_sub2.setTextColor(0xFFFFFFFF);
			ch_sub3.setTextColor(0xFFFFFFFF);
			ch_sub4.setTextColor(0xFFFFFFFF);
			ch_sub5.setTextColor(0xFFFFFFFF);
			ch_sub6.setTextColor(0xFFFFFFFF);
			no1.setTextColor(0xFFFFFFFF);
			no2.setTextColor(0xFFFFFFFF);
			no3.setTextColor(0xFFFFFFFF);
			no4.setTextColor(0xFFFFFFFF);
			no5.setTextColor(0xFFFFFFFF);
			no6.setTextColor(0xFFFFFFFF);
			points1.setTextColor(0xFFFFFFFF);
			points2.setTextColor(0xFFFFFFFF);
			points3.setTextColor(0xFFFFFFFF);
			points4.setTextColor(0xFFFFFFFF);
			points5.setTextColor(0xFFFFFFFF);
			points6.setTextColor(0xFFFFFFFF);
			textview11.setTextColor(0xFFFFFFFF);
			gpa.setTextColor(0xFF4CAF50);
		}
		else {
			if (share.getString("mode", "").equals("0")) {
				linear_al_expt_welcm.setBackgroundResource(R.drawable.vcvvv);
				ch_sub1.setTextColor(0xFF000000);
				ch_sub2.setTextColor(0xFF000000);
				ch_sub3.setTextColor(0xFF000000);
				ch_sub4.setTextColor(0xFF000000);
				ch_sub5.setTextColor(0xFF000000);
				ch_sub6.setTextColor(0xFF000000);
				no1.setTextColor(0xFF000000);
				no2.setTextColor(0xFF000000);
				no3.setTextColor(0xFF000000);
				no4.setTextColor(0xFF000000);
				no5.setTextColor(0xFF000000);
				no6.setTextColor(0xFF000000);
				points1.setTextColor(0xFF000000);
				points2.setTextColor(0xFF000000);
				points3.setTextColor(0xFF000000);
				points4.setTextColor(0xFF000000);
				points5.setTextColor(0xFF000000);
				points6.setTextColor(0xFF000000);
				textview11.setTextColor(0xFF000000);
				gpa.setTextColor(0xFF4CAF50);
			}
		}
	}
	private void _rotation () {
		rotate = 0;
		calculate.setRotation((float)(rotate));
		time = new TimerTask() {
					@Override
						public void run() {
							runOnUiThread(new Runnable() {
							@Override
								public void run() {
										rotate = 90;
								calculate.setRotation((float)(rotate));
								}
							});
						}
					};
					_timer.schedule(time, (int)(1500));
		time = new TimerTask() {
					@Override
						public void run() {
							runOnUiThread(new Runnable() {
							@Override
								public void run() {
										rotate = 180;
								calculate.setRotation((float)(rotate));
								}
							});
						}
					};
					_timer.schedule(time, (int)(2000));
		time = new TimerTask() {
					@Override
						public void run() {
							runOnUiThread(new Runnable() {
							@Override
								public void run() {
										rotate = 270;
								calculate.setRotation((float)(rotate));
								}
							});
						}
					};
					_timer.schedule(time, (int)(2500));
		time = new TimerTask() {
					@Override
						public void run() {
							runOnUiThread(new Runnable() {
							@Override
								public void run() {
										rotate = 360;
								calculate.setRotation((float)(rotate));
								}
							});
						}
					};
					_timer.schedule(time, (int)(3000));
		time = new TimerTask() {
					@Override
						public void run() {
							runOnUiThread(new Runnable() {
							@Override
								public void run() {
										rotate = 0;
								calculate.setRotation((float)(rotate));
								}
							});
						}
					};
					_timer.schedule(time, (int)(3500));
		time = new TimerTask() {
					@Override
						public void run() {
							runOnUiThread(new Runnable() {
							@Override
								public void run() {
										rotate = 90;
								calculate.setRotation((float)(rotate));
								}
							});
						}
					};
					_timer.schedule(time, (int)(4000));
		time = new TimerTask() {
					@Override
						public void run() {
							runOnUiThread(new Runnable() {
							@Override
								public void run() {
										rotate = 180;
								calculate.setRotation((float)(rotate));
								}
							});
						}
					};
					_timer.schedule(time, (int)(4500));
		time = new TimerTask() {
					@Override
						public void run() {
							runOnUiThread(new Runnable() {
							@Override
								public void run() {
										rotate = 270;
								calculate.setRotation((float)(rotate));
								}
							});
						}
					};
					_timer.schedule(time, (int)(5000));
		time = new TimerTask() {
					@Override
						public void run() {
							runOnUiThread(new Runnable() {
							@Override
								public void run() {
										rotate = 360;
								calculate.setRotation((float)(rotate));
								}
							});
						}
					};
					_timer.schedule(time, (int)(5500));
		time = new TimerTask() {
					@Override
						public void run() {
							runOnUiThread(new Runnable() {
							@Override
								public void run() {
										rotate = 0;
								calculate.setRotation((float)(rotate));
								}
							});
						}
					};
					_timer.schedule(time, (int)(6000));
		time = new TimerTask() {
					@Override
						public void run() {
							runOnUiThread(new Runnable() {
							@Override
								public void run() {
										rotate = 90;
								calculate.setRotation((float)(rotate));
								}
							});
						}
					};
					_timer.schedule(time, (int)(6500));
		time = new TimerTask() {
					@Override
						public void run() {
							runOnUiThread(new Runnable() {
							@Override
								public void run() {
										rotate = 180;
								calculate.setRotation((float)(rotate));
								}
							});
						}
					};
					_timer.schedule(time, (int)(7000));
		time = new TimerTask() {
					@Override
						public void run() {
							runOnUiThread(new Runnable() {
							@Override
								public void run() {
										rotate = 270;
								calculate.setRotation((float)(rotate));
								}
							});
						}
					};
					_timer.schedule(time, (int)(7500));
		time = new TimerTask() {
					@Override
						public void run() {
							runOnUiThread(new Runnable() {
							@Override
								public void run() {
										rotate = 360;
								calculate.setRotation((float)(rotate));
								}
							});
						}
					};
					_timer.schedule(time, (int)(8000));
		time = new TimerTask() {
					@Override
						public void run() {
							runOnUiThread(new Runnable() {
							@Override
								public void run() {
										rotate = 0;
								calculate.setRotation((float)(rotate));
								}
							});
						}
					};
					_timer.schedule(time, (int)(8500));
		time = new TimerTask() {
					@Override
						public void run() {
							runOnUiThread(new Runnable() {
							@Override
								public void run() {
										rotate = 90;
								calculate.setRotation((float)(rotate));
								}
							});
						}
					};
					_timer.schedule(time, (int)(9000));
		time = new TimerTask() {
					@Override
						public void run() {
							runOnUiThread(new Runnable() {
							@Override
								public void run() {
										rotate = 180;
								calculate.setRotation((float)(rotate));
								}
							});
						}
					};
					_timer.schedule(time, (int)(9500));
		time = new TimerTask() {
					@Override
						public void run() {
							runOnUiThread(new Runnable() {
							@Override
								public void run() {
										rotate = 270;
								calculate.setRotation((float)(rotate));
								}
							});
						}
					};
					_timer.schedule(time, (int)(10000));
		time = new TimerTask() {
					@Override
						public void run() {
							runOnUiThread(new Runnable() {
							@Override
								public void run() {
										rotate = 360;
								calculate.setRotation((float)(rotate));
								}
							});
						}
					};
					_timer.schedule(time, (int)(10000));
		time = new TimerTask() {
					@Override
						public void run() {
							runOnUiThread(new Runnable() {
							@Override
								public void run() {
										rotate = 0;
								calculate.setRotation((float)(rotate));
								}
							});
						}
					};
					_timer.schedule(time, (int)(11500));
		time = new TimerTask() {
					@Override
						public void run() {
							runOnUiThread(new Runnable() {
							@Override
								public void run() {
										rotate = 90;
								calculate.setRotation((float)(rotate));
								}
							});
						}
					};
					_timer.schedule(time, (int)(20000));
		time = new TimerTask() {
					@Override
						public void run() {
							runOnUiThread(new Runnable() {
							@Override
								public void run() {
										rotate = 180;
								calculate.setRotation((float)(rotate));
								}
							});
						}
					};
					_timer.schedule(time, (int)(25000));
		time = new TimerTask() {
					@Override
						public void run() {
							runOnUiThread(new Runnable() {
							@Override
								public void run() {
										rotate = 270;
								calculate.setRotation((float)(rotate));
								}
							});
						}
					};
					_timer.schedule(time, (int)(30000));
		time = new TimerTask() {
					@Override
						public void run() {
							runOnUiThread(new Runnable() {
							@Override
								public void run() {
										rotate = 360;
								calculate.setRotation((float)(rotate));
								}
							});
						}
					};
					_timer.schedule(time, (int)(35000));
	}
	private void _visible_all () {
		subject1.setVisibility(View.VISIBLE);
		subject2.setVisibility(View.VISIBLE);
		subject3.setVisibility(View.VISIBLE);
		subject4.setVisibility(View.VISIBLE);
		subject5.setVisibility(View.VISIBLE);
		subject6.setVisibility(View.VISIBLE);
		grade1.setVisibility(View.VISIBLE);
		grade2.setVisibility(View.VISIBLE);
		grade3.setVisibility(View.VISIBLE);
		grade4.setVisibility(View.VISIBLE);
		grade5.setVisibility(View.VISIBLE);
		grade6.setVisibility(View.VISIBLE);
		points1.setVisibility(View.VISIBLE);
		points2.setVisibility(View.VISIBLE);
		points3.setVisibility(View.VISIBLE);
		points4.setVisibility(View.VISIBLE);
		points5.setVisibility(View.VISIBLE);
		points6.setVisibility(View.VISIBLE);
		no1.setVisibility(View.VISIBLE);
		no2.setVisibility(View.VISIBLE);
		no3.setVisibility(View.VISIBLE);
		no4.setVisibility(View.VISIBLE);
		no5.setVisibility(View.VISIBLE);
		no6.setVisibility(View.VISIBLE);
		grade1.setVisibility(View.VISIBLE);
		grade2.setVisibility(View.VISIBLE);
		grade3.setVisibility(View.VISIBLE);
		grade4.setVisibility(View.VISIBLE);
		grade5.setVisibility(View.VISIBLE);
		grade6.setVisibility(View.VISIBLE);
		ch_sub1.setVisibility(View.VISIBLE);
		ch_sub2.setVisibility(View.VISIBLE);
		ch_sub3.setVisibility(View.VISIBLE);
		ch_sub4.setVisibility(View.VISIBLE);
		ch_sub5.setVisibility(View.VISIBLE);
		ch_sub6.setVisibility(View.VISIBLE);
		file.edit().putString("subject", "6").commit();
		share.edit().putString("share", "6").commit();
	}
	private void _numbers () {
		no_8 = 8;
		no_9 = 9;
		no_10 = 10;
		no_11 = 11;
		no_12 = 12;
		no_13 = 13;
		no_14 = 14;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
		no_8++;
	}
	private void _ch1_check () {
		if (ch_sub1.getText().toString().equals("1") && (!no1.getText().toString().equals("") && ((Double.parseDouble(no1.getText().toString()) > 7) && (Double.parseDouble(no1.getText().toString()) < 21)))) {
			submitdata.setVisibility(View.GONE);
			allign_reset_calcula.setVisibility(View.VISIBLE);
		}
		else {
			if (ch_sub1.getText().toString().equals("2") && (!no1.getText().toString().equals("") && ((Double.parseDouble(no1.getText().toString()) > 15) && (Double.parseDouble(no1.getText().toString()) < 41)))) {
				submitdata.setVisibility(View.GONE);
				allign_reset_calcula.setVisibility(View.VISIBLE);
			}
			else {
				if (ch_sub1.getText().toString().equals("3") && (!no1.getText().toString().equals("") && ((Double.parseDouble(no1.getText().toString()) > 23) && (Double.parseDouble(no1.getText().toString()) < 61)))) {
					submitdata.setVisibility(View.GONE);
					allign_reset_calcula.setVisibility(View.VISIBLE);
				}
				else {
					if (ch_sub1.getText().toString().equals("4") && (!no1.getText().toString().equals("") && ((Double.parseDouble(no1.getText().toString()) > 31) && (Double.parseDouble(no1.getText().toString()) < 81)))) {
						submitdata.setVisibility(View.GONE);
						allign_reset_calcula.setVisibility(View.VISIBLE);
					}
					else {
						showMessage("Credit Hour-4 valid data is 32~80");
						submitdata.setVisibility(View.VISIBLE);
						allign_reset_calcula.setVisibility(View.GONE);
						no1.setText("");
					}
					showMessage("Credit Hour-3 valid data is 24~60");
					submitdata.setVisibility(View.VISIBLE);
					allign_reset_calcula.setVisibility(View.GONE);
				}
				showMessage("Credit Hour-2 valid data is 16~40");
				submitdata.setVisibility(View.VISIBLE);
				allign_reset_calcula.setVisibility(View.GONE);
			}
			showMessage("Credit Hour-1 valid data is 8~18");
			submitdata.setVisibility(View.VISIBLE);
			allign_reset_calcula.setVisibility(View.GONE);
		}
		if (ch_sub2.getText().toString().equals("1") && (!no2.getText().toString().equals("") && ((Double.parseDouble(no2.getText().toString()) > 7) && (Double.parseDouble(no2.getText().toString()) < 21)))) {
			submitdata.setVisibility(View.GONE);
			allign_reset_calcula.setVisibility(View.VISIBLE);
		}
		else {
			if (ch_sub2.getText().toString().equals("2") && (!no2.getText().toString().equals("") && ((Double.parseDouble(no2.getText().toString()) > 15) && (Double.parseDouble(no2.getText().toString()) < 41)))) {
				submitdata.setVisibility(View.GONE);
				allign_reset_calcula.setVisibility(View.VISIBLE);
			}
			else {
				if (ch_sub2.getText().toString().equals("3") && (!no2.getText().toString().equals("") && ((Double.parseDouble(no2.getText().toString()) > 23) && (Double.parseDouble(no2.getText().toString()) < 61)))) {
					submitdata.setVisibility(View.GONE);
					allign_reset_calcula.setVisibility(View.VISIBLE);
				}
				else {
					if (ch_sub2.getText().toString().equals("4") && (!no2.getText().toString().equals("") && ((Double.parseDouble(no2.getText().toString()) > 31) && (Double.parseDouble(no2.getText().toString()) < 81)))) {
						submitdata.setVisibility(View.GONE);
						allign_reset_calcula.setVisibility(View.VISIBLE);
					}
					else {
						showMessage("Credit Hour-4 valid data is 32~80");
						submitdata.setVisibility(View.VISIBLE);
						allign_reset_calcula.setVisibility(View.GONE);
						no2.setText("");
					}
					showMessage("Credit Hour-3 valid data is 24~60");
					submitdata.setVisibility(View.VISIBLE);
					allign_reset_calcula.setVisibility(View.GONE);
				}
				showMessage("Credit Hour-2 valid data is 16~40");
				submitdata.setVisibility(View.VISIBLE);
				allign_reset_calcula.setVisibility(View.GONE);
			}
			showMessage("Credit Hour-1 valid data is 8~18");
			submitdata.setVisibility(View.VISIBLE);
			allign_reset_calcula.setVisibility(View.GONE);
		}
		if (ch_sub3.getText().toString().equals("1") && (!no3.getText().toString().equals("") && ((Double.parseDouble(no3.getText().toString()) > 7) && (Double.parseDouble(no3.getText().toString()) < 21)))) {
			submitdata.setVisibility(View.GONE);
			allign_reset_calcula.setVisibility(View.VISIBLE);
		}
		else {
			if (ch_sub3.getText().toString().equals("2") && (!no3.getText().toString().equals("") && ((Double.parseDouble(no3.getText().toString()) > 15) && (Double.parseDouble(no3.getText().toString()) < 41)))) {
				submitdata.setVisibility(View.GONE);
				allign_reset_calcula.setVisibility(View.VISIBLE);
			}
			else {
				if (ch_sub3.getText().toString().equals("3") && (!no3.getText().toString().equals("") && ((Double.parseDouble(no3.getText().toString()) > 23) && (Double.parseDouble(no3.getText().toString()) < 61)))) {
					submitdata.setVisibility(View.GONE);
					allign_reset_calcula.setVisibility(View.VISIBLE);
				}
				else {
					if (ch_sub3.getText().toString().equals("4") && (!no3.getText().toString().equals("") && ((Double.parseDouble(no3.getText().toString()) > 31) && (Double.parseDouble(no3.getText().toString()) < 81)))) {
						submitdata.setVisibility(View.GONE);
						allign_reset_calcula.setVisibility(View.VISIBLE);
					}
					else {
						showMessage("Credit Hour-4 valid data is 32~80");
						submitdata.setVisibility(View.VISIBLE);
						allign_reset_calcula.setVisibility(View.GONE);
						no3.setText("");
					}
					showMessage("Credit Hour-3 valid data is 24~60");
					submitdata.setVisibility(View.VISIBLE);
					allign_reset_calcula.setVisibility(View.GONE);
				}
				showMessage("Credit Hour-2 valid data is 16~40");
				submitdata.setVisibility(View.VISIBLE);
				allign_reset_calcula.setVisibility(View.GONE);
			}
			showMessage("Credit Hour-1 valid data is 8~18");
			submitdata.setVisibility(View.VISIBLE);
			allign_reset_calcula.setVisibility(View.GONE);
		}
		if (ch_sub4.getText().toString().equals("1") && (!no4.getText().toString().equals("") && ((Double.parseDouble(no4.getText().toString()) > 7) && (Double.parseDouble(no4.getText().toString()) < 21)))) {
			submitdata.setVisibility(View.GONE);
			allign_reset_calcula.setVisibility(View.VISIBLE);
		}
		else {
			if (ch_sub4.getText().toString().equals("2") && (!no4.getText().toString().equals("") && ((Double.parseDouble(no4.getText().toString()) > 15) && (Double.parseDouble(no4.getText().toString()) < 41)))) {
				submitdata.setVisibility(View.GONE);
				allign_reset_calcula.setVisibility(View.VISIBLE);
			}
			else {
				if (ch_sub4.getText().toString().equals("3") && (!no4.getText().toString().equals("") && ((Double.parseDouble(no4.getText().toString()) > 23) && (Double.parseDouble(no4.getText().toString()) < 61)))) {
					submitdata.setVisibility(View.GONE);
					allign_reset_calcula.setVisibility(View.VISIBLE);
				}
				else {
					if (ch_sub4.getText().toString().equals("4") && (!no4.getText().toString().equals("") && ((Double.parseDouble(no4.getText().toString()) > 31) && (Double.parseDouble(no4.getText().toString()) < 81)))) {
						submitdata.setVisibility(View.GONE);
						allign_reset_calcula.setVisibility(View.VISIBLE);
					}
					else {
						showMessage("Credit Hour-4 valid data is 32~80");
						submitdata.setVisibility(View.VISIBLE);
						allign_reset_calcula.setVisibility(View.GONE);
						no4.setText("");
					}
					showMessage("Credit Hour-3 valid data is 24~60");
					submitdata.setVisibility(View.VISIBLE);
					allign_reset_calcula.setVisibility(View.GONE);
				}
				showMessage("Credit Hour-2 valid data is 16~40");
				submitdata.setVisibility(View.VISIBLE);
				allign_reset_calcula.setVisibility(View.GONE);
			}
			showMessage("Credit Hour-1 valid data is 8~18");
			submitdata.setVisibility(View.VISIBLE);
			allign_reset_calcula.setVisibility(View.GONE);
		}
		if (ch_sub5.getText().toString().equals("1") && (!no5.getText().toString().equals("") && ((Double.parseDouble(no5.getText().toString()) > 7) && (Double.parseDouble(no5.getText().toString()) < 21)))) {
			submitdata.setVisibility(View.GONE);
			allign_reset_calcula.setVisibility(View.VISIBLE);
		}
		else {
			if (ch_sub5.getText().toString().equals("2") && (!no5.getText().toString().equals("") && ((Double.parseDouble(no5.getText().toString()) > 15) && (Double.parseDouble(no5.getText().toString()) < 41)))) {
				submitdata.setVisibility(View.GONE);
				allign_reset_calcula.setVisibility(View.VISIBLE);
			}
			else {
				if (ch_sub5.getText().toString().equals("3") && (!no5.getText().toString().equals("") && ((Double.parseDouble(no5.getText().toString()) > 23) && (Double.parseDouble(no5.getText().toString()) < 61)))) {
					submitdata.setVisibility(View.GONE);
					allign_reset_calcula.setVisibility(View.VISIBLE);
				}
				else {
					if (ch_sub5.getText().toString().equals("4") && (!no5.getText().toString().equals("") && ((Double.parseDouble(no5.getText().toString()) > 31) && (Double.parseDouble(no5.getText().toString()) < 81)))) {
						submitdata.setVisibility(View.GONE);
						allign_reset_calcula.setVisibility(View.VISIBLE);
					}
					else {
						showMessage("Credit Hour-4 valid data is 32~80");
						submitdata.setVisibility(View.VISIBLE);
						allign_reset_calcula.setVisibility(View.GONE);
						no5.setText("");
					}
					showMessage("Credit Hour-3 valid data is 24~60");
					submitdata.setVisibility(View.VISIBLE);
					allign_reset_calcula.setVisibility(View.GONE);
				}
				showMessage("Credit Hour-2 valid data is 16~40");
				submitdata.setVisibility(View.VISIBLE);
				allign_reset_calcula.setVisibility(View.GONE);
			}
			showMessage("Credit Hour-1 valid data is 8~18");
			submitdata.setVisibility(View.VISIBLE);
			allign_reset_calcula.setVisibility(View.GONE);
		}
		if (ch_sub6.getText().toString().equals("1") && (!no6.getText().toString().equals("") && ((Double.parseDouble(no6.getText().toString()) > 7) && (Double.parseDouble(no6.getText().toString()) < 21)))) {
			submitdata.setVisibility(View.GONE);
			allign_reset_calcula.setVisibility(View.VISIBLE);
		}
		else {
			if (ch_sub6.getText().toString().equals("2") && (!no6.getText().toString().equals("") && ((Double.parseDouble(no6.getText().toString()) > 15) && (Double.parseDouble(no6.getText().toString()) < 41)))) {
				submitdata.setVisibility(View.GONE);
				allign_reset_calcula.setVisibility(View.VISIBLE);
			}
			else {
				if (ch_sub6.getText().toString().equals("3") && (!no6.getText().toString().equals("") && ((Double.parseDouble(no6.getText().toString()) > 23) && (Double.parseDouble(no6.getText().toString()) < 61)))) {
					submitdata.setVisibility(View.GONE);
					allign_reset_calcula.setVisibility(View.VISIBLE);
				}
				else {
					if (ch_sub6.getText().toString().equals("4") && (!no6.getText().toString().equals("") && ((Double.parseDouble(no6.getText().toString()) > 31) && (Double.parseDouble(no6.getText().toString()) < 81)))) {
						submitdata.setVisibility(View.GONE);
						allign_reset_calcula.setVisibility(View.VISIBLE);
					}
					else {
						showMessage("Credit Hour-4 valid data is 32~80");
						submitdata.setVisibility(View.VISIBLE);
						allign_reset_calcula.setVisibility(View.GONE);
						no6.setText("");
					}
					showMessage("Credit Hour-3 valid data is 24~60");
					submitdata.setVisibility(View.VISIBLE);
					allign_reset_calcula.setVisibility(View.GONE);
				}
				showMessage("Credit Hour-2 valid data is 16~40");
				submitdata.setVisibility(View.VISIBLE);
				allign_reset_calcula.setVisibility(View.GONE);
			}
			showMessage("Credit Hour-1 valid data is 8~18");
			submitdata.setVisibility(View.VISIBLE);
			allign_reset_calcula.setVisibility(View.GONE);
		}
	}
	private void _ch2_check () {
		if (ch_sub1.getText().toString().equals("2") && (!no1.getText().toString().equals("") && ((Double.parseDouble(no1.getText().toString()) > 15) && (Double.parseDouble(no1.getText().toString()) < 41)))) {
			submitdata.setVisibility(View.GONE);
			allign_reset_calcula.setVisibility(View.VISIBLE);
		}
		else {
			showMessage("Credit Hour-2 valid data is 16~40");
			submitdata.setVisibility(View.VISIBLE);
			allign_reset_calcula.setVisibility(View.GONE);
			no1.setText("");
		}
	}




	// created automatically
	private void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}

	private int getLocationX(View _v) {
		 int _location[] = new int[2];
		 _v.getLocationInWindow(_location);
		 return _location[0];
	}

	private int getLocationY(View _v) {
		 int _location[] = new int[2];
		 _v.getLocationInWindow(_location);
		 return _location[1];
	}

	private int getRandom(int _minValue ,int _maxValue){
		Random random = new Random();
		return random.nextInt(_maxValue - _minValue + 1) + _minValue;
	}

	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
				_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}

	private float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}

	private int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}

	private int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}


}
