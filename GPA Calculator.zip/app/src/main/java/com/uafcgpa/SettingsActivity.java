package com.uafcgpa;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.ClipboardManager;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;


public class SettingsActivity extends Activity {

	private LinearLayout linear1;
	private TextView textview1;
	private Button bug;
	private TextView textview2;
	private Button ideo;
	private TextView textview5;
	private Button night_on;
	private Button night_off;
	private TextView textview4;
	private Button on;
	private Button off;
	private TextView textview3;

	private double click = 0;


	private Timer _timer = new Timer();
	private Vibrator vib;
	private SharedPreferences vibration;
	private Intent i = new Intent();
	private AlertDialog.Builder exit;
	private TimerTask time;
	private SharedPreferences share;
	private SharedPreferences file;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.settings);
		initialize();
		initializeLogic();
	}

	private void  initialize() {
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		textview1 = (TextView) findViewById(R.id.textview1);
		bug = (Button) findViewById(R.id.bug);
		textview2 = (TextView) findViewById(R.id.textview2);
		ideo = (Button) findViewById(R.id.ideo);
		textview5 = (TextView) findViewById(R.id.textview5);
		night_on = (Button) findViewById(R.id.night_on);
		night_off = (Button) findViewById(R.id.night_off);
		textview4 = (TextView) findViewById(R.id.textview4);
		on = (Button) findViewById(R.id.on);
		off = (Button) findViewById(R.id.off);
		textview3 = (TextView) findViewById(R.id.textview3);

		vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
		vibration = getSharedPreferences("value", Activity.MODE_PRIVATE);

		exit = new AlertDialog.Builder(this);

		share = getSharedPreferences("activity", Activity.MODE_PRIVATE);
		file = getSharedPreferences("store", Activity.MODE_PRIVATE);

		off.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				vibration.edit().putString("click", "1").commit();
				showMessage("Vibration is OFF");
			}
		});
		on.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				vibration.edit().putString("click", "2").commit();
				showMessage("Vibration is ON");
			}
		});
		bug.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				i.setAction(Intent.ACTION_VIEW);
				i.setData(Uri.parse("mailto:uafappdevelopers@gmail.com?subject=Report bug"));
				startActivity(i);
			}
		});
		ideo.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				i.setAction(Intent.ACTION_VIEW);
				i.setData(Uri.parse("mailto:uafappdevelopers@gmail.com?subject=Suggestion"));
				startActivity(i);
			}
		});
		night_on.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				linear1.setBackgroundResource(R.drawable.wal2);
				share.edit().putString("mode", "1").commit();
				showMessage("Night mode is ON");
				textview1.setTextColor(0xFFFFFFFF);
				textview2.setTextColor(0xFFFFFFFF);
				textview4.setTextColor(0xFFFFFFFF);
				textview5.setTextColor(0xFFFFFFFF);
			}
		});
		night_off.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				share.edit().putString("mode", "0").commit();
				showMessage("Night mode is OFF");
				textview1.setTextColor(0xFF000000);
				textview2.setTextColor(0xFF000000);
				textview4.setTextColor(0xFF000000);
				textview5.setTextColor(0xFF000000);
				linear1.setBackgroundResource(R.drawable.gfgy);
			}
		});

	}

	private void  initializeLogic() {
		
getActionBar().setTitle("Settings");
		if (share.getString("exit", "").equals("yes")) {
			finish();
		}
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/osap.ttf"), 0);
		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/osap.ttf"), 0);
		textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/osap.ttf"), 0);
		textview4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/osap.ttf"), 0);
		
getActionBar().setDisplayHomeAsUpEnabled(true);
/* */} 
@Override 
public boolean onMenuItemSelected(int featureId, MenuItem item) {
int itemId = item.getItemId(); 
switch (itemId) {
case android.R.id.home:
finish();
break;
}
return true;

	}

	@Override
	public void onBackPressed() {
				if (share.getString("pop", "").equals("1")) {
					i.setClass(getApplicationContext(), Main2Activity.class);
					startActivity(i);
					finish();
				}
				else {
					if (share.getString("pop", "").equals("2")) {
						i.setClass(getApplicationContext(), WelcomeActivity.class);
						startActivity(i);
						finish();
					}
					else {
						if (share.getString("pop", "").equals("3")) {
							i.setClass(getApplicationContext(), MainActivity.class);
							startActivity(i);
							finish();
						}
					}
				}
	}





	// created automatically
	private void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}

	private int getLocationX(View _v) {
		 int _location[] = new int[2];
		 _v.getLocationInWindow(_location);
		 return _location[0];
	}

	private int getLocationY(View _v) {
		 int _location[] = new int[2];
		 _v.getLocationInWindow(_location);
		 return _location[1];
	}

	private int getRandom(int _minValue ,int _maxValue){
		Random random = new Random();
		return random.nextInt(_maxValue - _minValue + 1) + _minValue;
	}

	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
				_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}

	private float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}

	private int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}

	private int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}


}
