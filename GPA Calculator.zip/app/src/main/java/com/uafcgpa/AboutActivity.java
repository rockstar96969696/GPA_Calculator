package com.uafcgpa;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.ClipboardManager;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;


public class AboutActivity extends Activity {

	private LinearLayout linear1;
	private ImageView imageview1;
	private LinearLayout linear12;
	private LinearLayout linear13;
	private TextView textview17;
	private LinearLayout linear14;
	private TextView textview16;
	private LinearLayout linear15;
	private TextView textview12;
	private TextView textview18;
	private TextView textview19;
	private ImageView imageview2;
	private LinearLayout linear17;
	private TextView textview1;
	private TextView textview3;
	private ImageView imageview3;
	private TextView textview4;
	private TextView textview7;
	private ImageView imageview4;
	private TextView phone;
	private TextView textview14;



	private Intent i = new Intent();
	private SharedPreferences file;
	private SharedPreferences share;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.about);
		initialize();
		initializeLogic();
	}

	private void  initialize() {
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		linear13 = (LinearLayout) findViewById(R.id.linear13);
		textview17 = (TextView) findViewById(R.id.textview17);
		linear14 = (LinearLayout) findViewById(R.id.linear14);
		textview16 = (TextView) findViewById(R.id.textview16);
		linear15 = (LinearLayout) findViewById(R.id.linear15);
		textview12 = (TextView) findViewById(R.id.textview12);
		textview18 = (TextView) findViewById(R.id.textview18);
		textview19 = (TextView) findViewById(R.id.textview19);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		linear17 = (LinearLayout) findViewById(R.id.linear17);
		textview1 = (TextView) findViewById(R.id.textview1);
		textview3 = (TextView) findViewById(R.id.textview3);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		textview4 = (TextView) findViewById(R.id.textview4);
		textview7 = (TextView) findViewById(R.id.textview7);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		phone = (TextView) findViewById(R.id.phone);
		textview14 = (TextView) findViewById(R.id.textview14);


		file = getSharedPreferences("store", Activity.MODE_PRIVATE);
		share = getSharedPreferences("activity", Activity.MODE_PRIVATE);

		textview7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				textview7.setTextColor(0xFFF44336);
				i.setAction(Intent.ACTION_VIEW);
				i.setData(Uri.parse("mailto:uafappdevelopers?subject=Help"));
				startActivity(i);
			}
		});
		textview14.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				textview14.setTextColor(0xFFF44336);
				i.setAction(Intent.ACTION_VIEW);
				i.setData(Uri.parse("sms:+923452166807"));
				startActivity(i);
			}
		});

	}

	private void  initializeLogic() {
		
getActionBar().setTitle("About");
		if (share.getString("exit", "").equals("yes")) {
			finish();
		}
		textview12.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/osap.ttf"), 0);
		
getActionBar().setDisplayHomeAsUpEnabled(true);
/* */} 
@Override 
public boolean onMenuItemSelected(int featureId, MenuItem item) {
int itemId = item.getItemId(); 
switch (itemId) {
case android.R.id.home:
finish();
break;
}
return true;

	}

	@Override
	public void onBackPressed() {
				if (share.getString("pop", "").equals("1")) {
					i.setClass(getApplicationContext(), Main2Activity.class);
					startActivity(i);
					finish();
				}
				else {
					if (share.getString("pop", "").equals("2")) {
						i.setClass(getApplicationContext(), WelcomeActivity.class);
						startActivity(i);
						finish();
					}
					else {
						if (share.getString("pop", "").equals("3")) {
							i.setClass(getApplicationContext(), MainActivity.class);
							startActivity(i);
							finish();
						}
					}
				}
	}





	// created automatically
	private void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}

	private int getLocationX(View _v) {
		 int _location[] = new int[2];
		 _v.getLocationInWindow(_location);
		 return _location[0];
	}

	private int getLocationY(View _v) {
		 int _location[] = new int[2];
		 _v.getLocationInWindow(_location);
		 return _location[1];
	}

	private int getRandom(int _minValue ,int _maxValue){
		Random random = new Random();
		return random.nextInt(_maxValue - _minValue + 1) + _minValue;
	}

	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
				_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}

	private float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}

	private int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}

	private int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}


}
