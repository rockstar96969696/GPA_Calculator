package com.uafcgpa;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.ClipboardManager;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;


public class TempActivity extends Activity {

	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear9;
	private LinearLayout linear10;
	private LinearLayout linear11;
	private TextView no2;
	private TextView no1;
	private TextView no3;
	private TextView no5;
	private TextView no6;
	private TextView no4;
	private TextView ch_sub1;
	private TextView ch_sub2;
	private TextView ch_sub3;
	private TextView ch_sub4;
	private TextView ch_sub5;
	private TextView ch_sub6;
	private TextView points1;
	private TextView points2;
	private TextView points3;
	private TextView points4;
	private TextView points5;
	private TextView points6;
	private TextView grade1;
	private TextView grade2;
	private TextView grade3;
	private TextView grade4;
	private TextView grade5;
	private TextView grade6;





	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.temp);
		initialize();
		initializeLogic();
	}

	private void  initialize() {
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		no2 = (TextView) findViewById(R.id.no2);
		no1 = (TextView) findViewById(R.id.no1);
		no3 = (TextView) findViewById(R.id.no3);
		no5 = (TextView) findViewById(R.id.no5);
		no6 = (TextView) findViewById(R.id.no6);
		no4 = (TextView) findViewById(R.id.no4);
		ch_sub1 = (TextView) findViewById(R.id.ch_sub1);
		ch_sub2 = (TextView) findViewById(R.id.ch_sub2);
		ch_sub3 = (TextView) findViewById(R.id.ch_sub3);
		ch_sub4 = (TextView) findViewById(R.id.ch_sub4);
		ch_sub5 = (TextView) findViewById(R.id.ch_sub5);
		ch_sub6 = (TextView) findViewById(R.id.ch_sub6);
		points1 = (TextView) findViewById(R.id.points1);
		points2 = (TextView) findViewById(R.id.points2);
		points3 = (TextView) findViewById(R.id.points3);
		points4 = (TextView) findViewById(R.id.points4);
		points5 = (TextView) findViewById(R.id.points5);
		points6 = (TextView) findViewById(R.id.points6);
		grade1 = (TextView) findViewById(R.id.grade1);
		grade2 = (TextView) findViewById(R.id.grade2);
		grade3 = (TextView) findViewById(R.id.grade3);
		grade4 = (TextView) findViewById(R.id.grade4);
		grade5 = (TextView) findViewById(R.id.grade5);
		grade6 = (TextView) findViewById(R.id.grade6);



	}

	private void  initializeLogic() {

	}


	private void _ch1 () {

	}
	private void _ch2 () {

	}
	private void _ch3 () {

	}
	private void _ch4 () {

	}
	private void _ch5 () {

	}




	// created automatically
	private void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}

	private int getLocationX(View _v) {
		 int _location[] = new int[2];
		 _v.getLocationInWindow(_location);
		 return _location[0];
	}

	private int getLocationY(View _v) {
		 int _location[] = new int[2];
		 _v.getLocationInWindow(_location);
		 return _location[1];
	}

	private int getRandom(int _minValue ,int _maxValue){
		Random random = new Random();
		return random.nextInt(_maxValue - _minValue + 1) + _minValue;
	}

	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
				_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}

	private float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}

	private int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}

	private int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}


}
