package com.uafcgpa;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.ClipboardManager;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;


public class MainActivity extends Activity {

	private LinearLayout linear1;
	private TextView textview1;
	private TextView textview2;
	private TextView textview3;
	private LinearLayout linear2;
	private TextView textview6;
	private LinearLayout linear3;
	private Button online;
	private Button offline;
	private Button update;
	private TextView textview8;
	private TextView your_;

	private String your_version = "";
	private String latest_version = "";
	private String package_name = "";
	private boolean connected;
	private HashMap<String, Object> map = new HashMap<>();
	private String command = "";
	private String pkg = "";

	private ArrayList<HashMap<String, Object>> map1 = new ArrayList<>();
	private ArrayList<String> list = new ArrayList<String>();

	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private Timer _timer = new Timer();
	private Intent i = new Intent();
	private AlertDialog.Builder dilog1;
	private DatabaseReference Version = _firebase.getReference("ver2");
	private SharedPreferences file;
	private AlertDialog.Builder dialog;
	private Intent iii = new Intent();
	private AlertDialog.Builder dilo3;
	private Vibrator vib;
	private SharedPreferences vibration;
	private SharedPreferences share;
	private TimerTask t;
	private Intent i4 = new Intent();


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		initialize();
		initializeLogic();
	}

	private void  initialize() {
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		textview1 = (TextView) findViewById(R.id.textview1);
		textview2 = (TextView) findViewById(R.id.textview2);
		textview3 = (TextView) findViewById(R.id.textview3);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		textview6 = (TextView) findViewById(R.id.textview6);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		online = (Button) findViewById(R.id.online);
		offline = (Button) findViewById(R.id.offline);
		update = (Button) findViewById(R.id.update);
		textview8 = (TextView) findViewById(R.id.textview8);
		your_ = (TextView) findViewById(R.id.your_);


		dilog1 = new AlertDialog.Builder(this);

		file = getSharedPreferences("store", Activity.MODE_PRIVATE);
		dialog = new AlertDialog.Builder(this);

		dilo3 = new AlertDialog.Builder(this);
		vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
		vibration = getSharedPreferences("value", Activity.MODE_PRIVATE);
		share = getSharedPreferences("activity", Activity.MODE_PRIVATE);



		offline.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				if (vibration.getString("click", "").equals("1")) {
					vib.vibrate((long)(0));
				}
				else {
					if (vibration.getString("click", "").equals("2")) {
						vib.vibrate((long)(100));
					}
				}
				offline.setAlpha((float)(Double.parseDouble(".2")));
				t = new TimerTask() {
							@Override
								public void run() {
									runOnUiThread(new Runnable() {
									@Override
										public void run() {
														offline.setAlpha((float)(Double.parseDouble("1")));
										}
									});
								}
							};
							_timer.schedule(t, (int)(150));
				i.setClass(getApplicationContext(), WelcomeActivity.class);
				startActivity(i);
				finish();
			}
		});
		online.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				if (vibration.getString("click", "").equals("1")) {
					vib.vibrate((long)(0));
				}
				else {
					if (vibration.getString("click", "").equals("2")) {
						vib.vibrate((long)(100));
					}
				}
				online.setAlpha((float)(Double.parseDouble(".2")));
				t = new TimerTask() {
							@Override
								public void run() {
									runOnUiThread(new Runnable() {
									@Override
										public void run() {
														online.setAlpha((float)(Double.parseDouble("1")));
										}
									});
								}
							};
							_timer.schedule(t, (int)(150));
				i.setClass(getApplicationContext(), OnlineActivity.class);
				startActivity(i);
				finish();
			}
		});
		Version.addChildEventListener(new ChildEventListener() {
		@Override
		public void onChildAdded(DataSnapshot _dataSnapshot, String _previousValue) {
			GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
			HashMap<String, Object> _childValue = _dataSnapshot.getValue(_ind);
				Version.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						map1 = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
							map1.add(_map);
							}
						}
						catch (Exception e) {
							e.printStackTrace();
						}
						latest_version = map1.get((int)0).get("ver2").toString();
						if (Double.parseDouble(latest_version) > Double.parseDouble(your_version)) {
							dilo3.setTitle("Update available");
							dilo3.setMessage("You are using older version of app please update to latest version");
							dilo3.setNegativeButton("Later", new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface _dialog, int _which) {
																	showMessage("You need to update");

								}
							});
							dilo3.setPositiveButton("Update", new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface _dialog, int _which) {
							
										iii.setAction(Intent.ACTION_VIEW);
										iii.setData(Uri.parse("https://docs.google.com/spreadsheets/d/1Fe0wsUQiGMX3dX9hKfnWexTf0aICcpOZURwBG6s6NS0/edit?usp=drivesdk"));
										startActivity(iii);
										finish();
								}
							});
							dilo3.create().show();
						}
						else {
							showMessage("You are using the latest version");
						}
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			@Override
			public void onChildChanged(DataSnapshot _dataSnapshot, String _value) {
			GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
			HashMap<String, Object> _childValue = _dataSnapshot.getValue(_ind);

			}
			@Override
			public void onChildMoved(DataSnapshot _dataSnapshot, String _value) {
			}
			@Override
			public void onChildRemoved(DataSnapshot _dataSnapshot) {
			GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
			HashMap<String, Object> _childValue = _dataSnapshot.getValue(_ind);

			}
			@Override
			public void onCancelled(DatabaseError _databaseError) {

			}
		});

		update.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				_Check_Connection();
				if (connected) {
					Version.addListenerForSingleValueEvent(new ValueEventListener() {
						@Override
						public void onDataChange(DataSnapshot _dataSnapshot) {
							map1 = new ArrayList<>();
							try {
								GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
								for (DataSnapshot _data : _dataSnapshot.getChildren()) {
									HashMap<String, Object> _map = _data.getValue(_ind);
								map1.add(_map);
								}
							}
							catch (Exception e) {
								e.printStackTrace();
							}
							latest_version = map1.get((int)0).get("ver2").toString();
							if (Double.parseDouble(latest_version) > Double.parseDouble(your_version)) {
								dilo3.setTitle("Update available");
								dilo3.setMessage("You are using older version of app please update to latest version");
								dilo3.setNegativeButton("Later", new DialogInterface.OnClickListener() {
									@Override
									public void onClick(DialogInterface _dialog, int _which) {
																			showMessage("You need to update");
									}
								});
								dilo3.setPositiveButton("Update", new DialogInterface.OnClickListener() {
									@Override
									public void onClick(DialogInterface _dialog, int _which) {
																			iii.setAction(Intent.ACTION_VIEW);
											iii.setData(Uri.parse("https://docs.google.com/spreadsheets/d/1Fe0wsUQiGMX3dX9hKfnWexTf0aICcpOZURwBG6s6NS0/edit?usp=drivesdk"));
											startActivity(iii);
											finish();
									}
								});
								dilo3.create().show();
							}
							else {
								showMessage("You are using the latest version");
							}
						}
						@Override
						public void onCancelled(DatabaseError _databaseError) {
						}
					});
				}
				else {
					showMessage("Please connect to internet");
				}
				if (vibration.getString("click", "").equals("1")) {
					vib.vibrate((long)(0));
				}
				else {
					if (vibration.getString("click", "").equals("2")) {
						vib.vibrate((long)(100));
					}
				}
				update.setAlpha((float)(Double.parseDouble(".2")));
				t = new TimerTask() {
							@Override
								public void run() {
									runOnUiThread(new Runnable() {
									@Override
										public void run() {
														update.setAlpha((float)(Double.parseDouble("1")));
										}
									});
								}
							};
							_timer.schedule(t, (int)(150));
				if (vibration.getString("click", "").equals("1")) {
					vib.vibrate((long)(0));
				}
				else {
					if (vibration.getString("click", "").equals("2")) {
						vib.vibrate((long)(100));
					}
				}
			}
		});

	}

	private void  initializeLogic() {
		ActionBar ab = getActionBar ();
ab.setTitle ("Welcome"); ab.setDisplayShowHomeEnabled (true);
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/osap.ttf"), 0);
		package_name = "com.uafcgpa";
		try {
android.content.pm.PackageInfo pinfo = getPackageManager().getPackageInfo( package_name, android.content.pm.PackageManager.GET_ACTIVITIES);
your_version = pinfo.versionName; }catch (Exception e){ showMessage(e.toString()); }

		DatabaseReference rootRef = _firebase.getReference(); rootRef.child("version").addListenerForSingleValueEvent(new ValueEventListener() {
@Override
public void onDataChange(DataSnapshot snapshot) {
if (snapshot.exists()) { } else {
		_mode();
		map = new HashMap<>();
		map.put("ver2", your_version);
		} }
@Override
public void onCancelled(DatabaseError _error) { } });
		Version.child("app").updateChildren(map);
		map.clear();
		if (file.getString("visible", "").equals("")) {
			dialog.setTitle("What's new?");
			dialog.setMessage("●Bug fixes and stability improvements\n●Grade colors fix\n●Wrong data input restrictions");
			dialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
			
				}
			});
			dialog.setNegativeButton("Don't show again", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
									file.edit().putString("visible", "a").commit();
				}
			});
			dialog.create().show();
		}
		if (file.getString("close", "").equals("3")) {
			finish();
		}
		share.edit().putString("pop", "3").commit();
		if (share.getString("swipe", "").equals("")) {
			iii.setClass(getApplicationContext(), SwipeActivity.class);
			startActivity(iii);
		}
		your_.setText("Your_Version ".concat(your_version));
		 }
@Override
public boolean onCreateOptionsMenu(Menu menu){


menu.add("Share App").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);


menu.add("About us").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);

menu.add("Settings").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
menu.add("Help").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
return true;
}

@Override 
public boolean onOptionsItemSelected(final MenuItem item) {
switch (item.getTitle().toString()) {
case "Share App":
showMessage("Sharing App");


pkg="com.uafcgpa";
 String apk = "";
String uri = (pkg);
try {
android.content.pm.PackageInfo pi = getPackageManager().getPackageInfo(uri, android.content.pm.PackageManager.GET_ACTIVITIES);
apk = pi.applicationInfo.publicSourceDir;
} catch (Exception e) { showMessage(e.toString());}
Intent iten = new Intent(Intent.ACTION_SEND);
iten.setType("*/*");
iten.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(new java.io.File(apk)));
startActivity(Intent.createChooser(iten, "Share App")); 
return true;
case "Settings":
showMessage("Settings");
i4.setClass(getApplicationContext(),SettingsActivity.class);
startActivity (i4);

return true;
case "Help":
showMessage("Help");
i.setClass(getApplicationContext(),HelpActivity.class);
startActivity (i);
return true;
case "About us":
showMessage("UAF Developers");
i.setClass(getApplicationContext(),AboutActivity.class);
startActivity (i);
return true;
default:
return super.onOptionsItemSelected(item);
}
	}

	@Override
	public void onBackPressed() {
				dilog1.setTitle("Exit");
				dilog1.setMessage("Do you really want to exit?");
				dilog1.setPositiveButton("YES", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
											finishAffinity ();
					}
				});
				dilog1.setNegativeButton("No", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
				
					}
				});
				dilog1.create().show();
	}
	@Override
	public void onDestroy() {
		super.onDestroy();

	}
	@Override
	public void onResume() {
		super.onResume();
				if (share.getString("pop", "").equals("1")) {
					i.setClass(getApplicationContext(), Main2Activity.class);
					startActivity(i);
					finish();
				}
				else {
					if (share.getString("pop", "").equals("2")) {
						i.setClass(getApplicationContext(), WelcomeActivity.class);
						startActivity(i);
						finish();
					}
				}
				_mode();
	}

	private void _Check_Connection () {
		try {
		command = "ping -c 1 google.com";
		connected = (Runtime.getRuntime().exec (command).waitFor() == 0); } catch (Exception e){ showMessage(e.toString());}
	}
	private void _mode () {
		if (share.getString("mode", "").equals("1")) {
			linear1.setBackgroundResource(R.drawable.ssn);
			textview6.setTextColor(0xFFFFFFFF);
			your_.setTextColor(0xFFFFFFFF);
			textview1.setTextColor(0xFFFFFFFF);
		}
		else {
			if (share.getString("mode", "").equals("0")) {
				linear1.setBackgroundResource(R.drawable.shsh);
				textview6.setTextColor(0xFF000000);
				your_.setTextColor(0xFF000000);
				textview1.setTextColor(0xFF000000);
			}
		}
	}




	// created automatically
	private void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}

	private int getLocationX(View _v) {
		 int _location[] = new int[2];
		 _v.getLocationInWindow(_location);
		 return _location[0];
	}

	private int getLocationY(View _v) {
		 int _location[] = new int[2];
		 _v.getLocationInWindow(_location);
		 return _location[1];
	}

	private int getRandom(int _minValue ,int _maxValue){
		Random random = new Random();
		return random.nextInt(_maxValue - _minValue + 1) + _minValue;
	}

	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
				_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}

	private float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}

	private int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}

	private int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}


}
